# -*- coding: utf-8 -*-
"""Extract text from LMCC exam PDFs using pdfplumber (primary) and PyPDF2 (fallback)."""

import pdfplumber
import PyPDF2
import os
import sys
import traceback

PDF_FILES = [
    (r"C:\Users\MINXIN\Desktop\CCF LMCC\LMCC-2025+第一轮试题解析.pdf", "PDF1_Round1_2025"),
    (r"C:\Users\MINXIN\Desktop\CCF LMCC\LMCC-2025+第二轮试题解析+-+青少年组.pdf", "PDF2_Round2_Youth_2025"),
    (r"C:\Users\MINXIN\Desktop\CCF LMCC\LMCC-青少年组-新例题-2026.pdf", "PDF3_NewExamples_2026"),
    (r"C:\Users\MINXIN\Desktop\CCF LMCC\lmcc\首次LMCC青少年组交流活动-试题分析.pdf", "PDF4_FirstExchange_Analysis"),
]

OUTPUT_FILE = r"C:\Users\MINXIN\Desktop\CCF LMCC\work\exam_analysis.txt"


def extract_with_pdfplumber(pdf_path):
    """Extract text using pdfplumber - handles complex layouts better."""
    pages_text = []
    with pdfplumber.open(pdf_path) as pdf:
        total_pages = len(pdf.pages)
        for i, page in enumerate(pdf.pages):
            text = page.extract_text() or ""
            pages_text.append(f"\n--- Page {i+1}/{total_pages} ---\n{text}")
    return total_pages, "\n".join(pages_text)


def extract_with_pypdf2(pdf_path):
    """Fallback extraction using PyPDF2."""
    pages_text = []
    with open(pdf_path, "rb") as f:
        reader = PyPDF2.PdfReader(f)
        total_pages = len(reader.pages)
        for i, page in enumerate(reader.pages):
            text = page.extract_text() or ""
            pages_text.append(f"\n--- Page {i+1}/{total_pages} ---\n{text}")
    return total_pages, "\n".join(pages_text)


def extract_pdf(pdf_path, label):
    """Try pdfplumber first, fall back to PyPDF2."""
    print(f"\n{'='*60}")
    print(f"Processing: {label}")
    print(f"File: {pdf_path}")
    print(f"{'='*60}")

    if not os.path.exists(pdf_path):
        msg = f"ERROR: File not found: {pdf_path}"
        print(msg)
        return msg

    file_size = os.path.getsize(pdf_path)
    print(f"File size: {file_size:,} bytes")

    # Try pdfplumber first
    try:
        print("Attempting extraction with pdfplumber...")
        total_pages, text = extract_with_pdfplumber(pdf_path)
        print(f"Success! Extracted {total_pages} pages, {len(text):,} characters")
        return text
    except Exception as e:
        print(f"pdfplumber failed: {e}")
        traceback.print_exc()

    # Fallback to PyPDF2
    try:
        print("Attempting extraction with PyPDF2 (fallback)...")
        total_pages, text = extract_with_pypdf2(pdf_path)
        print(f"Success! Extracted {total_pages} pages, {len(text):,} characters")
        return text
    except Exception as e:
        msg = f"ERROR: Both extraction methods failed for {pdf_path}: {e}"
        print(msg)
        traceback.print_exc()
        return msg


def main():
    all_results = []

    for pdf_path, label in PDF_FILES:
        text = extract_pdf(pdf_path, label)
        header = f"\n{'#'*80}\n# {label}\n# File: {pdf_path}\n{'#'*80}\n"
        all_results.append(header + text)

    # Write all results to output file
    print(f"\n\nWriting results to: {OUTPUT_FILE}")
    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        f.write("LMCC Exam Analysis - Extracted Text from All PDFs\n")
        f.write(f"Generated: 2026-07-14\n")
        f.write("="*80 + "\n")
        for result in all_results:
            f.write(result)
            f.write("\n\n")

    final_size = os.path.getsize(OUTPUT_FILE)
    print(f"Done! Output file: {OUTPUT_FILE} ({final_size:,} bytes)")


if __name__ == "__main__":
    main()
