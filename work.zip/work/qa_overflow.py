import os, re
from playwright.sync_api import sync_playwright
FIGD = "work/figs"
files = sorted(f for f in os.listdir(FIGD) if f.endswith(".svg"))
def load(n):
    s = open(os.path.join(FIGD, n), encoding="utf-8").read()
    return re.sub(r'<\?xml.*?\?>', '', s).strip()
divs = "\n".join(f'<div class="fig" data-name="{f}">{load(f)}</div>' for f in files)
html = f'''<html><head><meta charset="utf-8"><style>.fig{{margin:10px}} svg{{max-width:100%}}</style></head><body>{divs}</body></html>'''
issues=[]
with sync_playwright() as p:
    b=p.chromium.launch(args=["--no-sandbox"])
    pg=b.new_page(viewport={"width":1200,"height":1000})
    pg.set_content(html)
    pg.wait_for_timeout(600)
    for fn in files:
        r=pg.evaluate("""(name)=>{
            const d=document.querySelector(`[data-name="${name}"] #content`);
            if(!d) return {mat:true};
            const svg=d.ownerSVGElement;
            const vb=svg.getAttribute('viewBox').split(' ').map(Number);
            const bb=d.getBBox();
            return {vb, bb:{x:bb.x,y:bb.y,w:bb.width,h:bb.height}};
        }""", fn)
        if r.get("mat"):
            print(f'MATPLOTLIB/无#content {fn:24s} (tight_bbox, 结构性不裁切)'); continue
        vb=r["vb"]; bb=r["bb"]; W,H=vb[2],vb[3]; tol=2.0
        over=[]
        if bb["x"]<-tol: over.append(f'x={bb["x"]:.1f}')
        if bb["y"]<-tol: over.append(f'y={bb["y"]:.1f}')
        if bb["x"]+bb["w"]>W+tol: over.append(f'右={bb["x"]+bb["w"]:.1f}>{W}')
        if bb["y"]+bb["h"]>H+tol: over.append(f'下={bb["y"]+bb["h"]:.1f}>{H}')
        st="OK " if not over else "BAD"
        print(f'{st} {fn:24s} vb={W}x{H} content=({bb["x"]:.0f},{bb["y"]:.0f},{bb["w"]:.0f},{bb["h"]:.0f}) ' + ("; ".join(over) if over else ""))
        if over: issues.append(fn)
    b.close()
print("\n问题图:", issues if issues else "无")
