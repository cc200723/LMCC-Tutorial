#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Restore figure 1-11 after section 1.4.3."""
import re

HTML = "LMCC青少年组教材-增强版.html"
html = open(HTML, encoding="utf-8").read()

# ===== Helper functions (copied from add_figures.py) =====
BLUE = "#2c5f8a"
ORANGE = "#c1572f"
GREEN = "#2f7d4f"
TEAL = "#1f8a7c"
PURPLE = "#6a4c93"
LIGHT = "#eef3f8"
BORDER = "#cfd6dd"
INK = "#1a1a1a"

def svg_open(W, H):
    return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" width="{W}" font-family="Noto Sans CJK SC,Microsoft YaHei,sans-serif" font-size="15" fill="{INK}"><rect x="0" y="0" width="{W}" height="{H}" fill="white"/>'

def t(x, y, text, size=15, color=INK, weight=400, anchor="middle"):
    return f'<text x="{x}" y="{y}" text-anchor="{anchor}" fill="{color}" font-size="{size}" font-weight="{weight}">{text}</text>'

def box(x, y, w, h, fill="none", stroke=BORDER, rx=8, header=None, hfill=None):
    s = f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{rx}" fill="{fill}" stroke="{stroke}" stroke-width="1.5"/>'
    if header:
        s = f'<path d="M {x},{y+20} a {rx},{rx} 0 0 1 -{rx},-{rx} h {w-2*rx} a {rx},{rx} 0 0 1 {rx},{rx} v 20 h -{w} Z" fill="{hfill}"/>' + s
        s += t(x + w/2, y + 15, header, size=14, color="white", weight=600)
    return s

def lines(x, y, items, size=14, lh=28, color=INK):
    return "".join(t(x, y + i*lh, item, size=size, color=color, anchor="start") for i, item in enumerate(items))

def fig_1_11():
    W, H = 840, 430
    s = svg_open(W, H)
    s += t(W/2, 28, "大模型现状：国际持续迭代，国内快速发展", size=16, weight=600)
    s += box(40, 55, 360, 250, header="国际主流代表", hfill=BLUE)
    s += lines(62, 118, [
        "GPT-4 / GPT-4o（OpenAI）",
        "Claude（Anthropic）",
        "Gemini（Google）",
        "Llama（Meta，开源）",
        "Mixtral、Grok 等",
    ], size=14.5, lh=30)
    s += box(440, 55, 360, 250, header="国内代表模型", hfill=ORANGE)
    s += lines(462, 118, [
        "文心一言（百度）",
        "通义千问 Qwen（阿里）",
        "智谱 GLM（清华/智谱）",
        "豆包（字节）、DeepSeek",
        "阶跃、Kimi 等",
    ], size=14.5, lh=30)
    for i, (name, c) in enumerate([("趋势：开源化、多模态、推理增强", GREEN),
                                     ("正确使用：核实信息、保护隐私", TEAL),
                                     ("关键决策仍由人把关", PURPLE)]):
        x = 40 + i * 270
        s += box(x, 325, 255, 80, fill=LIGHT, stroke=BORDER, rx=8)
        s += t(x + 127, 370, name, size=13.5, color=INK, weight=600)
    s += "</svg>"
    return s

# ===== Insert figure 1-11 after section 1.4.3 text =====
new_fig = f'<figure class="textbook-fig">{fig_1_11()}\n<figcaption>图 1-11 大模型现状：国际持续迭代，国内快速发展</figcaption></figure>\n'

# Find position: after the note box that ends section 1.4.3, before the next h3
marker_end = '<div class="note">使用大模型时，记住三条原则：第一，关键信息要核实，模型可能会“一本正经地胡说八道”；第二，保护个人隐私，不要输入敏感信息；第三，关键决策仍要由人把关，模型是辅助工具，不是最终责任人。</div>\n'
assert marker_end in html, "section 1.4.3 note not found"

# Find the next heading after this note
pos = html.find(marker_end) + len(marker_end)
next_h = min([html.find(tag, pos) for tag in ['<h3', '<h2', '<h1'] if html.find(tag, pos) != -1])
assert next_h != -1, "next heading not found"

html = html[:next_h] + "\n" + new_fig + "\n" + html[next_h:]
open(HTML, "w", encoding="utf-8").write(html)
print("Restored figure 1-11 after section 1.4.3.")
