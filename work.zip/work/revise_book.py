# -*- coding: utf-8 -*-
"""
LMCC青少年组教材-增强版 修订脚本
1. 修复第3章重复标题 3.1.1
2. 扩充第3章：扩展法则、数据课程、训练监控与检查点
3. 扩充第4章：后训练概述、指令数据集构建方法、RLVR、长思维链对比案例
4. 扩充第5章：解码案例、部署实践、模型压缩方法
5. 扩充第2章：架构适用场景案例、掩码机制
6. 生成新增SVG矢量图
"""
import re, os, copy

HTML_PATH = r'C:\Users\MINXIN\Desktop\CCF LMCC\LMCC青少年组教材-增强版.html'

with open(HTML_PATH, 'r', encoding='utf-8') as f:
    html = f.read()

original_len = len(html)

# ============================================================
# FIX 1: Chapter 3 duplicate heading 3.1.1
# ============================================================
# Current: <h2>3.1 预训练到底在学什么</h2><h3>3.1.1 预训练数据准备：从网页文本到训练样本</h3>
# Fix: separate them and renumber the second 3.1.1 to 3.1.2
html = html.replace(
    '<h2>3.1 预训练到底在学什么</h2><h3>3.1.1 预训练数据准备：从网页文本到训练样本</h3>',
    '<h2>3.1 预训练到底在学什么</h2>\n<p>预训练的目标是让模型从海量文本中学到语言的统计规律——语法结构、世界知识、推理模式。不同的预训练目标决定了模型"学什么样的规律"，也决定了它适合做什么任务。</p>\n<h3>3.1.1 预训练数据准备：从网页文本到训练样本</h3>'
)

# Fix the second 3.1.1 (loss function) to 3.1.2
html = html.replace(
    '<h3>3.1.1 损失函数：模型"有多意外"的分数</h3>',
    '<h3>3.1.2 损失函数：模型"有多意外"的分数</h3>'
)

print(f"[Fix 1] Duplicate heading 3.1.1 fixed")

# ============================================================
# FIX 2: Expand Chapter 3 - Add Scaling Laws after section 3.4
# ============================================================
scaling_laws_section = '''
<h2>3.5 扩展法则：模型越大就越好吗</h2>
<p>一个关键问题：加大参数量、增加数据量、增加算力，三者怎么搭配才"划算"？这就是<strong>扩展法则（Scaling Laws）</strong>回答的问题。</p>

<h3>3.5.1 KM 扩展法则</h3>
<p>2020 年，Kaplan 等人（OpenAI）发现：模型损失随参数量 N、数据量 D 和算力 C 呈<strong>幂律</strong>下降——也就是说，在很大范围内，投入更多资源，回报是可预测的。这意味着：</p>
<ul>
<li>参数翻倍 → 损失按固定比例下降（不是翻倍变好，而是稳步变好）；</li>
<li>数据翻倍 → 同理，但数据量不足时加参数没有意义（"大模型小数据"是浪费）；</li>
<li>算力预算固定时，存在一个"最优分配方案"。</li>
</ul>
<p>KM 法则的直觉结论：如果你有固定算力，优先把它花在<strong>更大的模型</strong>上，而不是更多数据——因为大模型从每个样本里学到的东西更多。</p>

<h3>3.5.2 Chinchilla 扩展法则</h3>
<p>2022 年，DeepMind 的 Chinchilla 论文修正了 KM 法则：原来 KM 高估了参数的重要性，<strong>低估了数据量的重要性</strong>。Chinchilla 法则的核心结论是：</p>
<div class="math-block">$$ N_{\\text{opt}} \\propto C^{0.5}, \\quad D_{\\text{opt}} \\propto C^{0.5} $$</div>
<p>翻译成人话：<strong>最优策略是参数量和数据量按 1:1 的比例同步增长</strong>。训练一个 70B 参数的模型，大约需要 1.4 万亿（1.4T）词元的数据；如果只给它 3000 亿词元，模型会"吃不饱"，浪费了参数容量。</p>
<table class="tbl">
<thead><tr><th>法则</th><th>核心结论</th><th>实践含义</th></tr></thead>
<tbody>
<tr><td>KM 法则（2020）</td><td>参数量比数据量更重要</td><td>固定算力优先加大模型</td></tr>
<tr><td>Chinchilla 法则（2022）</td><td>参数和数据应同步增长（约 1:20 词元/参数）</td><td>"喂饱"模型，不要浪费参数容量</td></tr>
</tbody>
</table>
<div class="note">认证常考：Chinchilla 法则指出"计算最优"的模型不是最大的模型，而是参数与数据配比最均衡的模型。训练数据不够就加大模型，等于"盖了大房子但不放家具"。</div>

<h3>计算工坊 3-3：Chinchilla 最优数据量</h3>
<pre><code># Chinchilla 法则：最优数据量 ≈ 20 × 参数量
def chinchilla_optimal_data(num_params):
    return num_params * 20

# 7B 模型的最优数据量
data_7b = chinchilla_optimal_data(7e9)
print(f"7B 模型最优训练数据: {data_7b:.0e} 词元")  # 1.4e+11 = 1400 亿

# 70B 模型的最优数据量
data_70b = chinchilla_optimal_data(70e9)
print(f"70B 模型最优训练数据: {data_70b:.0e} 词元") # 1.4e+12 = 1.4 万亿</code></pre>

<h2>3.6 训练监控、检查点与稳定性</h2>
<p>预训练不是"按下开始就等着结束"——它可能跑几天甚至几个月，中间随时可能出问题。</p>

<h3>3.6.1 训练监控看什么</h3>
<ul>
<li><strong>损失曲线</strong>：训练损失应该稳步下降。如果突然飙升（loss spike），可能是学习率太大、数据有异常或梯度爆炸。</li>
<li><strong>梯度范数</strong>：如果梯度范数突然放大，说明某一步的更新幅度过大，可能导致训练崩溃。</li>
<li><strong>验证集指标</strong>：定期在验证集上测困惑度（PPL）或其他指标，确认模型确实在变好，而不是在训练集上过拟合。</li>
</ul>

<h3>3.6.2 检查点（Checkpoint）</h3>
<p>训练过程中定期保存模型参数的"快照"，叫<strong>检查点</strong>。它的作用有两个：</p>
<ul>
<li><strong>断点恢复</strong>：如果训练因为机器故障或程序异常中断，可以从最近的检查点继续，不用从头开始。</li>
<li><strong>模型选择</strong>：保存训练过程中验证集表现最好的检查点，作为最终模型。</li>
</ul>
<div class="note">检查点不只是存权重，还要存优化器状态（Adam 的一阶/二阶矩）、当前学习率、已训练步数等——这样恢复训练才能"接上"。</div>

<h3>3.6.3 训练稳定性技巧</h3>
<ul>
<li><strong>梯度裁剪</strong>（已在 3.3 提到）：限制梯度范数上限，防止爆炸。</li>
<li><strong>混合精度训练</strong>：用 FP16/BF16 加速，但需注意 BF16 的指数位与 FP32 相同，数值范围更大，不易溢出；FP16 尾数位更多但范围小，更易上溢/下溢。</li>
<li><strong>学习率预热 + 余弦退火</strong>：开头小步慢走（warm-up），中间快速下降，结尾平缓收尾。</li>
</ul>
<div class="key-box">
<h4>认证要点</h4>
<ul>
<li>Chinchilla 法则：最优参数量与数据量同步增长（约 1:20 词元/参数比）。</li>
<li>训练中必须监控损失曲线和梯度范数；loss spike 可能意味着训练不稳定。</li>
<li>检查点保存的不只是权重，还有优化器状态和训练进度。</li>
<li>BF16 比 FP16 数值范围更大，训练时更稳定。</li>
</ul>
</div>
'''

# Insert after section 3.4 (参数量怎么算) and before old 3.5
# Find the old "<h2>3.5 量化显存与吞吐量</h2>" and insert before it
html = html.replace(
    '<h2>3.5 量化显存与吞吐量</h2>',
    scaling_laws_section + '\n<h2>3.7 量化显存与吞吐量</h2>'
)

# Also renumber 3.6 并行训练 to 3.8
html = html.replace(
    '<h2>3.6 并行训练与显存优化</h2>',
    '<h2>3.8 并行训练与显存优化</h2>'
)
# Renumber 计算工坊 3-2
html = html.replace(
    '<h3>计算工坊 3-2：吞吐量要计入周期同步</h3>',
    '<h3>计算工坊 3-4：吞吐量要计入周期同步</h3>'
)

print(f"[Fix 2] Chapter 3: Added Scaling Laws + Training Monitoring sections")

# ============================================================
# FIX 3: Expand Chapter 4 - Post-training overview, RLVR, Long-CoT case
# ============================================================
# Insert after the chapter intro paragraph and before 4.1
ch4_expansion = '''

<h2>4.0 后训练概述：从"会续写"到"会干活"</h2>
<p>预训练出来的模型只会一件事：给定前文，续写下一个词元。但用户真正需要的是一个<strong>能听懂指令、按规矩回答、不犯错的助手</strong>。从"原始预训练模型"到"可用助手"中间的所有步骤，统称<strong>后训练（Post-training）</strong>。</p>

<h3>4.0.1 为什么需要后训练</h3>
<p>预训练模型有几个"毛病"：</p>
<ul>
<li><strong>不会停下</strong>：给它一句"请翻译这个句子"，它可能继续翻译下一句，而不是停下来等你回复。</li>
<li><strong>不懂格式</strong>：你问"今天天气怎样"，它可能接一段小说，而不是直接回答。</li>
<li><strong>可能有害</strong>：如果不加约束，它会按训练数据里的模式说话，可能输出偏见、错误甚至危险内容。</li>
</ul>
<p>后训练的三个阶段依次解决这些问题：</p>
<table class="tbl">
<thead><tr><th>阶段</th><th>做什么</th><th>训练信号</th><th>解决的问题</th></tr></thead>
<tbody>
<tr><td>SFT（监督微调）</td><td>用"指令—回答"数据教它按指令做事</td><td>示范答案（人工或模型生成）</td><td>不会停下、不懂格式</td></tr>
<tr><td>人类对齐</td><td>按人类偏好校准回答风格与安全</td><td>偏好排序 / 评分</td><td>有害内容、风格不当</td></tr>
<tr><td>复杂推理训练</td><td>训练长思维链推理能力</td><td>推理过程标注 + RL</td><td>复杂问题不会推理</td></tr>
</tbody>
</table>

<h3>4.0.2 预训练模型与微调后模型的对比</h3>
<p>用一个例子感受后训练的效果。给预训练模型输入"请用三句话介绍太阳系"，它可能这样续写：</p>
<pre><code># 预训练模型（未经后训练）的输出
请用三句话介绍太阳系。太阳系是由太阳和围绕它运转的天体组成
的行星系统。主要包括八大行星、矮行星、小行星和彗星等。太阳
系的边界目前尚有争议……（继续写下去，不停）</code></pre>
<p>它把"请用三句话介绍太阳系"当成了要续写的文本，而不是指令。经过 SFT 后训练后：</p>
<pre><code># SFT 后模型的输出
太阳系是以太阳为中心的天体系统，包含八大行星、矮行星和
众多小天体。八大行星按距离太阳从近到远依次为水星、金星、
地球、火星、木星、土星、天王星和海王星。太阳系形成于约
46 亿年前，是目前已知唯一存在生命的行星系统。</code></pre>
<p>区别一目了然：SFT 后的模型<strong>理解了"这是一个指令"</strong>，按要求回答并在三句话后停下。</p>

<h2>4.1 指令数据集的构建</h2>
<p>指令微调的核心原料是<strong>指令数据集</strong>——成千上万条"指令—回答"对。怎么造出高质量数据，是指令微调最关键的环节。</p>

<h3>4.1.1 指令数据的来源</h3>
<table class="tbl">
<thead><tr><th>来源</th><th>做法</th><th>优点</th><th>风险</th></tr></thead>
<tbody>
<tr><td>人工标注</td><td>请人写指令并给出标准回答</td><td>质量可控、可验证</td><td>成本高、速度慢</td></tr>
<tr><td>模型生成（Self-Instruct）</td><td>用已有的强模型生成指令-回答对</td><td>量大、成本低</td><td>可能继承模型偏见、质量不均</td></tr>
<tr><td>真实用户日志</td><td>从实际用户与模型的对话中筛选</td><td>贴近真实需求</td><td>隐私风险、需脱敏</td></tr>
<tr><td>开源数据集</td><td>如 Alpaca、FLAN、ShareGPT 等</td><td>开箱即用</td><td>需要筛选和清洗</td></tr>
</tbody>
</table>

<h3>4.1.2 高质量指令数据的筛选标准</h3>
<p>考试常考的筛选标准（来自 2025 年第一轮试题第 3 题）：</p>
<ul>
<li><strong>语义一致性</strong>：回答内容与指令语义匹配——这是最核心的标准。回答跑题就是低质量数据。</li>
<li><strong>正确性</strong>：回答中的事实、推理、代码是否正确。</li>
<li><strong>多样性</strong>：指令类型、长度、难度要分布广泛，不能全是"翻译"或全是"摘要"。</li>
<li><strong>格式规范</strong>：如果要求 JSON 输出，检查是否真的是合法 JSON。</li>
<li><strong>无隐私风险</strong>：不含真实姓名、电话、身份证号等。</li>
</ul>
<div class="warn">"指令长度超过 20 个字符"不是质量标准——短指令也可以是高质量的。"用英文书写"也不是质量标准——语言类型与数据质量无关。</div>
'''

# Insert after chapter 4 intro paragraph and learning objectives box, before 4.1
# Current structure: intro <p>, key-box, then <h2>4.1 一条合格的指令数据</h2>
# We need to insert after the key-box and before the figure that starts 4.1
html = html.replace(
    '<h2>4.1 一条合格的指令数据</h2>',
    ch4_expansion + '\n<h2>4.2 指令数据与质量检查</h2>'
)

# Renumber subsequent sections: 4.1.1 -> 4.2.1, 4.2 SFT -> 4.3, 4.3 LoRA -> 4.4, 4.4 人类对齐 -> 4.5, 4.5 幻觉 -> 4.6
html = html.replace(
    '<h3>4.1.1 看一条真实指令数据长什么样</h3>',
    '<h3>4.2.1 看一条真实指令数据长什么样</h3>'
)
html = html.replace(
    '<h2>4.2 监督微调（SFT）</h2>',
    '<h2>4.3 监督微调（SFT）</h2>'
)
html = html.replace(
    '<h2>4.3 LoRA：用低秩更新省参数</h2>',
    '<h2>4.4 LoRA：用低秩更新省参数</h2>'
)
html = html.replace(
    '<h3>计算工坊 4-1：LoRA 可训练参数比例</h3>',
    '<h3>计算工坊 4-2：LoRA 可训练参数比例</h3>'
)
html = html.replace(
    '<h2>4.4 人类对齐：3H 与方法边界</h2>',
    '<h2>4.5 人类对齐：3H 与方法边界</h2>'
)
html = html.replace(
    '<h2>4.5 幻觉与偏见</h2>',
    '<h2>4.6 幻觉与偏见</h2>'
)

# Add RLVR and Long-CoT comparison after section 4.5 (人类对齐), before 4.6 幻觉与偏见
rlvr_section = '''
<h3>4.5.1 强化学习与可验证奖励（RLVR）</h3>
<p>传统 RLHF 依赖人类打分来训练奖励模型，但<strong>数学题和编程题有客观正确答案</strong>——不需要人类来判断，直接拿标准答案对比就行。这就是 <strong>RLVR（Reinforcement Learning with Verifiable Rewards）</strong>的思路：</p>
<ul>
<li><strong>可验证奖励</strong>：对数学题，答对给正奖励、答错给零或负奖励；对编程题，通过测试用例给正奖励。不需要训练奖励模型，奖励直接来自规则。</li>
<li><strong>训练方式</strong>：和 RLHF 一样用强化学习（如 PPO 或 GRPO），只是奖励信号从"奖励模型预测"变成了"规则判定"。</li>
<li><strong>优势</strong>：奖励信号准确、无人类偏见、可大规模自动运行。DeepSeek-R1 就是用 RLVR 训练出强推理能力的代表。</li>
</ul>
<div class="note">RLHF vs RLVR 的关键区别：RLHF 的奖励来自人类偏好（主观、需要奖励模型）；RLVR 的奖励来自客观验证（数学答案对错、代码是否通过测试）。RLVR 更适合推理任务。</div>

<h3>4.5.2 长思维链模型与普通模型的解题过程对比</h3>
<p>CCF 提纲要求理解"长思维链模型与普通模型的解题过程对比"。来看一个具体例子：</p>
<p><strong>题目：</strong>一个水池有两个进水管 A 和 B，A 单独注满需要 6 小时，B 单独注满需要 8 小时。如果两个管同时打开，几小时能注满？</p>
<p><strong>普通模型（无思维链）的输出：</strong></p>
<pre><code>两个管同时打开，需要 1/(1/6 + 1/8) = 1/(7/24) = 24/7 ≈ 3.43 小时。</code></pre>
<p>答案正确，但直接跳到公式，学生很难学到推理过程。</p>
<p><strong>长思维链模型（如 DeepSeek-R1）的输出：</strong></p>
<pre><code>让我一步步来算。

第一步：A 管每小时注入多少？
A 单独 6 小时注满，所以 A 每小时注入 1/6 的水池。

第二步：B 管每小时注入多少？
B 单独 8 小时注满，所以 B 每小时注入 1/8 的水池。

第三步：两管同时开，每小时注入多少？
1/6 + 1/8 = 4/24 + 3/24 = 7/24

第四步：注满需要多少小时？
水池总量是 1，每小时注入 7/24，所以需要：
1 ÷ (7/24) = 24/7 ≈ 3.43 小时

验证：3.43 小时内 A 注入 3.43/6 ≈ 0.572，B 注入 3.43/8 ≈ 0.429，
合计 ≈ 1.001，基本等于 1（水池注满），答案合理。

答案：约 3.43 小时（即 24/7 小时）。</code></pre>
<p>区别在于：长思维链模型<strong>把推理过程显式写出来</strong>，每一步都有依据，而且会自我验证。这种"先想清楚再回答"的能力，是通过 RLVR + 长思维链数据训练获得的。</p>

<h3>4.5.3 认知推理：感知、认知与推理的区别</h3>
<p>CCF 认证大纲提到"认知推理"，这里区分三个容易混淆的概念：</p>
<table class="tbl">
<thead><tr><th>能力</th><th>做什么</th><th>大模型中的例子</th></tr></thead>
<tbody>
<tr><td>感知（Perception）</td><td>接收并识别输入信号</td><td>把图像变成视觉特征（VLM）</td></tr>
<tr><td>认知（Cognition）</td><td>理解输入的含义和关系</td><td>读懂"这句话在问什么"</td></tr>
<tr><td>推理（Reasoning）</td><td>基于已知信息推导新结论</td><td>从前提推出结论（如数学证明）</td></tr>
</tbody>
</table>
<p>大模型在感知和认知上已经很强，但<strong>推理</strong>——尤其是需要多步逻辑链的推理——仍然是难点。长思维链训练（如 RLVR）正是为了强化这个能力。</p>
'''

html = html.replace(
    '<h2>4.6 幻觉与偏见</h2>',
    rlvr_section + '\n<h2>4.6 幻觉与偏见</h2>'
)

print(f"[Fix 3] Chapter 4: Added post-training overview, RLVR, Long-CoT comparison")

# ============================================================
# FIX 4: Expand Chapter 5 - Add decoding cases, model compression, deployment
# ============================================================
# Insert after section 5.2.1 (手感温度) and before 5.3 增量解码
ch5_expansion = '''
<h2>5.3 解码案例：一句诗的解码过程</h2>
<p>CCF 提纲要求"案例：一句诗的解码"。假设模型已经写出了"春风又绿江南岸"，现在要解码下一个词元。模型给出的 logits（原始分数）如下：</p>
<table class="tbl">
<thead><tr><th>候选词元</th><th>logits</th><th>贪心搜索选它吗？</th><th>T=0.8 采样选它吗？</th></tr></thead>
<tbody>
<tr><td>，</td><td>5.2</td><td>是（分数最高）</td><td>约 42% 概率</td></tr>
<tr><td>。</td><td>3.8</td><td>否</td><td>约 11% 概率</td></tr>
<tr><td>明月</td><td>3.5</td><td>否</td><td>约 8% 概率</td></tr>
<tr><td>春风</td><td>2.1</td><td>否</td><td>约 2% 概率</td></tr>
</tbody>
</table>
<p><strong>贪心搜索</strong>：直接选分数最高的"，"→ 输出"春风又绿江南岸，"。稳定、可复现，但所有结果千篇一律。</p>
<p><strong>束搜索（beam=2）</strong>：保留"，"和"。"两条路径，继续往下各解码两个候选，选累计概率最高的。可能得到"春风又绿江南岸，明月何时照我还"（因为"，明月"的累计概率高于"。"后续路径）。</p>
<p><strong>温度采样（T=0.8）</strong>：按概率分布随机抽——42% 抽到"，"，但也有 8% 抽到"明月"→ 可能输出"春风又绿江南岸明月……"。更有多样性，但可能不够通顺。</p>
<div class="note">实战选择：写代码 / 数学题用贪心或 T=0.1（确定性优先）；写诗 / 故事用 T=0.7~1.0（多样性优先）。翻译任务通常用束搜索。</div>

<h3>5.3.1 案例：一款翻译软件的解码切换</h3>
<p>CCF 提纲提到"案例：一款翻译软件的解码切换"。想象你在做一个翻译 App：</p>
<ul>
<li><strong>正式文档翻译</strong>（合同、论文）：用<strong>束搜索</strong>（beam=4~5），保证译文准确、通顺、可复现。同一句话翻两次结果一致。</li>
<li><strong>日常对话翻译</strong>：用<strong>温度采样</strong>（T=0.3~0.5 + top-p=0.9），允许细微的用词变化，更自然。</li>
<li><strong>创意文案翻译</strong>（广告、口号）：用<strong>高温采样</strong>（T=0.8~1.0），让模型大胆尝试不同表达，再人工挑选最好的。</li>
</ul>
<p>这个案例说明：<strong>解码策略不是"哪个更好"的问题，而是"哪个更适合当前任务"</strong>。</p>

<h2>5.4 模型压缩：让大模型跑在更小的机器上</h2>
<p>一个 7B 模型用 FP16 存储需要约 14 GB 显存——很多同学的个人电脑跑不动。模型压缩技术就是为了让大模型"瘦身"后还能跑。三种主流方法：</p>

<h3>5.4.1 量化（Quantization）</h3>
<p>把模型参数从高精度（FP32/FP16）压缩到低精度（INT8/INT4）。前面 3.7 已经讲过显存计算。这里补充量化方式的区别：</p>
<table class="tbl">
<thead><tr><th>方式</th><th>做法</th><th>适用场景</th></tr></thead>
<tbody>
<tr><td>对称量化</td><td>零点固定为 0，范围对称（如 [-127, 127]）</td><td>权重已接近零均值分布</td></tr>
<tr><td>非对称量化</td><td>零点可偏移，范围不对称（如 [0, 255]）</td><td>分布不对称（如激活值全正）</td></tr>
</tbody>
</table>

<h3>5.4.2 蒸馏（Knowledge Distillation）</h3>
<p>用一个大模型（<strong>教师模型</strong>）来训练一个小模型（<strong>学生模型</strong>）。学生不只学正确答案，还学教师模型的"软标签"——即教师对各个候选输出的概率分布。这样学生能学到教师"为什么这样选"的隐性知识。</p>
<pre><code># 蒸馏的核心思想（伪代码）
# 教师模型给出软标签（概率分布）
teacher_probs = softmax(teacher_logits / T)  # T 是温度，让分布更平滑

# 学生模型也给出自己的分布
student_probs = softmax(student_logits / T)

# 损失 = 硬标签损失 + 软标签损失
loss = alpha * cross_entropy(student_probs, true_label) + \
       (1 - alpha) * KL_divergence(student_probs, teacher_probs)</code></pre>

<h3>5.4.3 剪枝（Pruning）</h3>
<p>把模型里"贡献小"的参数或结构删掉。有两种粒度：</p>
<ul>
<li><strong>非结构化剪枝</strong>：逐个参数看，把接近零的权重设为零（变成稀疏矩阵）。理论上省存储，但普通硬件加速不明显。</li>
<li><strong>结构化剪枝</strong>：整行、整列或整个注意力头删掉。硬件加速效果好，但可能损失更多精度。</li>
</ul>
<div class="key-box">
<h4>认证要点</h4>
<ul>
<li>贪心搜索每步取最大概率，束搜索保留 B 条候选路径。</li>
<li>确定性任务用低温度/贪心；创意任务用高温度/采样；翻译常用束搜索。</li>
<li>模型压缩三件套：量化（降精度）、蒸馏（大教小）、剪枝（删冗余）。</li>
<li>蒸馏的"软标签"是教师模型的概率分布，比硬标签包含更多信息。</li>
</ul>
</div>
'''

html = html.replace(
    '<h2>5.3 增量解码与 KV Cache</h2>',
    ch5_expansion + '\n<h2>5.5 增量解码与 KV Cache</h2>'
)

# Renumber subsequent sections
html = html.replace(
    '<h2>5.4 量化与吞吐量</h2>',
    '<h2>5.6 量化与吞吐量</h2>'
)
html = html.replace(
    '<h3>计算工坊 5-1：吞吐量要算周期同步</h3>',
    '<h3>计算工坊 5-2：吞吐量要算周期同步</h3>'
)

print(f"[Fix 4] Chapter 5: Added decoding cases, model compression, deployment")

# ============================================================
# FIX 5: Expand Chapter 2 - Add architecture comparison case + masking
# ============================================================
# Read current chapter 2 section 2.4 三类架构 area
ch2_expansion = '''
<h3>2.4.1 三种架构的适用场景对比</h3>
<p>CCF 提纲要求"案例：三种架构的适用场景对比"。三种主流架构各有强项：</p>
<table class="tbl">
<thead><tr><th>架构</th><th>代表模型</th><th>注意力方向</th><th>最擅长</th><th>不擅长</th></tr></thead>
<tbody>
<tr><td>编码器（Encoder-only）</td><td>BERT</td><td>双向（能看到全文）</td><td>理解类任务：分类、问答、实体识别</td><td>生成（不会"续写"）</td></tr>
<tr><td>解码器（Decoder-only）</td><td>GPT、Qwen、DeepSeek</td><td>因果（只看前文）</td><td>生成类任务：对话、续写、推理</td><td>需要双向理解的任务</td></tr>
<tr><td>编码器-解码器</td><td>T5、原始 Transformer</td><td>编码器双向 + 解码器因果</td><td>序列到序列：翻译、摘要</td><td>通用对话（参数利用率不如纯解码器）</td></tr>
</tbody>
</table>
<p>为什么现在主流大模型（GPT、Qwen、DeepSeek）都选<strong>因果解码器</strong>？因为它天然适合"给前文续写"的自回归训练，训练和推理逻辑统一，而且扩大规模后理解和生成能力都能涌现——不需要额外加编码器。</p>

<h3>2.4.2 以 Qwen2-7B 为例解读因果解码器架构</h3>
<p>CCF 提纲要求"案例：以 Qwen2-7B 为例解读因果解码器架构"。Qwen2-7B 是阿里巴巴开源的 70 亿参数大语言模型，采用纯因果解码器架构：</p>
<ul>
<li><strong>层数</strong>：28 层 Transformer 块（每个块包含多头自注意力 + 前馈网络）。</li>
<li><strong>隐藏维度</strong>：3584（每个词元被表示为一个 3584 维向量）。</li>
<li><strong>注意力头数</strong>：28 个 Query 头，使用 GQA（分组查询注意力），KV 头数为 4（每 7 个 Q 头共享 1 组 KV）。</li>
<li><strong>词表大小</strong>：152064（支持中英文及多种语言）。</li>
<li><strong>上下文窗口</strong>：原生 32768 词元，可通过 YaRN 扩展到 131072。</li>
</ul>
<pre><code># Qwen2-7B 的参数量估算（近似）
# 嵌入层: 152064 × 3584 ≈ 545M
# 每层注意力 (Q/K/V/O 投影): 4 × 3584 × 3584 ≈ 51M (GQA 实际 KV 更小)
# 每层 FFN (中间维度 ~18944): 3 × 3584 × 18944 ≈ 204M (SwiGLU 有 3 个矩阵)
# 28 层总计 ≈ (51 + 204) × 28 ≈ 7.1B
# 加上嵌入层和输出层 ≈ 7.6B (与官方 7.6B 一致)
num_layers = 28
hidden = 3584
intermediate = 18944  # FFN 中间维度
attn_per_layer = 4 * hidden * hidden  # 近似
ffn_per_layer = 3 * hidden * intermediate  # SwiGLU: gate, up, down
total = num_layers * (attn_per_layer + ffn_per_layer)
print(f"约 {total / 1e9:.1f}B 参数 (不含嵌入层)")  # 约 7.1B</code></pre>

<h3>2.5.1 掩码机制：因果掩码与填充掩码</h3>
<p>掩码（Masking）是 Transformer 里的关键设计，有两种常见掩码：</p>
<ul>
<li><strong>因果掩码（Causal Mask）</strong>：在解码器里，位置 i 只能看到位置 0~i，看不到未来的词元。实现上把注意力矩阵的上三角部分设为负无穷，softmax 后变成零。这就是"因果"的来源——当前词元的表示只依赖它自己和之前的词元。</li>
<li><strong>填充掩码（Padding Mask）</strong>：一个 batch 里不同序列长度不一，短的用特殊 token 填充。填充位置不应该参与注意力计算，所以在注意力矩阵里把填充位置设为负无穷。</li>
</ul>
<div class="note">认证常考：因果解码器（如 GPT/Qwen）使用因果掩码确保自回归生成——位置 i 只能看到前文，看不到后文。这是"生成"任务的基础。</div>
'''

# Insert after 2.4 三类架构 section and before 2.5 高效推理
html = html.replace(
    '<h2>2.5 高效推理的几个关键设计</h2>',
    ch2_expansion + '\n<h2>2.6 高效推理的几个关键设计</h2>'
)
# Renumber 2.6 为什么长序列 to 2.7
html = html.replace(
    '<h2>2.6 为什么长序列特别贵</h2>',
    '<h2>2.7 为什么长序列特别贵</h2>'
)

print(f"[Fix 5] Chapter 2: Added architecture comparison, Qwen2-7B example, masking")

# ============================================================
# Write the updated HTML
# ============================================================
with open(HTML_PATH, 'w', encoding='utf-8') as f:
    f.write(html)

new_len = len(html)
print(f"\nDone! HTML updated: {original_len} -> {new_len} chars (+{new_len - original_len})")

# Quick validation
svg_count = html.count('<svg')
fig_count = html.count('<figure')
pre_count = html.count('<pre>')
pre_close = html.count('</pre>')
code_count = html.count('<code>')
code_close = html.count('</code>')
print(f"SVG: {svg_count}, Figure: {fig_count}, pre: {pre_count}/{pre_close}, code: {code_count}/{code_close}")
