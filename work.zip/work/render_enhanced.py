# -*- coding: utf-8 -*-
"""LMCC 青少年组教材-增强版 · HTML(KaTeX) → PDF (A4) 渲染器

关键：KaTeX 渲染的公式依赖本地 woff2 字体（work/katex/fonts/）。
若不显式等待字体加载完成就 page.pdf()，数学字形会变成乱码。
本渲染器用 load + 显式 document.fonts.load() 强制加载 KaTeX 全套字体后再出 PDF。
"""
import os
from playwright.sync_api import sync_playwright

BASE = os.path.dirname(os.path.abspath(__file__))
HTML = os.path.join(BASE, "..", "LMCC青少年组教材-增强版.html")
OUT = os.path.join(BASE, "..", "LMCC青少年组教材-增强版.pdf")

# KaTeX 用到的全部字体族（与 work/katex/katex.min.css 的 @font-face 对应）
KATEX_FONTS = [
    "KaTeX_Main", "KaTeX_Math", "KaTeX_AMS", "KaTeX_Caligraphic",
    "KaTeX_Fraktur", "KaTeX_SansSerif", "KaTeX_Script",
    "KaTeX_Size1", "KaTeX_Size2", "KaTeX_Size3", "KaTeX_Size4",
    "KaTeX_Typewriter",
]

FORCE_FONTS_JS = """async () => {
    const fams = %s;
    // 显式触发每个字体的加载，等全部就绪
    await Promise.all(fams.map(f => document.fonts.load("16px " + f).catch(() => {})));
    await document.fonts.ready;
    // 再等一帧让布局稳定
    await new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)));
    return document.fonts.status;
}""" % repr(KATEX_FONTS)

def main():
    with sync_playwright() as p:
        browser = p.chromium.launch(args=["--no-sandbox"])
        page = browser.new_page()
        page.set_default_timeout(60000)
        # load：等 DOM 与 defer 脚本就绪（KaTeX 在 DOMContentLoaded 时已 typeset）
        page.goto("file://" + os.path.abspath(HTML), wait_until="load")
        # 等 KaTeX 渲染产物出现
        try:
            page.wait_for_selector(".katex", timeout=20000)
        except Exception:
            print("warn: 未检测到 KaTeX 渲染产物（可能无公式或本地 katex 缺失）")
        # ★ 核心：强制加载 KaTeX 全套字体并等待就绪，防止 PDF 里数学字形乱码
        try:
            st = page.evaluate(FORCE_FONTS_JS)
            print("fonts status:", st)
        except Exception as e:
            print("warn: 字体强制加载异常:", e)
        page.wait_for_timeout(1500)
        page.pdf(
            path=os.path.abspath(OUT),
            format="A4",
            print_background=True,
            prefer_css_page_size=True,
            display_header_footer=True,
            header_template='<div style="font-size:0;"></div>',
            footer_template=(
                '<div style="font-size:9px; width:100%; text-align:center;'
                ' color:#888; padding:0 16mm;">'
                '<span class="pageNumber"></span>'
                ' / '
                '<span class="totalPages"></span>'
                '</div>'
            ),
            margin={"top": "18mm", "bottom": "18mm",
                    "left": "16mm", "right": "16mm"},
        )
        browser.close()
    size = os.path.getsize(OUT)
    print(f"已生成 PDF：{OUT}  ({size/1024:.0f} KB)")

if __name__ == "__main__":
    main()
