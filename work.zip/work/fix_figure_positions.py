# -*- coding: utf-8 -*-
"""
Fix figure positions in the textbook HTML.
Move misplaced figures to their correct sections.
"""
import re
import os

BASE = r"C:\Users\MINXIN\Desktop\CCF LMCC"
HTML = os.path.join(BASE, "LMCC青少年组教材-增强版.html")

with open(HTML, "r", encoding="utf-8") as f:
    html = f.read()

def find_figure_block(html, caption_text):
    """Find the complete <figure>...</figure> block containing the caption."""
    cap_pos = html.find(caption_text)
    if cap_pos < 0:
        return None, None
    fig_start = html.rfind("<figure", 0, cap_pos)
    fig_end = html.find("</figure>", cap_pos)
    if fig_end >= 0:
        fig_end += len("</figure>")
    return fig_start, fig_end

def find_insertion_point(html, after_text, end_marker=None):
    """Find a position to insert a figure after a specific text."""
    pos = html.find(after_text)
    if pos < 0:
        return None
    # Find the end of the current element (paragraph, list, etc.)
    if end_marker:
        end_pos = html.find(end_marker, pos)
        if end_pos >= 0:
            return end_pos + len(end_marker)
    return pos

changes = []

# ============================================================
# Fix 1: Move 图1-4 (涌现能力) to section 1.4.4
# Currently: after 图1-3, before section 1.4 heading
# Should be: in section 1.4.4, after the 涌现能力 discussion
# ============================================================
fig14_start, fig14_end = find_figure_block(html, "图 1-4 涌现能力")
if fig14_start and fig14_end:
    fig14_html = html[fig14_start:fig14_end]
    
    # Find insertion point: after the </ul> that ends the 涌现能力 discussion in 1.4.4
    # The discussion ends with the list of features (涌现能力, 统一架构, 通用助手)
    emergence_list_end = html.find("</ul>", html.find("通用助手</strong>", fig14_end))
    if emergence_list_end >= 0:
        emergence_list_end += len("</ul>")
        # Remove from old position
        html = html[:fig14_start] + html[fig14_end:]
        # Recalculate insertion point (positions shifted after removal)
        # Find again in modified html
        emergence_list_end_new = html.find("</ul>", html.find("通用助手</strong>"))
        if emergence_list_end_new >= 0:
            emergence_list_end_new += len("</ul>")
            # Insert at new position
            html = html[:emergence_list_end_new] + "\n\n" + fig14_html + "\n" + html[emergence_list_end_new:]
            changes.append("图1-4 (涌现能力): moved to section 1.4.4 after 涌现能力 discussion")
    else:
        changes.append("图1-4: WARNING - could not find insertion point in 1.4.4")
else:
    changes.append("图1-4: WARNING - figure block not found")

# ============================================================
# Fix 2: Move 图1-1 (三种学习方式) to section 1.1
# Currently: before section 1.1 heading (in section 1.0 area)
# Should be: inside section 1.1, after the intro text
# ============================================================
fig11_start, fig11_end = find_figure_block(html, "图 1-1 三种学习方式")
if fig11_start and fig11_end:
    fig11_html = html[fig11_start:fig11_end]
    
    # Find section 1.1 heading
    s11_pos = html.find("<h2>1.1 三种学习方式</h2>")
    if s11_pos >= 0:
        # Find the first paragraph after 1.1 heading
        # Insert after the intro paragraph
        intro_end = html.find("</p>", s11_pos + 100)
        if intro_end >= 0:
            intro_end += len("</p>")
            # Check if figure is already after 1.1
            if fig11_start < s11_pos:
                # Remove from old position
                html = html[:fig11_start] + html[fig11_end:]
                # Recalculate positions
                s11_pos_new = html.find("<h2>1.1 三种学习方式</h2>")
                intro_end_new = html.find("</p>", s11_pos_new + 100) + len("</p>")
                # Insert at new position
                html = html[:intro_end_new] + "\n\n" + fig11_html + "\n" + html[intro_end_new:]
                changes.append("图1-1 (三种学习方式): moved to section 1.1 after intro paragraph")
            else:
                changes.append("图1-1: already in correct position")
else:
    changes.append("图1-1: WARNING - figure block not found")

# ============================================================
# Fix 3: Move 图1-3 (语言模型四个阶段) to section 1.4 area
# Currently: in section 1.3.1 (before section 1.4)
# Should be: at the beginning of section 1.4
# ============================================================
fig13_start, fig13_end = find_figure_block(html, "图 1-3 语言模型发展")
if fig13_start and fig13_end:
    fig13_html = html[fig13_start:fig13_end]
    
    # Find section 1.4 heading
    s14_pos = html.find("<h2>1.4 语言模型发展的四个阶段</h2>")
    if s14_pos >= 0:
        # Find the first paragraph after 1.4 heading
        para_end = html.find("</p>", s14_pos + 100)
        if para_end >= 0:
            para_end += len("</p>")
            # Check if figure is before 1.4
            if fig13_start < s14_pos:
                # Remove from old position
                html = html[:fig13_start] + html[fig13_end:]
                # Recalculate
                s14_pos_new = html.find("<h2>1.4 语言模型发展的四个阶段</h2>")
                para_end_new = html.find("</p>", s14_pos_new + 100) + len("</p>")
                # Insert at new position
                html = html[:para_end_new] + "\n\n" + fig13_html + "\n" + html[para_end_new:]
                changes.append("图1-3 (语言模型四个阶段): moved to section 1.4 after intro paragraph")
            else:
                changes.append("图1-3: already in correct position")
else:
    changes.append("图1-3: WARNING - figure block not found")

# ============================================================
# Fix 4: Move 图5-1 (温度) to section 5.2
# Currently: at end of section 4.6 (before section 5.1)
# Should be: in section 5.2 (温度、top-k、top-p)
# ============================================================
fig51_start, fig51_end = find_figure_block(html, "图 5-1 温度")
if fig51_start and fig51_end:
    fig51_html = html[fig51_start:fig51_end]
    
    # Find section 5.2 heading
    s52_pos = html.find("<h2>5.2 温度、top-k、top-p 怎么配合</h2>")
    if s52_pos >= 0:
        # Find the first paragraph after 5.2 heading
        para_end = html.find("</p>", s52_pos + 100)
        if para_end >= 0:
            para_end += len("</p>")
            # Check if figure is before 5.2
            if fig51_start < s52_pos:
                # Remove from old position
                html = html[:fig51_start] + html[fig51_end:]
                # Recalculate
                s52_pos_new = html.find("<h2>5.2 温度、top-k、top-p 怎么配合</h2>")
                para_end_new = html.find("</p>", s52_pos_new + 100) + len("</p>")
                # Insert at new position
                html = html[:para_end_new] + "\n\n" + fig51_html + "\n" + html[para_end_new:]
                changes.append("图5-1 (温度): moved to section 5.2 after intro paragraph")
            else:
                changes.append("图5-1: already in correct position")
else:
    changes.append("图5-1: WARNING - figure block not found")

# Write updated HTML
with open(HTML, "w", encoding="utf-8") as f:
    f.write(html)

print("=== Figure position fixes ===")
for c in changes:
    print(f"  {c}")
print(f"\nHTML size: {len(html)} chars")
