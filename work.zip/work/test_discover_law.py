import math
points = [(0.39, 0.24), (0.72, 0.62), (1.00, 1.00), (1.52, 1.88), (5.20, 11.86)]
xs = [math.log(a) for a, _ in points]
ys = [math.log(t) for _, t in points]
n = len(xs)
mx = sum(xs) / n; my = sum(ys) / n
num = sum((x - mx) * (y - my) for x, y in zip(xs, ys))
den = sum((x - mx) ** 2 for x in xs)
k = num / den
print(f"拟合得到 T 正比于 a^{k:.3f}（理论值 1.5）")
