# -*- coding: utf-8 -*-
"""LMCC 青少年组教材 · HTML → PDF (A4) 渲染器"""
import os
from playwright.sync_api import sync_playwright

BASE = os.path.dirname(os.path.abspath(__file__))
HTML = os.path.join(BASE, "..", "LMCC青少年组教材.html")
OUT = os.path.join(BASE, "..", "LMCC青少年组教材.pdf")

def main():
    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page()
        page.goto("file://" + os.path.abspath(HTML), wait_until="networkidle")
        # 等字体/布局稳定 + KaTeX 渲染完成
        page.evaluate("() => document.fonts && document.fonts.ready")
        try:
            page.wait_for_selector(".katex", timeout=5000)
        except Exception:
            pass
        page.wait_for_timeout(1500)
        page.pdf(
            path=os.path.abspath(OUT),
            format="A4",
            print_background=True,
            prefer_css_page_size=True,
            margin={"top": "16mm", "bottom": "16mm",
                    "left": "16mm", "right": "16mm"},
        )
        browser.close()
    size = os.path.getsize(OUT)
    print(f"已生成 PDF：{OUT}  ({size/1024:.0f} KB)")

if __name__ == "__main__":
    main()
