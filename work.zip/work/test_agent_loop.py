import math

def search_books(category):
    db = {"科幻": "《三体》", "历史": "《明朝那些事儿》"}
    return db.get(category, "未找到")

def get_summary(title):
    return f"{title}：一部广受好评的作品。"

def fake_model(goal, memory):
    if "推荐" in goal and "book" not in memory:
        return ("call", "search_books", {"category": "科幻"})
    if "book" in memory and "summary" not in memory:
        return ("call", "get_summary", {"title": memory["book"]})
    return ("done", None, None)

memory = {}
turn = 0
while turn < 5:
    turn += 1
    action, tool, args = fake_model("推荐一本科幻书", memory)
    if action == "done":
        break
    if tool == "search_books":
        result = search_books(**args)
        memory["book"] = result
        print(f"[行动] 调用 search_books → {result}")
    elif tool == "get_summary":
        result = get_summary(**args)
        memory["summary"] = result
        print(f"[行动] 调用 get_summary → {result}")
    print(f"[记忆] {memory}\n")

print("最终回答：", memory.get("summary", "（未完成）"))
