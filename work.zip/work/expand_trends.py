# -*- coding: utf-8 -*-
"""LMCC 青少年组教材-增强版：补充 2026 前沿趋势 + 可复现实战案例。

注入位置（均用唯一锚点做切片/替换，避免整段脆弱匹配）：
  1) §1.4.3 正文重写：融入 GPT-5.6 / Claude Fable 5 / ChatGPT Images 2.0
  2) 在 图 1-11 之后插入 §1.4.4《2026 年中前沿速览》+ 图 1-12 演进时间线
  3) 在第 9 章“小白课堂”笔记之后、本章要点之前插入 §9.12《智能体工程前沿》+ 图 9-4~9-7 + 离线可跑的 ReAct 智能体循环
  4) 在第 10 章 图 10-2 之后、本章要点之前插入 §10.8《世界模型》+ §10.9《AI4S》+ 图 10-3/10-4 + 离线可跑的“定律发现”演示，并向第 10 章要点追加两条
"""
import os
import xml.dom.minidom as minidom

BASE = os.path.dirname(os.path.abspath(__file__))
HTML_PATH = os.path.join(BASE, "..", "LMCC青少年组教材-增强版.html")

# 统一配色（与既有教材一致）
BLUE, ORANGE, GREEN, PURPLE = "#2c5f8a", "#c1572f", "#3a7d44", "#6a4c93"
PANEL, BORDER, INK, MUTE, RED = "#f4f7fa", "#cfd6dd", "#1a1a1a", "#5b6770", "#d13c3c"
FONT = "Noto Sans CJK SC,Microsoft YaHei,PingFang SC,sans-serif"


def svg_open(h, title):
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 840 {h}" width="840" '
            f'font-family=\'{FONT}\' font-size="15" fill="{INK}">'
            f'<rect x="0" y="0" width="840" height="{h}" fill="white"/>'
            f'<text x="420" y="32" text-anchor="middle" font-size="16" font-weight="600">{title}</text>')


def fig(svg, cap):
    return f'<figure class="textbook-fig">{svg}\n<figcaption>{cap}</figcaption></figure>'


# ---------------------------------------------------------------------------
# 图 1-12：大模型能力演进时间线（2024 – 2026）
# ---------------------------------------------------------------------------
def fig_1_12():
    s = svg_open(400, "大模型能力演进时间线（2024 – 2026）")
    # 主轴线
    s += '<line x1="70" y1="215" x2="790" y2="215" stroke="#1a1a1a" stroke-width="2"/>'
    s += '<circle cx="160" cy="215" r="9" fill="#9aa5b0"/><circle cx="420" cy="215" r="9" fill="#2c5f8a"/><circle cx="700" cy="215" r="9" fill="#c1572f"/>'
    s += '<text x="160" y="240" text-anchor="middle" font-size="15" font-weight="600" fill="#9aa5b0">2024</text>'
    s += '<text x="420" y="240" text-anchor="middle" font-size="15" font-weight="600" fill="#2c5f8a">2025</text>'
    s += '<text x="700" y="240" text-anchor="middle" font-size="15" font-weight="600" fill="#c1572f">2026</text>'
    # 2024 卡片
    for i, (txt, y) in enumerate([("GPT-4o（OpenAI）", 150), ("Llama 3（开源）", 110)]):
        yy = y
        s += f'<rect x="90" y="{yy}" width="150" height="32" rx="7" fill="#eef3f8" stroke="#9aa5b0" stroke-width="1.2"/>'
        s += f'<text x="165" y="{yy+21}" text-anchor="middle" font-size="12.5" fill="#1a1a1a">{txt}</text>'
        s += f'<line x1="165" y1="{yy+32}" x2="160" y2="206" stroke="#cfd6dd" stroke-width="1"/>'
    # 2025 卡片
    for i, (txt, y) in enumerate([("DeepSeek-R1（低成本开源）", 150), ("Qwen2.5（阿里）", 110)]):
        yy = y
        s += f'<rect x="345" y="{yy}" width="170" height="32" rx="7" fill="#eef3f8" stroke="#2c5f8a" stroke-width="1.2"/>'
        s += f'<text x="430" y="{yy+21}" text-anchor="middle" font-size="12.5" fill="#1a1a1a">{txt}</text>'
        s += f'<line x1="430" y1="{yy+32}" x2="420" y2="206" stroke="#cfd6dd" stroke-width="1"/>'
    # 2026 卡片（更宽）
    items26 = [
        ("GPT-5.6（Sol / Terra / Luna）", 175),
        ("Claude Fable 5（Mythos 级）", 137),
        ("gpt-image-2（图像会思考）", 99),
        ("OpenClaw · Hermes（开源智能体）", 61),
        ("世界模型 · AI4S（科研新范式）", 23),
    ]
    for txt, yy in items26:
        s += f'<rect x="598" y="{yy}" width="200" height="32" rx="7" fill="#fdecec" stroke="#c1572f" stroke-width="1.2"/>'
        s += f'<text x="698" y="{yy+21}" text-anchor="middle" font-size="12" fill="#1a1a1a">{txt}</text>'
        s += f'<line x1="698" y1="{yy+32}" x2="700" y2="206" stroke="#f3c3bd" stroke-width="1"/>'
    s += '<text x="420" y="285" text-anchor="middle" font-size="12.5" fill="#5b6770">能力边界从“文本对话”一路外扩到“图像生成、自主智能体、物理世界理解与科学发现”</text>'
    s += '<text x="420" y="312" text-anchor="middle" font-size="12.5" fill="#5b6770">竞争焦点也从“谁更聪明”转向“谁更便宜、更可靠、更适合真实任务”</text>'
    s += "</svg>"
    return fig(s, "图 1-12 大模型能力演进时间线（2024 – 2026）")


# ---------------------------------------------------------------------------
# 图 9-4：智能体工程四层抽象（俄罗斯套娃）
# ---------------------------------------------------------------------------
def fig_9_4():
    h = 360
    s = svg_open(h, "智能体工程四层抽象：从写提示词到设计循环")
    # ④ Loop（最外层）
    s += '<rect x="50" y="40" width="740" height="290" rx="16" fill="#fdecec" stroke="#c1572f" stroke-width="2"/>'
    s += '<text x="66" y="66" font-size="14" font-weight="600" fill="#c1572f">④ Loop Engineering（设计循环：让 Agent 自己跑）</text>'
    s += '<text x="66" y="312" font-size="12" fill="#5b6770">解决：很多任务怎么自动、跨时间地一直做下去</text>'
    # ③ Harness
    s += '<rect x="110" y="82" width="620" height="206" rx="14" fill="#eef3f8" stroke="#2c5f8a" stroke-width="2"/>'
    s += '<text x="126" y="108" font-size="14" font-weight="600" fill="#2c5f8a">③ Harness Engineering（搭运行环境：沙箱 / 监控 / 降级）</text>'
    s += '<text x="126" y="274" font-size="12" fill="#5b6770">解决：Agent 怎么稳定跑完不翻车</text>'
    # ② Context
    s += '<rect x="170" y="124" width="500" height="122" rx="12" fill="#e7f3ec" stroke="#3a7d44" stroke-width="2"/>'
    s += '<text x="186" y="150" font-size="14" font-weight="600" fill="#3a7d44">② Context Engineering（管上下文：RAG / 记忆）</text>'
    s += '<text x="186" y="234" font-size="12" fill="#5b6770">解决：让 Agent 看见该看的信息</text>'
    # ① Prompt（最内层）
    s += '<rect x="230" y="166" width="380" height="40" rx="10" fill="#f1ecf8" stroke="#6a4c93" stroke-width="2"/>'
    s += '<text x="246" y="191" font-size="13.5" font-weight="600" fill="#6a4c93">① Prompt Engineering（写好一次提示）</text>'
    s += "</svg>"
    return fig(s, "图 9-4 智能体工程四层抽象：Prompt → Context → Harness → Loop")


# ---------------------------------------------------------------------------
# 图 9-5：一个 Loop 的嵌套结构（外循环 → 内循环 → 最内核）
# ---------------------------------------------------------------------------
def fig_9_5():
    h = 400
    s = svg_open(h, "一个 Loop 的嵌套结构：外循环驱动，内循环执行")
    # 外循环
    s += '<rect x="60" y="70" width="720" height="250" rx="16" fill="none" stroke="#c1572f" stroke-width="2" stroke-dasharray="8,5"/>'
    s += '<text x="78" y="96" font-size="14" font-weight="600" fill="#c1572f">外循环 Loop Engineering（定时跑、自我喂料、派生帮手）</text>'
    # 五个动作
    moves = [("发现", 95), ("分发", 235), ("核验", 375), ("记忆", 505), ("调度", 635)]
    for name, x in moves:
        s += f'<rect x="{x}" y="300" width="120" height="34" rx="8" fill="#fdecec" stroke="#c1572f" stroke-width="1.2"/>'
        s += f'<text x="{x+60}" y="322" text-anchor="middle" font-size="13" fill="#1a1a1a">{name}</text>'
    # 内循环
    s += '<rect x="140" y="120" width="560" height="150" rx="14" fill="#eef3f8" stroke="#2c5f8a" stroke-width="2"/>'
    s += '<text x="158" y="146" font-size="14" font-weight="600" fill="#2c5f8a">内循环 DeepAgent / Harness（一个复杂任务怎么做完做稳）</text>'
    # 最内核 ReAct
    s += '<rect x="250" y="168" width="340" height="70" rx="12" fill="#e7f3ec" stroke="#3a7d44" stroke-width="2"/>'
    s += '<text x="420" y="196" text-anchor="middle" font-size="14" font-weight="600" fill="#3a7d44">最内核 ReAct</text>'
    s += '<text x="420" y="220" text-anchor="middle" font-size="13" fill="#1a1a1a">思考 → 行动 → 观察（循环往复）</text>'
    # 循环箭头
    s += '<path d="M 400 330 Q 420 360 450 335" fill="none" stroke="#c1572f" stroke-width="2" marker-end="url(#ahL)"/>'
    s += '<defs><marker id="ahL" markerWidth="10" markerHeight="10" refX="7" refY="3.5" orient="auto"><path d="M0,0 L7,3.5 L0,7 z" fill="#c1572f"/></marker></defs>'
    s += '<text x="455" y="352" font-size="12" fill="#c1572f">循环往复，直到目标达成</text>'
    s += "</svg>"
    return fig(s, "图 9-5 一个 Loop 的嵌套结构：外循环 → 内循环 → 最内核 ReAct")


# ---------------------------------------------------------------------------
# 图 9-6：OpenClaw / Hermes 智能体四模块
# ---------------------------------------------------------------------------
def fig_9_6():
    h = 360
    s = svg_open(h, "开源智能体的典型结构：四模块 + 本地记忆")
    cx, cy = 420, 190
    s += f'<circle cx="{cx}" cy="{cy}" r="64" fill="#eef3f8" stroke="#1a1a1a" stroke-width="2"/>'
    s += f'<text x="{cx}" y="{cy-4}" text-anchor="middle" font-size="14" font-weight="600" fill="#1a1a1a">智能体</text>'
    s += f'<text x="{cx}" y="{cy+16}" text-anchor="middle" font-size="13" fill="#1a1a1a">内核</text>'
    mods = [
        ("渠道适配器", "WhatsApp / 微信 / 飞书", 340, 50, BLUE),
        ("决策核心", "灵活切换大模型", 640, 160, ORANGE),
        ("技能插件 Skills", "控制浏览器 / 邮件 / 代码", 340, 300, GREEN),
        ("双模记忆", "本地 Markdown 长期记忆", 60, 160, PURPLE),
    ]
    for name, sub, x, y, col in mods:
        s += f'<rect x="{x}" y="{y}" width="160" height="60" rx="12" fill="white" stroke="{col}" stroke-width="2"/>'
        s += f'<text x="{x+80}" y="{y+26}" text-anchor="middle" font-size="13.5" font-weight="600" fill="{col}">{name}</text>'
        s += f'<text x="{x+80}" y="{y+46}" text-anchor="middle" font-size="11" fill="#5b6770">{sub}</text>'
        s += f'<line x1="{x+80}" y1="{y+ (60 if y>cy else 0)}" x2="{cx}" y2="{cy}" stroke="{col}" stroke-width="1.4"/>'
    s += '<text x="420" y="350" text-anchor="middle" font-size="12" fill="#5b6770">代表项目：OpenClaw（本地运行的个人智能体）、Hermes Agent（内置技能与跨会话记忆的“会成长的智能体”）</text>'
    s += "</svg>"
    return fig(s, "图 9-6 开源智能体的典型结构：四模块 + 本地记忆")


# ---------------------------------------------------------------------------
# 图 9-7：生成器 / 评估器分离
# ---------------------------------------------------------------------------
def fig_9_7():
    h = 300
    s = svg_open(h, "生成器与评估器分离：让“挑剔的考官”来打分")
    # 生成器
    s += '<rect x="60" y="120" width="190" height="74" rx="12" fill="#eef3f8" stroke="#2c5f8a" stroke-width="2"/>'
    s += '<text x="155" y="150" text-anchor="middle" font-size="14" font-weight="600" fill="#2c5f8a">模型生成</text>'
    s += '<text x="155" y="174" text-anchor="middle" font-size="12" fill="#5b6770">Generator</text>'
    s += '<line x1="250" y1="157" x2="320" y2="157" stroke="#1a1a1a" stroke-width="2" marker-end="url(#ah7a)"/>'
    # 评估器
    s += '<rect x="320" y="110" width="210" height="94" rx="12" fill="#fdecec" stroke="#c1572f" stroke-width="2"/>'
    s += '<text x="425" y="142" text-anchor="middle" font-size="14" font-weight="600" fill="#c1572f">独立评估器</text>'
    s += '<text x="425" y="166" text-anchor="middle" font-size="12" fill="#5b6770">Skeptical Evaluator</text>'
    s += '<text x="425" y="188" text-anchor="middle" font-size="11.5" fill="#5b6770">（挑剔打分，不偏袒自己）</text>'
    s += '<defs><marker id="ah7a" markerWidth="10" markerHeight="10" refX="7" refY="3.5" orient="auto"><path d="M0,0 L7,3.5 L0,7 z" fill="#1a1a1a"/></marker>'
    s += '<marker id="ah7b" markerWidth="10" markerHeight="10" refX="7" refY="3.5" orient="auto"><path d="M0,0 L7,3.5 L0,7 z" fill="#3a7d44"/></marker>'
    s += '<marker id="ah7c" markerWidth="10" markerHeight="10" refX="7" refY="3.5" orient="auto"><path d="M0,0 L7,3.5 L0,7 z" fill="#c1572f"/></marker></defs>'
    # 分流
    s += '<line x1="530" y1="140" x2="600" y2="100" stroke="#3a7d44" stroke-width="2" marker-end="url(#ah7b)"/>'
    s += '<line x1="530" y1="174" x2="600" y2="220" stroke="#c1572f" stroke-width="2" marker-end="url(#ah7c)"/>'
    # 通过 / 打回
    s += '<rect x="600" y="66" width="190" height="60" rx="12" fill="#e7f3ec" stroke="#3a7d44" stroke-width="2"/>'
    s += '<text x="695" y="100" text-anchor="middle" font-size="13.5" font-weight="600" fill="#3a7d44">通过（进入下一轮 / 交付）</text>'
    s += '<rect x="600" y="190" width="190" height="60" rx="12" fill="#fbeee6" stroke="#c1572f" stroke-width="2"/>'
    s += '<text x="695" y="224" text-anchor="middle" font-size="13.5" font-weight="600" fill="#c1572f">打回（重新生成）</text>'
    s += '<line x1="600" y1="220" x2="250" y2="160" stroke="#c1572f" stroke-width="1.6" stroke-dasharray="6,4" marker-end="url(#ah7c)"/>'
    s += '<text x="420" y="290" text-anchor="middle" font-size="12" fill="#5b6770">模型自己给自己的作业打分往往偏宽松；独立的评估器更可靠——这正是 Loop Engineering 强调分离的原因。</text>'
    s += "</svg>"
    return fig(s, "图 9-7 生成器与评估器分离：用独立的“挑剔考官”把关质量")


# ---------------------------------------------------------------------------
# 图 10-3：世界模型（NTP → NSP + 三条路径）
# ---------------------------------------------------------------------------
def fig_10_3():
    h = 430
    s = svg_open(h, "世界模型：从“预测下一个词”到“预测下一物理状态”")
    # 顶部两个大卡
    s += '<rect x="60" y="64" width="340" height="92" rx="12" fill="#eef3f8" stroke="#2c5f8a" stroke-width="2"/>'
    s += '<text x="230" y="96" text-anchor="middle" font-size="14" font-weight="600" fill="#2c5f8a">传统大模型 LLM</text>'
    s += '<text x="230" y="122" text-anchor="middle" font-size="12.5" fill="#1a1a1a">Next Token Prediction</text>'
    s += '<text x="230" y="144" text-anchor="middle" font-size="12" fill="#5b6770">预测下一个词（语言统计）</text>'
    s += '<rect x="440" y="64" width="340" height="92" rx="12" fill="#fdecec" stroke="#c1572f" stroke-width="2"/>'
    s += '<text x="610" y="96" text-anchor="middle" font-size="14" font-weight="600" fill="#c1572f">世界模型 World Model</text>'
    s += '<text x="610" y="122" text-anchor="middle" font-size="12.5" fill="#1a1a1a">Next State Prediction</text>'
    s += '<text x="610" y="144" text-anchor="middle" font-size="12" fill="#5b6770">预测下一物理状态（时空因果）</text>'
    s += '<line x1="400" y1="110" x2="440" y2="110" stroke="#1a1a1a" stroke-width="2" marker-end="url(#ahW)"/>'
    s += '<defs><marker id="ahW" markerWidth="10" markerHeight="10" refX="7" refY="3.5" orient="auto"><path d="M0,0 L7,3.5 L0,7 z" fill="#1a1a1a"/></marker></defs>'
    s += '<text x="420" y="56" text-anchor="middle" font-size="12" fill="#5b6770">范式迁移</text>'
    # 三条路径
    paths = [
        ("JEPA（杨立昆）", "预测抽象潜空间特征，忽略无关背景；适合实时推理（机器人 / 自动驾驶）", 60, BLUE),
        ("高斯泼溅 Gaussian Splats", "从提示生成 3D 高斯场景，可导入物理引擎自由导航", 320, GREEN),
        ("端到端生成 Genie 3 / Cosmos", "模型自身当物理引擎，实时生成场景与动力学（Waymo 用来模拟极端路况）", 580, ORANGE),
    ]
    for name, desc, x, col in paths:
        s += f'<rect x="{x}" y="210" width="240" height="160" rx="12" fill="white" stroke="{col}" stroke-width="2"/>'
        s += f'<text x="{x+120}" y="240" text-anchor="middle" font-size="13.5" font-weight="600" fill="{col}">{name}</text>'
        # 折行描述
        words = desc
        # 简单按字符宽度折行（每行约 13 字）
        line = ""
        yy = 268
        for ch in words:
            line += ch
            if len(line) >= 13:
                s += f'<text x="{x+120}" y="{yy}" text-anchor="middle" font-size="12" fill="#1a1a1a">{line}</text>'
                line = ""
                yy += 22
        if line:
            s += f'<text x="{x+120}" y="{yy}" text-anchor="middle" font-size="12" fill="#1a1a1a">{line}</text>'
    s += '<text x="420" y="408" text-anchor="middle" font-size="12" fill="#5b6770">智源研究院（BAAI）进一步给出四类路线，并提出“悟界·Physis”等通用世界基座模型</text>'
    s += "</svg>"
    return fig(s, "图 10-3 世界模型：NTP → NSP，以及三条主要技术路径")


# ---------------------------------------------------------------------------
# 图 10-4：AI4S 科研闭环
# ---------------------------------------------------------------------------
def fig_10_4():
    h = 320
    s = svg_open(h, "AI4S：假设生成 — 模拟验证 — 实验优化 的科研闭环")
    # 三个节点
    s += '<rect x="350" y="50" width="160" height="66" rx="14" fill="#eef3f8" stroke="#2c5f8a" stroke-width="2"/>'
    s += '<text x="430" y="80" text-anchor="middle" font-size="14" font-weight="600" fill="#2c5f8a">假设生成</text>'
    s += '<text x="430" y="100" text-anchor="middle" font-size="11.5" fill="#5b6770">模型提出猜想</text>'
    s += '<rect x="80" y="190" width="180" height="66" rx="14" fill="#e7f3ec" stroke="#3a7d44" stroke-width="2"/>'
    s += '<text x="170" y="220" text-anchor="middle" font-size="14" font-weight="600" fill="#3a7d44">模拟验证</text>'
    s += '<text x="170" y="240" text-anchor="middle" font-size="11.5" fill="#5b6770">用数据 / 仿真检验</text>'
    s += '<rect x="580" y="190" width="180" height="66" rx="14" fill="#fdecec" stroke="#c1572f" stroke-width="2"/>'
    s += '<text x="670" y="220" text-anchor="middle" font-size="14" font-weight="600" fill="#c1572f">实验优化</text>'
    s += '<text x="670" y="240" text-anchor="middle" font-size="11.5" fill="#5b6770">真实实验迭代配方</text>'
    # 循环箭头
    s += '<path d="M 430 116 L 200 186" fill="none" stroke="#2c5f8a" stroke-width="2" marker-end="url(#ahS1)"/>'
    s += '<path d="M 580 223 L 440 130" fill="none" stroke="#c1572f" stroke-width="2" marker-end="url(#ahS2)"/>'
    s += '<path d="M 260 223 L 580 223" fill="none" stroke="#3a7d44" stroke-width="2" marker-end="url(#ahS3)"/>'
    s += '<defs>'
    s += '<marker id="ahS1" markerWidth="10" markerHeight="10" refX="7" refY="3.5" orient="auto"><path d="M0,0 L7,3.5 L0,7 z" fill="#2c5f8a"/></marker>'
    s += '<marker id="ahS2" markerWidth="10" markerHeight="10" refX="7" refY="3.5" orient="auto"><path d="M0,0 L7,3.5 L0,7 z" fill="#c1572f"/></marker>'
    s += '<marker id="ahS3" markerWidth="10" markerHeight="10" refX="7" refY="3.5" orient="auto"><path d="M0,0 L7,3.5 L0,7 z" fill="#3a7d44"/></marker>'
    s += '</defs>'
    s += '<text x="430" y="300" text-anchor="middle" font-size="12" fill="#5b6770">典型落地：材料发现（超导相变）、药物设计、气候建模——把科学家从重复试错中解放出来</text>'
    s += "</svg>"
    return fig(s, "图 10-4 AI4S 科研闭环：假设生成 — 模拟验证 — 实验优化")


# ===========================================================================
# 正文块
# ===========================================================================

def build_143_body():
    return (
        '<h3 id="1.4.3-大模型现状">1.4.3 大模型现状：国际主流与国内发展</h3>\n'
        '<p>大模型已经从实验室走进日常工具，并且每隔几个月就会有重量级更新。2026 年 7 月，OpenAI 发布 GPT-5.6 系列（Sol / Terra / Luna 三档），'
        '新增“max 推理强度”与“ultra 子智能体”模式，在编程、网络安全和科学研究上达到新高度，并同步推出可长时间自主工作的 ChatGPT Work 智能体。'
        'Anthropic 于 2026 年 6 月发布 Claude Fable 5，是首个公开可用的“Mythos 级”模型，擅长多天、高复杂度的软件工程与知识工作。'
        'Google 的 Gemini 系列持续强化多模态与视频理解；Meta 的 Llama 系列则代表开源路线，允许研究者在本地下载与部署。</p>\n'
        '<p>国内大模型呈现出“百花齐放”的局面。2025 年初，DeepSeek-R1 以低成本、高性能的开源策略引发关注；到 2026 年，国产模型在智能体、图像生成等方向持续突破。'
        '阿里巴巴的通义千问（Qwen）系列在中文理解、数学推理和开源生态方面表现亮眼，成为全球开发者使用最广泛的开源模型家族之一。'
        '百度的文心一言（已焕新为“文小言”）在中文知识问答和企业级服务上保持优势。字节跳动的豆包依托内容生态，成为国内用户规模最大的 AI 助手之一。'
        '智谱 AI 的 GLM 系列、月之暗面的 Kimi（以长文本处理著称）、MiniMax、腾讯混元、科大讯飞星火等也各有侧重，覆盖从编程、智能体到语音交互的多个场景。</p>\n'
        '<p>根据斯坦福大学 2026 年《AI 指数报告》，中美顶级大模型的性能差距已缩小到约 2.7%，双方在主要评测排行榜上处于同一梯队。'
        '与此同时，中国模型的全球使用量快速增长，开源模型在代码、数学等任务上的表现已逼近闭源旗舰。竞争焦点已经从单纯的“谁更聪明”转向“谁更便宜、更可靠、更适合真实任务”。</p>\n'
        '<p>总体趋势可概括为四点：一是多模态能力增强，模型能同时理解文字、图片、音频和视频；二是推理能力强化，通过“长思维链”或强化学习训练，模型在数学、编程、科研问题上的表现大幅提升；'
        '三是 AI 智能体（Agent）兴起，模型不再只回答提问，而是能调用工具、规划步骤并执行多步任务；四是成本和效率持续下降，大模型从“技术展示”走向“商业落地”。'
        '2026 年，图像生成、智能体工程、世界模型与 AI4S 等更前沿的方向正在快速扩展大模型的能力边界，详见下一节。</p>\n'
        '<div class="note">使用大模型时，记住三条原则：第一，关键信息要核实，模型可能会“一本正经地胡说八道”；第二，保护个人隐私，不要输入敏感信息；'
        '第三，关键决策仍要由人把关，模型是辅助工具，不是最终责任人。</div>'
    )


def build_144():
    return (
        '<h3>1.4.4 2026 年中前沿速览</h3>\n'
        '<p>大模型的能力边界在 2026 年明显外扩。下面四个方向都和大模型现状、智能体密切相关，也是后续章节会展开的前沿。</p>\n'
        '<div class="note" style="background:#eef3f8;border-left:3px solid #2c5f8a;padding:10px 14px;margin:12px 0;">'
        '<strong>图像生成迈入“会思考”阶段：</strong>OpenAI 的 ChatGPT Images 2.0（模型代号 gpt-image-2，2026 年 4 月发布）首次把“思维链”引入图像生成——'
        '生成前先规划、可联网取实时信息、一次最多产出 8 张风格一致的图像，中文等非拉丁文字渲染错误率降到 5% 以下。DALL·E 系列于 2026 年 5 月退役。</div>\n'
        '<div class="note" style="background:#e7f3ec;border-left:3px solid #3a7d44;padding:10px 14px;margin:12px 0;">'
        '<strong>智能体工程：从写提示词到设计循环：</strong>2026 年，“Loop Engineering（循环工程）”成为新范式——人不再逐轮给 Agent 写提示，而是设计“让 Agent 自己跑的循环”。'
        '开源项目 OpenClaw（Peter Steinberger，本地运行的个人智能体，GitHub 星标一度登顶）与 Hermes Agent（Nous Research，内置技能与跨会话记忆的“会成长的智能体”）代表了两条热门路线。'
        'ChatGPT 也推出“Skills（技能）”：把可复用的工作流写成 SKILL.md，让模型在需要时自动调用。</div>\n'
        '<div class="note" style="background:#fdecec;border-left:3px solid #c1572f;padding:10px 14px;margin:12px 0;">'
        '<strong>世界模型：让 AI 理解物理世界：</strong>行业正从“预测下一个词（Next Token Prediction）”转向“预测世界的下一个状态（Next State Prediction）”。'
        'JEPA、高斯泼溅、Genie 3 / Cosmos 等路径，让 AI 能在脑中预演物理过程，是具身智能与机器人落地的关键。</div>\n'
        '<div class="note" style="background:#f1ecf8;border-left:3px solid #6a4c93;padding:10px 14px;margin:12px 0;">'
        '<strong>AI4S（AI for Science）：科研范式变革：</strong>大模型被用于假设生成、模拟验证与实验优化，在蛋白质结构、新材料、药物与气候建模上加速发现。'
        '麦肯锡 2026 年报告估计其市场规模将超 200 亿美元。</div>\n'
        + fig_1_12()
    )


def build_912():
    return (
        '<h2>9.12 智能体工程前沿：从写提示词到设计循环</h2>\n'
        '<p>前面几节讲的是“怎样让一次工具调用更安全、更规范”。但 2026 年行业的一个明显变化是：大家的注意力从“把一次调用写好”移到了“把整套循环设计好”。'
        '这背后是一连串被依次提出的工程范式。</p>\n'
        '<h3>9.12.1 Loop Engineering（循环工程）</h3>\n'
        '<p>“Loop Engineering”由 Google 工程师 Addy Osmani 在 2026 年 6 月正式命名，其思想源自 OpenClaw 作者 Peter Steinberger 与 Claude Code 负责人 Boris Cherny 的同期实践。'
        '它的核心只有一句话：<strong>人不再逐轮给 Agent 写提示，而是设计“让 Agent 自己跑的循环”</strong>。'
        '智能体工程由此形成四层抽象（由内到外）：写好一次提示的 Prompt Engineering、管理上下文窗口的 Context Engineering、搭好运行环境的 Harness Engineering，'
        '以及最外层的 Loop Engineering——它坐在 harness 上面，靠定时器跑起来、派生小助手、自我喂料。</p>\n'
        + fig_9_4() +
        '<p>一个能跑起来的 Loop 通常被拆成五个动作：<strong>发现</strong>（该做什么）、<strong>分发</strong>（交给哪个子智能体）、'
        '<strong>核验</strong>（结果对不对）、<strong>记忆</strong>（进度存下来）、<strong>调度</strong>（何时再跑）。'
        '嵌套关系是：外循环（Loop）每次心跳拉起一个内循环（DeepAgent / harness）作为 worker，内循环内部再跑最内核的 ReAct（思考 → 行动 → 观察）把任务做完，'
        '由独立的评估器把关，再写回长期记忆，等待下一次心跳。</p>\n'
        + fig_9_5() +
        '<h3>9.12.2 OpenClaw 与 Hermes：两条开源智能体路线</h3>\n'
        '<p>开源社区把“让 AI 真正动手”这件事推到了台前。两个代表项目值得了解：</p>\n'
        '<ul>\n'
        '<li><strong>OpenClaw</strong>：由独立开发者 Peter Steinberger 发起的本地个人智能体，可接入 WhatsApp、微信、飞书等日常工具，'
        '核心包括渠道适配器、决策核心、技能插件和“双模记忆”（把设置与记忆以本地 Markdown 存储）。其特点是“本地代理主权”——数据留在自己机器上。</li>\n'
        '<li><strong>Hermes Agent</strong>：由 Nous Research 开源，自称“会成长的智能体”。它把执行经验沉淀为技能（Skills），具备跨会话的持久记忆，'
        '并能自动创建和优化程序性记忆；国内用户还可直接通过微信接入。它体现了“Agent 从每一次任务里越用越聪明”的思路。</li>\n'
        '</ul>\n'
        + fig_9_6() +
        '<h3>9.12.3 Skills（技能）：可复用、可移植的工作流</h3>\n'
        '<p>无论是 OpenAI 的 ChatGPT Skills 还是 Hermes 的技能系统，背后的想法一致：把“反复要做的事”固化成一份可复用、可共享的工作流（通常是一个 SKILL.md 文件，'
        '写明名称、适用场景、步骤、所需资源与产出格式）。模型在合适的时候自动调用一个或多个技能，从而让输出更稳定、也更省去重复解释。'
        '这类技能遵循开放标准、可移植、可组合，被认为是“把聊天机器人升级成可编程自动化平台”的关键一步。</p>\n'
        '<h3>9.12.4 生成器与评估器分离</h3>\n'
        '<p>让一个 Agent 既“生成答案”又“给答案打分”，它往往会偏爱自己的产出。Loop Engineering 因此强调一个朴素但重要的设计：'
        '<strong>让独立的、挑剔的评估器来把关</strong>，而不是让生成器自己验收自己。下面这张图说明了这个分工。</p>\n'
        + fig_9_7() +
        '<h3>9.12.5 可复现实战：离线跑一个 ReAct 式智能体循环</h3>\n'
        '<p>下面这段 Python 不依赖任何外部接口，用规则模拟“模型”的决策，重点展示“观察 → 思考 → 行动 → 观察”的循环，以及“记忆”如何驱动下一步。'
        '把代码复制保存为 agent_loop.py，用普通 Python 运行即可看到循环过程。</p>\n'
        '<pre><code>import math\n\n'
        '# 两个本地“工具”（无需联网，纯函数）\n'
        'def search_books(category):\n'
        '    db = {"科幻": "《三体》", "历史": "《明朝那些事儿》"}\n'
        '    return db.get(category, "未找到")\n\n'
        'def get_summary(title):\n'
        '    return f"{title}：一部广受好评的作品。"\n\n'
        '# 用规则模拟“模型”：根据目标与已知记忆决定下一步动作\n'
        'def fake_model(goal, memory):\n'
        '    if "推荐" in goal and "book" not in memory:\n'
        '        return ("call", "search_books", {"category": "科幻"})\n'
        '    if "book" in memory and "summary" not in memory:\n'
        '        return ("call", "get_summary", {"title": memory["book"]})\n'
        '    return ("done", None, None)\n\n'
        'memory = {}\n'
        'turn = 0\n'
        'while turn &lt; 5:            # 最多 5 轮，防止无限循环\n'
        '    turn += 1\n'
        '    action, tool, args = fake_model("推荐一本科幻书", memory)\n'
        '    if action == "done":\n'
        '        break\n'
        '    if tool == "search_books":\n'
        '        result = search_books(**args)\n'
        '        memory["book"] = result\n'
        '        print(f"[行动] 调用 search_books → {result}")\n'
        '    elif tool == "get_summary":\n'
        '        result = get_summary(**args)\n'
        '        memory["summary"] = result\n'
        '        print(f"[行动] 调用 get_summary → {result}")\n'
        '    print(f"[记忆] {memory}\\n")\n\n'
        'print("最终回答：", memory.get("summary", "（未完成）"))\n'
        '</code></pre>\n'
        '<p>运行后你会看到：第一轮调用 search_books 得到书名并写入记忆，第二轮调用 get_summary 生成简介，随后模型判断“已完成”退出循环。'
        '这正是前面讲的“模型出主意、程序干实事”，只不过这里的“模型”被我们简化成了规则——真正产品里，这一步由大模型承担，而校验、执行、记忆仍由外层程序守住。</p>\n'
        '<div class="key-box">\n'
        '<h4>认证要点（第 9 章补充：智能体工程前沿）</h4>\n'
        '<ul>\n'
        '<li>智能体工程四层抽象：Prompt → Context → Harness → Loop；Loop 坐在最外层，负责“定时跑、自我喂料、派生帮手”。</li>\n'
        '<li>循环由“发现 / 分发 / 核验 / 记忆 / 调度”五动作组成；内层 ReAct，外层 Loop，呈俄罗斯套娃式嵌套。</li>\n'
        '<li>OpenClaw 与 Hermes 是本地 / 开源智能体的代表；Skills（SKILL.md）让工作流可复用、可组合、可移植。</li>\n'
        '<li>生成器与评估器应当分离：让独立的“挑剔考官”把关，比让模型自己验收自己更可靠。</li>\n'
        '<li>可复现实战：智能体循环必须用“最大轮数”等上限防止无限循环；真实系统里模型只出主意，执行与记忆由外层程序负责。</li>\n'
        '</ul>\n'
        '</div>'
    )


def build_108_109():
    return (
        '<h2>10.8 世界模型：让 AI 理解物理世界</h2>\n'
        '<p>前面的多模态模型擅长“看图说话”，但传统大模型本质上仍在做“预测下一个词（Next Token Prediction）”——它从海量文本里学的是语言统计规律，'
        '并不真正理解重力、碰撞、因果关系这些物理常识。2026 年，行业出现一个明显共识：人工智能正从“语言建模”走向“世界建模”。</p>\n'
        '<p>世界模型的核心是<strong>预测世界的下一个状态（Next State Prediction，NSP）</strong>，而不是预测下一个词。'
        '它让 AI 在脑中预演：如果我这样做，物理环境会发生什么变化？从而支撑机器人、自动驾驶、具身智能等“进入真实世界”的任务。'
        '当前主要有三条技术路径：</p>\n'
        '<ul>\n'
        '<li><strong>JEPA（联合嵌入预测架构，杨立昆倡导）</strong>：不预测像素级细节，而是学习抽象的潜空间特征，忽略无关背景，计算和内存更高效，适合机器人、自动驾驶等实时推理场景。</li>\n'
        '<li><strong>高斯泼溅（Gaussian Splats）</strong>：从提示生成 3D 高斯泼溅场景，可导入标准物理引擎自由导航，大幅降低创建交互式 3D 环境的成本。</li>\n'
        '<li><strong>端到端生成（Genie 3 / Cosmos 为代表）</strong>：模型自身充当物理引擎，实时生成场景、物理动力学与反应；Waymo 用它模拟极端路况等少见但危险的边界场景。</li>\n'
        '</ul>\n'
        + fig_10_3() +
        '<p>智源研究院（BAAI）在 2026 年进一步把世界模型归纳为四类路线（以语言为中心、以像素为中心、以三维结构为中心、以视觉表征为中心），'
        '并发布“悟界·Physis”等通用世界基座模型，强调以“物理隐空间”统一表达语言、动作、状态、时间与空间，是面向真实物理世界的下一代基座模型。</p>\n'
        '<h2>10.9 AI4S：当大模型走进实验室</h2>\n'
        '<p>AI4S（AI for Science，人工智能驱动科学研究）是把大模型用于基础科研的新范式。它把科研从“靠直觉 + 大量试错”转向“数据 + 模型驱动”，'
        '形成“假设生成 → 模拟验证 → 实验优化”的智能闭环。在材料发现（预测超导相变路径）、药物设计、气候建模等领域，AI4S 已经把原本以年计的研发周期压缩到月级。</p>\n'
        + fig_10_4() +
        '<h3>可复现实战：用最小二乘“重新发现”开普勒第三定律</h3>\n'
        '<p>这段 Python 不依赖任何第三方库。我们给定几组（行星半长轴 a，公转周期 T）的带噪声观测，用最小二乘在“对数空间”里拟合，'
        '结果会自然浮现 T² ∝ a³（理论指数约 1.5）。它用最朴素的方式演示了 AI4S 的“从数据中发现定律”思路。复制保存为 discover_law.py 即可运行。</p>\n'
        '<pre><code>import math\n\n'
        '# (半长轴 a, 周期 T) 的带噪声观测\n'
        'points = [(0.39, 0.24), (0.72, 0.62), (1.00, 1.00),\n'
        '          (1.52, 1.88), (5.20, 11.86)]\n\n'
        '# 取对数后，log T = k * log a + b，真实 k 应接近 1.5\n'
        'xs = [math.log(a) for a, _ in points]\n'
        'ys = [math.log(t) for _, t in points]\n'
        'n = len(xs)\n'
        'mx = sum(xs) / n; my = sum(ys) / n\n'
        'num = sum((x - mx) * (y - my) for x, y in zip(xs, ys))\n'
        'den = sum((x - mx) ** 2 for x in xs)\n'
        'k = num / den\n'
        'print(f"拟合得到 T 正比于 a^{k:.3f}（理论值 1.5）")\n'
        '</code></pre>\n'
        '<p>运行后会打印出接近 1.5 的指数——模型“重新发现”了行星运动里那条著名规律。现实中 AI4S 做的正是这件事的放大版：'
        '从海量实验 / 仿真数据里提炼可迁移的规律，再用真实实验去校验它。</p>\n'
    )


def main():
    with open(HTML_PATH, "r", encoding="utf-8") as f:
        html = f.read()
    orig_len = len(html)

    # ---- 1) §1.4.3 正文重写（切片替换，保留 图 1-11）----
    h3 = html.index('<h3>1.4.3 大模型现状')
    fig_start = html.index('<figure class="textbook-fig">', h3)
    html = html[:h3] + build_143_body() + html[fig_start:]

    # ---- 2) §1.4.4 + 图 1-12，插入到 图 1-11 之后 ----
    cap11 = html.index('<figcaption>图 1-11 大模型现状')
    fig11_end = html.index('</figure>', cap11) + len('</figure>')
    html = html[:fig11_end] + '\n\n' + build_144() + '\n' + html[fig11_end:]

    # ---- 3) §9.12 智能体工程前沿，插入到“小白课堂”笔记之后、第 9 章要点之前 ----
    anchor9 = html.index('角色扮演就像演员演戏')
    note9_end = html.index('</div>', anchor9) + len('</div>')
    keybox9 = html.index('<div class="key-box">', note9_end)
    html = html[:note9_end] + '\n\n' + build_912() + '\n' + html[keybox9:]

    # ---- 4) §10.8 / §10.9，插入到 图 10-2 之后、第 10 章要点之前，并追加热点 ----
    cap10 = html.index('<figcaption>图 10-2 多模态融合')
    fig10_end = html.index('</figure>', cap10) + len('</figure>')
    keybox10 = html.index('<div class="key-box">', fig10_end)
    html = html[:fig10_end] + '\n\n' + build_108_109() + '\n' + html[keybox10:]

    # 向第 10 章要点追加两条
    last_li = '风险：幻觉、偏见、隐私、多模态提示注入；对策是人工复核、先转可核验文本、指令/数据分离。</li>'
    idx = html.index(last_li) + len(last_li)
    extra = ('\n<li>世界模型把目标从“预测下一个词”升级为“预测下一物理状态”，是具身智能与机器人的关键底座'
              '（JEPA / 高斯泼溅 / Genie 3·Cosmos 三条路径）。</li>\n'
              '<li>AI4S（AI for Science）用“假设生成—模拟验证—实验优化”的闭环加速科研，在材料、药物、气候等领域落地。</li>')
    html = html[:idx] + extra + html[idx:]

    with open(HTML_PATH, "w", encoding="utf-8") as f:
        f.write(html)

    # ---- 自检 ----
    n_open = html.count('<svg'); n_close = html.count('</svg>')
    f_open = html.count('<figure'); f_close = html.count('</figure>')
    print(f"写入完成：{orig_len} → {len(html)} 字符")
    print(f"<svg> {n_open} / </svg> {n_close}  |  <figure> {f_open} / </figure> {f_close}")

    # 逐个解析 svg，确保 XML 合法
    import re
    svgs = re.findall(r'<svg.*?</svg>', html, re.S)
    bad = 0
    for i, s in enumerate(svgs):
        try:
            minidom.parseString(s)
        except Exception as e:
            bad += 1
            print(f"[XML 错误] 第 {i} 个 svg：{e}")
    print(f"SVG 解析：{len(svgs)} 个，非法 {bad} 个")

    # AI 痕迹词扫描
    traces = ["换句话说", "综上所述", "值得注意的是", "需要强调的是", "总而言之", "显而易见", "不难发现", "值得一提的是"]
    hits = {w: html.count(w) for w in traces if html.count(w) > 0}
    print("AI 痕迹词：", hits if hits else "无新增")


if __name__ == "__main__":
    main()
