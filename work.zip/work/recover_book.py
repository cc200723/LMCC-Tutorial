# -*- coding: utf-8 -*-
"""Recover LMCC青少年组教材-增强版.html from a corrupted state.

Strategy (safe, no greedy figure replacement):
  HEAD+MIDDLE = base[ : 图6-2 的 <figure> ]  (all text from chapters, consistent)
                 + re-inject the lost middle figures/trends by CALLING the
                   generation functions of add_figures.py / expand_trends.py
                   (imported as modules -> pure string builders, no file mutation)
                 + apply the 4 user-requested redraws (图1-9 ROC, 图2-1 no-black,
                   图3-2 FP16/FP32/BF16 labels, 图1-4 涌现能力)
  TAIL         = corrupted-backup[9810:]  (last-good ch6.2->12 + appendix, intact)
The TAIL already contains the radian 图6-2 and all §9.12/§10.8/§10.9 redraws.
"""
import re, xml.dom.minidom as M, importlib.util, os

ROOT = os.path.dirname(os.path.abspath(__file__))
PARENT = os.path.join(ROOT, "..")
BASE_P = os.path.join(PARENT, "LMCC青少年组教材.html")
BAK_P  = os.path.join(PARENT, "LMCC青少年组教材-增强版.bak_corrupted.html")
OUT_P  = os.path.join(PARENT, "LMCC青少年组教材-增强版.html")

base = open(BASE_P, encoding="utf-8").read()
bak  = open(BAK_P,  encoding="utf-8").read()

# ---------- safe figure block helpers ----------
def fig_open_pos(html, cap_prefix):
    """index of the <figure ...> tag that encloses a figcaption starting with cap_prefix."""
    i = html.index('<figcaption>' + cap_prefix)
    return html.rfind('<figure', 0, i)

def replace_fig(html, cap_prefix, new_figure):
    i = html.index('<figcaption>' + cap_prefix)
    fs = html.rfind('<figure', 0, i)
    fe = html.find('</figure>', i) + len('</figure>')
    return html[:fs] + new_figure + html[fe:]

def insert_after_figure(html, cap_prefix, block):
    i = html.index('<figcaption>' + cap_prefix)
    fe = html.find('</figure>', i) + len('</figure>')
    return html[:fe] + '\n' + block + '\n' + html[fe:]

# ---------- import generation functions (safe: guarded main, no top-level mutation) ----------
spec = importlib.util.spec_from_file_location("AF", os.path.join(ROOT, "add_figures.py"))
AF = importlib.util.module_from_spec(spec); spec.loader.exec_module(AF)
spec2 = importlib.util.spec_from_file_location("ET", os.path.join(ROOT, "expand_trends.py"))
ET = importlib.util.module_from_spec(spec2); spec2.loader.exec_module(ET)

# ---------- palette for the redraw figures (from redraw_figs.py / redraw_figs2.py) ----------
BLUE="#2c5f8a"; ORANGE="#c1572f"; GREEN="#3a7d44"; PURPLE="#6a4c93"
RED="#d13c3c"; INK="#1a1a1a"; MUTE="#5b6770"; PANEL="#f4f7fa"; BORDER="#cfd6dd"
FONT="Noto Sans CJK SC,Microsoft YaHei,PingFang SC,sans-serif"
WHITE="#ffffff"; GRID="#e3e8ed"
TINT_BLUE="#eaf1f7"; TINT_ORANGE="#fbeee8"; TINT_GREEN="#eaf3ec"

PAL = {'BLUE':'#2c5f8a','ORANGE':'#c1572f','GREEN':'#3a7d44','PURPLE':'#6a4c93',
        'RED':'#d13c3c','INK':'#1a1a1a','MUTE':'#5b6770','PANEL':'#f4f7fa','BORDER':'#cfd6dd',
        'FONT':FONT,'BLUE_P':'#eaf2f8','ORANGE_P':'#fbeee6','GREEN_P':'#eaf3ec'}
def fill(s):
    for k,v in PAL.items(): s = s.replace(k, v)
    return s

# ---------- FIG 1-9 (ROC, clean integer coords) ----------
fs = [0.0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0]
tprs = [0.0,0.2316,0.4276,0.6014,0.7211,0.8232,0.8988,0.9507,0.9821,0.9968,1.0]
pts = [(int(round(80+720*f)), int(round(460-390*t))) for f,t in zip(fs,tprs)]
d_curve = "M " + " L ".join(f"{x},{y}" for x,y in pts)
FIG_1_9 = f'''<figure class="textbook-fig">
<svg xmlns="http://www.w3.org/2000/svg" width="840" height="560" viewBox="0 0 840 560" font-family="{FONT}">
<rect x="0" y="0" width="840" height="560" fill="{WHITE}"/>
<text x="420" y="40" text-anchor="middle" font-size="18" font-weight="700" fill="{INK}">ROC 曲线：整体区分能力的体检单</text>
<text x="420" y="66" text-anchor="middle" font-size="13" fill="{MUTE}">曲线越靠近左上角，模型区分正负样本的能力越强（AUC 越大）</text>
<line x1="80" y1="460" x2="800" y2="460" stroke="{INK}" stroke-width="1.5"/>
<line x1="80" y1="460" x2="80" y2="70" stroke="{INK}" stroke-width="1.5"/>
<line x1="440" y1="70" x2="440" y2="460" stroke="{GRID}" stroke-width="1"/>
<line x1="800" y1="70" x2="800" y2="460" stroke="{GRID}" stroke-width="1"/>
<line x1="80" y1="265" x2="800" y2="265" stroke="{GRID}" stroke-width="1"/>
<line x1="80" y1="70" x2="800" y2="70" stroke="{GRID}" stroke-width="1"/>
<text x="80" y="482" text-anchor="middle" font-size="14" fill="{INK}">0.0</text>
<text x="440" y="482" text-anchor="middle" font-size="14" fill="{INK}">0.5</text>
<text x="800" y="482" text-anchor="middle" font-size="14" fill="{INK}">1.0</text>
<text x="440" y="508" text-anchor="middle" font-size="15" fill="{INK}">假阳性率 FPR（False Positive Rate）</text>
<text x="68" y="465" text-anchor="end" font-size="14" fill="{INK}">0.0</text>
<text x="68" y="270" text-anchor="end" font-size="14" fill="{INK}">0.5</text>
<text x="68" y="75" text-anchor="end" font-size="14" fill="{INK}">1.0</text>
<text x="26" y="265" text-anchor="middle" font-size="15" fill="{INK}" transform="rotate(-90 26,265)">真阳性率 TPR（True Positive Rate）</text>
<line x1="80" y1="460" x2="800" y2="70" stroke="{RED}" stroke-width="2.5" stroke-dasharray="10,7"/>
<text x="250" y="400" font-size="14" font-weight="600" fill="{RED}" transform="rotate(-28 250,400)">随机分类器（AUC = 0.5）</text>
<path d="M 80,460 L 80,70 L 800,70" fill="none" stroke="{GREEN}" stroke-width="1.6" stroke-dasharray="6,4"/>
<text x="92" y="88" font-size="13" font-weight="600" fill="{GREEN}">理想分类器（AUC = 1.0）</text>
<path d="{d_curve}" fill="none" stroke="{BLUE}" stroke-width="3"/>
<text x="250" y="205" font-size="14" font-weight="700" fill="{BLUE}">模型 A（AUC ≈ 0.90）</text>
<line x1="640" y1="150" x2="470" y2="95" stroke="{INK}" stroke-width="1.8" marker-end="url(#ah9)"/>
<text x="500" y="118" font-size="13" font-weight="600" fill="{INK}">更好</text>
<line x1="690" y1="190" x2="770" y2="250" stroke="{INK}" stroke-width="1.8" marker-end="url(#ah9)"/>
<text x="740" y="240" font-size="13" font-weight="600" fill="{INK}">更差</text>
<defs>
<marker id="ah9" markerWidth="10" markerHeight="10" refX="8" refY="3" orient="auto">
<path d="M0,0 L8,3 L0,6 z" fill="{INK}"/>
</marker>
</defs>
</svg>
<figcaption>图 1-9 ROC 曲线与 AUC：整体区分能力的体检单</figcaption>
</figure>'''

# ---------- FIG 3-2 (prominent FP16 / BF16 / FP32 labels) ----------
FIG_3_2 = f'''<figure class="textbook-fig">
<svg xmlns="http://www.w3.org/2000/svg" width="840" height="340" viewBox="0 0 840 340" font-family="{FONT}">
<rect x="0" y="0" width="840" height="340" fill="{WHITE}"/>
<text x="420" y="28" text-anchor="middle" font-size="16" font-weight="700" fill="{INK}">三种浮点精度的 bit 分配（宽度按比例，每 bit 20px）</text>
<text x="24" y="100" font-size="16" font-weight="800" fill="{BLUE}">FP32</text>
<text x="24" y="118" font-size="11" fill="{MUTE}">32 位 · 全精度</text>
<rect x="150" y="64" width="20" height="54" fill="{RED}"/>
<text x="160" y="96" text-anchor="middle" font-size="11" fill="{WHITE}">S</text>
<rect x="170" y="64" width="160" height="54" fill="{BLUE}"/>
<text x="250" y="96" text-anchor="middle" font-size="12" fill="{WHITE}">指数 8 bit</text>
<rect x="330" y="64" width="460" height="54" fill="{GREEN}"/>
<text x="560" y="96" text-anchor="middle" font-size="12" fill="{WHITE}">尾数 23 bit</text>
<text x="24" y="180" font-size="16" font-weight="800" fill="{ORANGE}">FP16</text>
<text x="24" y="198" font-size="11" fill="{MUTE}">16 位</text>
<rect x="150" y="144" width="20" height="54" fill="{RED}"/>
<text x="160" y="176" text-anchor="middle" font-size="11" fill="{WHITE}">S</text>
<rect x="170" y="144" width="100" height="54" fill="{BLUE}"/>
<text x="220" y="176" text-anchor="middle" font-size="12" fill="{WHITE}">指数 5 bit</text>
<rect x="270" y="144" width="200" height="54" fill="{GREEN}"/>
<text x="370" y="176" text-anchor="middle" font-size="12" fill="{WHITE}">尾数 10 bit</text>
<text x="500" y="176" font-size="12" fill="{RED}">范围窄（最大 65504），训练易溢出</text>
<text x="24" y="260" font-size="16" font-weight="800" fill="{GREEN}">BF16</text>
<text x="24" y="278" font-size="11" fill="{MUTE}">16 位</text>
<rect x="150" y="224" width="20" height="54" fill="{RED}"/>
<text x="160" y="256" text-anchor="middle" font-size="11" fill="{WHITE}">S</text>
<rect x="170" y="224" width="160" height="54" fill="{BLUE}"/>
<text x="250" y="256" text-anchor="middle" font-size="12" fill="{WHITE}">指数 8 bit</text>
<rect x="330" y="224" width="140" height="54" fill="{GREEN}"/>
<text x="400" y="256" text-anchor="middle" font-size="12" fill="{WHITE}">尾数 7 bit</text>
<text x="500" y="256" font-size="12" fill="{GREEN}">范围同 FP32，训练更稳定</text>
<text x="24" y="318" font-size="12.5" fill="{INK}">要点：FP16 与 BF16 都是 16 位，但 BF16 把 8 位分给指数（与 FP32 相同），故范围大、训练稳定，尾数精度较低。</text>
</svg>
<figcaption>图 3-2 三种浮点精度的 bit 分配：FP16、BF16、FP32 的指数位与尾数位拆分（宽度按每 bit 20px）</figcaption>
</figure>'''

# ---------- FIG 1-4 (涌现能力) & FIG 2-1 (no black bg) from redraw_figs.py ----------
FIG1_4 = fill("""<figure class="textbook-fig"><svg xmlns="http://www.w3.org/2000/svg" width="840" height="360" viewBox="0 0 840 360" font-family="FONT">
<rect width="840" height="360" fill="#ffffff"/>
<text x="420" y="26" text-anchor="middle" font-size="16" font-weight="700" fill="INK">涌现能力：模型规模突破阈值后，复杂能力突然跳升</text>
<line x1="80" y1="290" x2="790" y2="290" stroke="INK" stroke-width="1.8"/>
<line x1="80" y1="290" x2="80" y2="60" stroke="INK" stroke-width="1.8"/>
<text x="435" y="336" text-anchor="middle" font-size="13" fill="MUTE">模型参数量（对数尺度）</text>
<text x="26" y="180" text-anchor="middle" font-size="13" fill="MUTE" transform="rotate(-90,26,180)">任务准确率</text>
<text x="130" y="308" text-anchor="middle" font-size="11" fill="MUTE">1M</text>
<text x="250" y="308" text-anchor="middle" font-size="11" fill="MUTE">100M</text>
<text x="390" y="308" text-anchor="middle" font-size="11" fill="MUTE">1B</text>
<text x="530" y="308" text-anchor="middle" font-size="11" fill="MUTE">10B</text>
<text x="660" y="308" text-anchor="middle" font-size="11" fill="MUTE">100B</text>
<text x="770" y="308" text-anchor="middle" font-size="11" fill="MUTE">1T</text>
<text x="70" y="74" text-anchor="end" font-size="11" fill="MUTE">100%</text>
<text x="70" y="132" text-anchor="end" font-size="11" fill="MUTE">75%</text>
<text x="70" y="190" text-anchor="end" font-size="11" fill="MUTE">50%</text>
<text x="70" y="248" text-anchor="end" font-size="11" fill="MUTE">25%</text>
<text x="70" y="294" text-anchor="end" font-size="11" fill="MUTE">0%</text>
<polyline points="130,272 250,254 390,224 530,200 660,182 770,168" fill="none" stroke="BLUE" stroke-width="2.6"/>
<text x="782" y="166" font-size="12" fill="BLUE">简单任务</text>
<polyline points="130,284 250,280 390,277 480,275 530,150 660,100 770,78" fill="none" stroke="ORANGE" stroke-width="2.6"/>
<text x="782" y="80" font-size="12" fill="ORANGE">数学推理</text>
<polyline points="130,286 250,283 390,280 530,277 580,160 660,105 770,86" fill="none" stroke="GREEN" stroke-width="2.6"/>
<text x="782" y="94" font-size="12" fill="GREEN">代码生成</text>
<line x1="530" y1="64" x2="530" y2="288" stroke="RED" stroke-width="1.4" stroke-dasharray="5,4"/>
<circle cx="530" cy="150" r="5.5" fill="none" stroke="RED" stroke-width="2"/>
<circle cx="580" cy="160" r="5.5" fill="none" stroke="RED" stroke-width="2"/>
<text x="530" y="56" text-anchor="middle" font-size="12" font-weight="700" fill="RED">涌现阈值</text>
</svg><figcaption>图 1-4 涌现能力示意：简单任务（蓝色）平滑增长，复杂任务（橙色/绿色）在特定规模处突然跳升</figcaption></figure>""")

FIG2_1 = fill("""<figure class="textbook-fig"><svg xmlns="http://www.w3.org/2000/svg" width="840" height="380" viewBox="0 0 840 380" font-family="FONT">
<defs><marker id="ar-m" markerWidth="9" markerHeight="9" refX="6" refY="3" orient="auto"><path d="M0,0 L6,3 L0,6 z" fill="MUTE"/></marker></defs>
<rect width="840" height="380" fill="#ffffff"/>
<text x="420" y="28" text-anchor="middle" font-size="16" font-weight="700" fill="INK">缩放点积注意力：Q、K、V 如何产生输出</text>
<rect x="60" y="60" width="180" height="170" rx="10" fill="BLUE_P" stroke="BLUE" stroke-width="1.6"/>
<text x="150" y="92" text-anchor="middle" font-size="14" font-weight="700" fill="BLUE">Q（查询）</text>
<text x="150" y="116" text-anchor="middle" font-size="11" fill="MUTE">question</text>
<text x="150" y="150" text-anchor="middle" font-size="12" fill="INK">来自当前位置</text>
<text x="150" y="170" text-anchor="middle" font-size="12" fill="INK">去和其他位置比对</text>
<text x="150" y="200" text-anchor="middle" font-size="11" fill="MUTE">“要问什么”</text>
<rect x="330" y="60" width="180" height="170" rx="10" fill="ORANGE_P" stroke="ORANGE" stroke-width="1.6"/>
<text x="420" y="92" text-anchor="middle" font-size="14" font-weight="700" fill="ORANGE">K（键）</text>
<text x="420" y="116" text-anchor="middle" font-size="11" fill="MUTE">key</text>
<text x="420" y="150" text-anchor="middle" font-size="12" fill="INK">每个位置的特征</text>
<text x="420" y="170" text-anchor="middle" font-size="12" fill="INK">用来被查询</text>
<text x="420" y="200" text-anchor="middle" font-size="11" fill="MUTE">“是什么”</text>
<rect x="600" y="60" width="180" height="170" rx="10" fill="GREEN_P" stroke="GREEN" stroke-width="1.6"/>
<text x="690" y="92" text-anchor="middle" font-size="14" font-weight="700" fill="GREEN">V（值）</text>
<text x="690" y="116" text-anchor="middle" font-size="11" fill="MUTE">value</text>
<text x="690" y="150" text-anchor="middle" font-size="12" fill="INK">每个位置真正</text>
<text x="690" y="170" text-anchor="middle" font-size="12" fill="INK">要取出的信息</text>
<text x="690" y="200" text-anchor="middle" font-size="11" fill="MUTE">“携带什么”</text>
<rect x="110" y="272" width="170" height="46" rx="8" fill="PANEL" stroke="BORDER"/>
<text x="195" y="300" text-anchor="middle" font-size="13" fill="INK">Q·Kᵀ / √d</text>
<rect x="320" y="272" width="120" height="46" rx="8" fill="PANEL" stroke="BORDER"/>
<text x="380" y="300" text-anchor="middle" font-size="13" fill="INK">softmax</text>
<rect x="480" y="272" width="120" height="46" rx="8" fill="PANEL" stroke="BORDER"/>
<text x="540" y="300" text-anchor="middle" font-size="13" fill="INK">× V</text>
<rect x="650" y="272" width="120" height="46" rx="8" fill="PANEL" stroke="BORDER"/>
<text x="710" y="300" text-anchor="middle" font-size="13" font-weight="700" fill="BLUE">输出</text>
<line x1="150" y1="230" x2="188" y2="272" stroke="MUTE" stroke-width="1.6" marker-end="url(#ar-m)"/>
<line x1="420" y1="230" x2="240" y2="272" stroke="MUTE" stroke-width="1.6" marker-end="url(#ar-m)"/>
<line x1="290" y1="295" x2="318" y2="295" stroke="MUTE" stroke-width="1.6" marker-end="url(#ar-m)"/>
<line x1="440" y1="295" x2="478" y2="295" stroke="MUTE" stroke-width="1.6" marker-end="url(#ar-m)"/>
<line x1="690" y1="230" x2="562" y2="272" stroke="MUTE" stroke-width="1.6" marker-end="url(#ar-m)"/>
<line x1="600" y1="295" x2="648" y2="295" stroke="MUTE" stroke-width="1.6" marker-end="url(#ar-m)"/>
</svg><figcaption>图 2-1 缩放点积注意力：Q 查询、K 键、V 值如何相互作用产生输出</figcaption></figure>""")

# =====================================================================
# Build MIDDLE (ch1 图1-1 -> ch6.1, before 图6-2) from base
# =====================================================================
m_start = fig_open_pos(base, "图 1-1")
m_end   = fig_open_pos(base, "图 6-2")
mid = base[m_start:m_end]
print("MIDDLE slice:", len(mid), "chars  (base", m_start, "->", m_end, ")")

# ---- inject add_figures extras that belong to the middle (skip 8-2, 9-2 which live in the TAIL) ----
A161 = '<h3>1.6.1 更多评测工具：交叉验证与 ROC/AUC</h3>'
blk10 = AF.build_block(next(it for it in AF.FIGURES if it["no"] == "1-10"))
# 图1-9 gets MY redraw (ROC); 图1-10 keeps the add_figures version
combined_161 = A161 + "\n" + FIG_1_9 + "\n" + blk10 + "\n"
mid = mid.replace(A161, combined_161, 1)

for item in AF.FIGURES:
    no = item["no"]
    if no in ("1-9", "1-10", "8-2", "9-2"):
        continue
    a = item["anchor"]; blk = AF.build_block(item)
    if item["pos"] == "after":
        mid = mid.replace(a, a + blk, 1)
    else:
        mid = mid.replace(a, blk + a, 1)

# ---- inject expand_trends §1.4.3 / §1.4.4 / 图1-12 (middle only) ----
h3 = mid.index('<h3>1.4.3 大模型现状')
fig_start = mid.index('<figure class="textbook-fig">', h3)
mid = mid[:h3] + ET.build_143_body() + mid[fig_start:]
cap11 = mid.index('<figcaption>图 1-11 大模型现状')
fig11_end = mid.index('</figure>', cap11) + len('</figure>')
mid = mid[:fig11_end] + '\n\n' + ET.build_144() + '\n' + mid[fig11_end:]

# ---- apply the 4 redraws ----
# 图2-1 : replace with clean (no black bg) version
mid = replace_fig(mid, "图 2-1 ", FIG2_1)
# 图1-4 : insert after 图1-3 (does not exist in base)
mid = insert_after_figure(mid, "图 1-3 ", FIG1_4)
# 图3-2 : insert after 图3-1 (does not exist in base) - labeled version
mid = insert_after_figure(mid, "图 3-1 ", FIG_3_2)

# =====================================================================
# Assemble FINAL = HEAD + MIDDLE + TAIL
# =====================================================================
head = base[:m_start]
# ---- inject 图1-5 / 图1-7 into HEAD (their anchors are in §1.0, BEFORE 图1-1) ----
for item in AF.FIGURES:
    if item["no"] in ("1-5", "1-7"):
        a = item["anchor"]; blk = AF.build_block(item)
        if a not in head:
            print(f"  WARN: HEAD anchor for 图{item['no']} not found: {a[:30]}")
            continue
        if item["pos"] == "after":
            head = head.replace(a, a + blk, 1)
        else:
            head = head.replace(a, blk + a, 1)
        print(f"  injected 图{item['no']} into HEAD (anchor: {a[:24]}...)")
tail = bak[9810:]
final = head + mid + tail
# ---- safety net: any invalid _P fills are always a bug -> light tints ----
final = final.replace("#2c5f8a_P", "#eaf2f8").replace("#c1572f_P", "#fbeee6").replace("#3a7d44_P", "#eaf3ec")
# ---- normalize pre-existing BAD font-family attrs (unescaped inner quotes break strict XML) ----
# e.g. font-family="Noto Sans CJK SC","Microsoft YaHei","PingFang SC",sans-serif
#  -> font-family="Noto Sans CJK SC,Microsoft YaHei,PingFang SC,sans-serif"
# Non-greedy, bounded by the attribute terminator (whitespace or >) so it cannot over-match.
def _fixff(m):
    raw = m.group(1)
    cleaned = raw.replace('"', '')   # drop inner quotes; CSS comma list needs none
    return 'font-family="' + cleaned + '"'
final = re.sub(r'font-family="(.*?)"(?=[\s>])', _fixff, final, flags=re.S)

# ---- upgrade KaTeX bootstrap: render inside .math-block too (appendix B formulas) ----
# Old bootstrap only scans $$ / \[ / \( at top level. The appendix's <div class="math-block">
# contents were not rendered -> PDF showed raw LaTeX. This block patches the bootstrap.
OLD_BOOT = '''<script>
document.addEventListener("DOMContentLoaded", function(){
  if (window.renderMathInElement) {
    renderMathInElement(document.body, {
      delimiters: [
        {left:"$$", right:"$$", display:true},
        {left:"\\\\[", right:"\\\\]", display:true},
        {left:"\\\\(", right:"\\\\)", display:false}
      ],
      throwOnError:false, errorColor:"#b23a3a"
    });
  }
});
</script>'''
NEW_BOOT = '''<script>
document.addEventListener("DOMContentLoaded", function(){
  if (window.renderMathInElement) {
    function renderAll(root) {
      renderMathInElement(root, {
        delimiters: [
          {left:"$$", right:"$$", display:true},
          {left:"\\\\[", right:"\\\\]", display:true},
          {left:"\\\\(", right:"\\\\)", display:false}
        ],
        throwOnError:false, errorColor:"#b23a3a"
      });
      document.querySelectorAll(".math-block").forEach(function(el){
        var html = el.innerHTML.replace(/\\$([^$\\n]+?)\\$/g, "\\\\($1\\\\)");
        el.innerHTML = html;
        renderMathInElement(el, {
          delimiters: [
            {left:"$$", right:"$$", display:true},
            {left:"\\\\[", right:"\\\\]", display:true},
            {left:"\\\\(", right:"\\\\)", display:false}
          ],
          throwOnError:false, errorColor:"#b23a3a"
        });
      });
    }
    if (typeof katex === "undefined") {
      var s = document.createElement("script");
      s.src = "work/katex/katex.min.js";
      s.onload = function() {
        var s2 = document.createElement("script");
        s2.src = "work/katex/auto-render.min.js";
        s2.onload = function(){ renderAll(document.body); };
        document.head.appendChild(s2);
      };
      document.head.appendChild(s);
    } else {
      renderAll(document.body);
    }
  }
});
</script>'''
if OLD_BOOT in final:
    final = final.replace(OLD_BOOT, NEW_BOOT, 1)
    print("  KaTeX bootstrap: upgraded to render inside .math-block")
else:
    # 退化匹配：仅替换 document.addEventListener 整块
    print("  WARN: old KaTeX bootstrap not found verbatim, leaving as-is")

# ---- add beginner-friendly cosθ interpretation after 图6-2 ----
COS_NOTE = '''
<div class="key-box">
<h4>读懂这张图：cos θ 到底等于多少？</h4>
<p>上图把查询向量 <strong>q̂</strong> 和文档向量 <strong>d̂</strong> 都做了 L2 归一化（长度变成 1），所以它们的点积就等于夹角的余弦：<strong>sim = cos θ = q̂ · d̂</strong>。本图里 θ ≈ 0.91 弧度（约 52°），算出来 <strong>cos θ ≈ 0.62</strong>。这个数字怎么理解？</p>
<ul>
<li><strong>cos θ = 1</strong>：两向量方向完全一致 → 文档与查询完全相关。</li>
<li><strong>cos θ = 0</strong>：两向量垂直 → 文档与查询"八竿子打不着"。</li>
<li><strong>cos θ = −1</strong>：方向相反 → 含义对立。</li>
<li><strong>cos θ ≈ 0.62</strong>（本图）：方向比较接近，但不完全重合 → 文档<strong>大概率相关</strong>，值得排在检索结果靠前的位置。</li>
</ul>
<p>实际 RAG 系统会给所有候选文档算 cos θ，按从大到小排序取 Top-k，再把最相关的几篇喂给大模型作答。所以"<strong>余弦相似度越大 = 越相关</strong>"是检索的核心直觉。</p>
</div>
'''
try:
    final = insert_after_figure(final, "图 6-2 ", COS_NOTE)
    print("  cosθ interpretation note: inserted after 图6-2")
except Exception as e:
    print(f"  WARN: could not insert cosθ note: {e}")

open(OUT_P, "w", encoding="utf-8").write(final)

# =====================================================================
# Self validation
# =====================================================================
def _try(s):
    try: M.parseString(s.encode("utf-8")); return True
    except Exception: return False
svgs=re.findall(r"<svg\b",final); svge=re.findall(r"</svg>",final)
figs=re.findall(r"<figure\b",final); fige=re.findall(r"</figure>",final)
bad=sum(1 for m in re.finditer(r"<svg.*?</svg>",final,re.S) if not _try(m.group(0)))
print("svg",len(svgs),len(svge),"| figure",len(figs),len(fige),"| xml_fail",bad)
need=["图 1-4","图 1-9","图 2-1","图 3-2","图 3-1","图 6-2","图 9-2","图 9-6","图 9-4","图 10-3","图 1-12","附录 E","世界模型","B.4 第 10 章前沿概念","GPT-5.6"]
for n in need: print(f"  present {n!r}: {final.count(n)}")
# 图2-1 black-bg check
f21=re.search(r"<figure[^>]*>.*?<figcaption>图 2-1.*?</figure>",final,re.S)
print("  图2-1 invalid _P fills:", (f21.group(0).count("#2c5f8a_P")+f21.group(0).count("#c1572f_P")+f21.group(0).count("#3a7d44_P")) if f21 else "MISS")
# 图6-2 radian check (in tail)
f62=re.search(r"<figure[^>]*>.*?<figcaption>图 6-2.*?</figure>",final,re.S)
print("  图6-2 0.91 rad:",("0.91 rad" in f62.group(0)) if f62 else "MISS","| 弧度:",("弧度" in f62.group(0)) if f62 else "MISS")
# 图3-2 label check
f32=re.search(r"<figure[^>]*>.*?<figcaption>图 3-2.*?</figure>",final,re.S)
print("  图3-2 has FP16/BF16/FP32 labels:", all(k in f32.group(0) for k in["FP16","BF16","FP32"]) if f32 else "MISS")
print("WROTE", OUT_P, len(final), "bytes")
