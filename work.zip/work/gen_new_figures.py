﻿# -*- coding: utf-8 -*-
"""
Generate new SVG figures for the expanded textbook sections.
1. Post-training pipeline (Chapter 4)
2. Scaling Laws comparison (Chapter 3)
3. Model compression methods (Chapter 5)
4. Decoding strategy comparison (Chapter 5)
5. Causal mask visualization (Chapter 2)
"""
from pathlib import Path
import re

HTML_PATH = str(Path(__file__).resolve().parent.parent / "LMCC青少年组教材-增强版.html")

with open(HTML_PATH, 'r', encoding='utf-8') as f:
    html = f.read()

# Color palette (consistent with existing figures)
C_BLUE = "#2c5f8a"
C_ORANGE = "#c1572f"
C_GREEN = "#2f7d4f"
C_PURPLE = "#6a4c93"
C_LIGHT = "#e8eef3"
C_DARK = "#1a1a2e"
C_GRAY = "#6c757d"

# ============================================================
# Figure 1: Post-training pipeline (Chapter 4)
# ============================================================
fig_post_training = f'''<figure class="textbook-fig"><svg xmlns="http://www.w3.org/2000/svg" width="820" height="200" viewBox="0 0 820 200"><defs><marker id="ah-pt" markerWidth="10" markerHeight="10" refX="8" refY="3" orient="auto"><path d="M0,0 L8,3 L0,6 z" fill="{C_GRAY}"/></marker></defs>
<!-- Base model -->
<rect x="10" y="65" width="120" height="70" rx="8" fill="{C_LIGHT}" stroke="{C_BLUE}" stroke-width="2"/>
<text x="70" y="95" text-anchor="middle" font-size="13" fill="{C_DARK}" font-family="sans-serif">预训练模型</text>
<text x="70" y="115" text-anchor="middle" font-size="10" fill="{C_GRAY}" font-family="sans-serif">只会续写</text>
<!-- Arrow -->
<line x1="130" y1="100" x2="175" y2="100" stroke="{C_GRAY}" stroke-width="2" marker-end="url(#ah-pt)"/>
<!-- SFT -->
<rect x="180" y="55" width="140" height="90" rx="8" fill="{C_LIGHT}" stroke="{C_BLUE}" stroke-width="2"/>
<text x="250" y="80" text-anchor="middle" font-size="13" fill="{C_DARK}" font-family="sans-serif">SFT</text>
<text x="250" y="98" text-anchor="middle" font-size="10" fill="{C_GRAY}" font-family="sans-serif">监督微调</text>
<text x="250" y="115" text-anchor="middle" font-size="9" fill="{C_GRAY}" font-family="sans-serif">指令数据</text>
<text x="250" y="130" text-anchor="middle" font-size="9" fill="{C_GRAY}" font-family="sans-serif">学会听指令</text>
<!-- Arrow -->
<line x1="320" y1="100" x2="365" y2="100" stroke="{C_GRAY}" stroke-width="2" marker-end="url(#ah-pt)"/>
<!-- RLHF/RLVR -->
<rect x="370" y="55" width="140" height="90" rx="8" fill="{C_LIGHT}" stroke="{C_ORANGE}" stroke-width="2"/>
<text x="440" y="80" text-anchor="middle" font-size="13" fill="{C_DARK}" font-family="sans-serif">人类对齐</text>
<text x="440" y="98" text-anchor="middle" font-size="10" fill="{C_GRAY}" font-family="sans-serif">RLHF / RLVR</text>
<text x="440" y="115" text-anchor="middle" font-size="9" fill="{C_GRAY}" font-family="sans-serif">偏好校准</text>
<text x="440" y="130" text-anchor="middle" font-size="9" fill="{C_GRAY}" font-family="sans-serif">安全无害</text>
<!-- Arrow -->
<line x1="510" y1="100" x2="555" y2="100" stroke="{C_GRAY}" stroke-width="2" marker-end="url(#ah-pt)"/>
<!-- Reasoning -->
<rect x="560" y="55" width="140" height="90" rx="8" fill="{C_LIGHT}" stroke="{C_GREEN}" stroke-width="2"/>
<text x="630" y="80" text-anchor="middle" font-size="13" fill="{C_DARK}" font-family="sans-serif">推理训练</text>
<text x="630" y="98" text-anchor="middle" font-size="10" fill="{C_GRAY}" font-family="sans-serif">长思维链</text>
<text x="630" y="115" text-anchor="middle" font-size="9" fill="{C_GRAY}" font-family="sans-serif">RLVR</text>
<text x="630" y="130" text-anchor="middle" font-size="9" fill="{C_GRAY}" font-family="sans-serif">分步推理</text>
<!-- Arrow -->
<line x1="700" y1="100" x2="745" y2="100" stroke="{C_GRAY}" stroke-width="2" marker-end="url(#ah-pt)"/>
<!-- Final -->
<rect x="750" y="65" width="60" height="70" rx="8" fill="{C_GREEN}" stroke="{C_GREEN}" stroke-width="2"/>
<text x="780" y="95" text-anchor="middle" font-size="12" fill="white" font-family="sans-serif">可用</text>
<text x="780" y="112" text-anchor="middle" font-size="12" fill="white" font-family="sans-serif">助手</text>
<!-- Labels below -->
<text x="70" y="170" text-anchor="middle" font-size="9" fill="{C_GRAY}" font-family="sans-serif">基座</text>
<text x="250" y="170" text-anchor="middle" font-size="9" fill="{C_GRAY}" font-family="sans-serif">阶段一</text>
<text x="440" y="170" text-anchor="middle" font-size="9" fill="{C_GRAY}" font-family="sans-serif">阶段二</text>
<text x="630" y="170" text-anchor="middle" font-size="9" fill="{C_GRAY}" font-family="sans-serif">阶段三</text>
<text x="780" y="170" text-anchor="middle" font-size="9" fill="{C_GRAY}" font-family="sans-serif">部署</text>
</svg><figcaption>图 4-1 后训练三阶段流水线：从"只会续写"到"可用助手"</figcaption></figure>'''

# Insert after the post-training overview table, before 4.0.2
html = html.replace(
    '<h3>4.0.2 预训练模型与微调后模型的对比</h3>',
    fig_post_training + '\n<h3>4.0.2 预训练模型与微调后模型的对比</h3>'
)

# ============================================================
# Figure 2: Scaling Laws comparison (Chapter 3)
# ============================================================
fig_scaling = f'''<figure class="textbook-fig"><svg xmlns="http://www.w3.org/2000/svg" width="820" height="380" viewBox="0 0 820 380">
<!-- Axes -->
<line x1="80" y1="320" x2="780" y2="320" stroke="{C_DARK}" stroke-width="2"/>
<line x1="80" y1="320" x2="80" y2="40" stroke="{C_DARK}" stroke-width="2"/>
<!-- Axis labels -->
<text x="430" y="360" text-anchor="middle" font-size="13" fill="{C_DARK}" font-family="sans-serif">计算量 C (对数刻度)</text>
<text x="30" y="180" text-anchor="middle" font-size="13" fill="{C_DARK}" font-family="sans-serif" transform="rotate(-90 30 180)">损失 Loss</text>
<!-- Tick marks -->
<text x="80" y="338" text-anchor="middle" font-size="9" fill="{C_GRAY}" font-family="sans-serif">10²⁰</text>
<text x="250" y="338" text-anchor="middle" font-size="9" fill="{C_GRAY}" font-family="sans-serif">10²¹</text>
<text x="420" y="338" text-anchor="middle" font-size="9" fill="{C_GRAY}" font-family="sans-serif">10²²</text>
<text x="590" y="338" text-anchor="middle" font-size="9" fill="{C_GRAY}" font-family="sans-serif">10²³</text>
<text x="760" y="338" text-anchor="middle" font-size="9" fill="{C_GRAY}" font-family="sans-serif">10²⁴</text>
<!-- KM curve (blue, steeper descent emphasizing params) -->
<path d="M 80 280 Q 200 250 350 210 Q 500 180 650 155 Q 720 145 780 140" fill="none" stroke="{C_BLUE}" stroke-width="2.5"/>
<text x="700" y="135" font-size="11" fill="{C_BLUE}" font-family="sans-serif">KM 法则</text>
<!-- Chinchilla curve (orange, lower loss at same compute) -->
<path d="M 80 285 Q 200 240 350 195 Q 500 160 650 130 Q 720 115 780 108" fill="none" stroke="{C_ORANGE}" stroke-width="2.5"/>
<text x="700" y="100" font-size="11" fill="{C_ORANGE}" font-family="sans-serif">Chinchilla 法则</text>
<!-- Annotation: "Chinchilla更优" -->
<line x1="500" y1="175" x2="500" y2="160" stroke="{C_GRAY}" stroke-width="1" stroke-dasharray="3,3"/>
<text x="510" y="172" font-size="10" fill="{C_GRAY}" font-family="sans-serif">相同算力，Chinchilla 损失更低</text>
<!-- Legend box -->
<rect x="100" y="50" width="220" height="65" rx="5" fill="white" stroke="{C_GRAY}" stroke-width="1"/>
<line x1="115" y1="70" x2="145" y2="70" stroke="{C_BLUE}" stroke-width="2.5"/>
<text x="155" y="74" font-size="10" fill="{C_DARK}" font-family="sans-serif">KM: 参数优先 (2020)</text>
<line x1="115" y1="95" x2="145" y2="95" stroke="{C_ORANGE}" stroke-width="2.5"/>
<text x="155" y="99" font-size="10" fill="{C_DARK}" font-family="sans-serif">Chinchilla: 参数≈数据 (2022)</text>
<!-- Title -->
<text x="430" y="25" text-anchor="middle" font-size="14" fill="{C_DARK}" font-family="sans-serif" font-weight="bold">扩展法则：损失随算力的下降趋势</text>
</svg><figcaption>图 3-5 KM 法则 vs Chinchilla 法则：相同算力下，参数与数据均衡分配的 Chinchilla 更优</figcaption></figure>'''

# Insert after the Chinchilla table
html = html.replace(
    '<div class="note">认证常考：Chinchilla 法则指出"计算最优"的模型不是最大的模型',
    fig_scaling + '\n<div class="note">认证常考：Chinchilla 法则指出"计算最优"的模型不是最大的模型'
)

# ============================================================
# Figure 3: Model compression methods (Chapter 5)
# ============================================================
fig_compression = f'''<figure class="textbook-fig"><svg xmlns="http://www.w3.org/2000/svg" width="820" height="280" viewBox="0 0 820 280">
<!-- Title -->
<text x="410" y="25" text-anchor="middle" font-size="14" fill="{C_DARK}" font-family="sans-serif" font-weight="bold">模型压缩三种方法对比</text>
<!-- Original model -->
<rect x="30" y="100" width="100" height="80" rx="8" fill="{C_BLUE}" stroke="{C_BLUE}" stroke-width="2"/>
<text x="80" y="135" text-anchor="middle" font-size="12" fill="white" font-family="sans-serif">原始模型</text>
<text x="80" y="155" text-anchor="middle" font-size="10" fill="white" font-family="sans-serif">FP16 / 14GB</text>
<!-- Three arrows -->
<line x1="130" y1="120" x2="220" y2="60" stroke="{C_GRAY}" stroke-width="1.5" marker-end="url(#ah-pt)"/>
<line x1="130" y1="140" x2="220" y2="140" stroke="{C_GRAY}" stroke-width="1.5" marker-end="url(#ah-pt)"/>
<line x1="130" y1="160" x2="220" y2="220" stroke="{C_GRAY}" stroke-width="1.5" marker-end="url(#ah-pt)"/>
<!-- Quantization -->
<rect x="230" y="35" width="160" height="55" rx="8" fill="{C_LIGHT}" stroke="{C_ORANGE}" stroke-width="2"/>
<text x="310" y="58" text-anchor="middle" font-size="12" fill="{C_DARK}" font-family="sans-serif">量化 (Quantization)</text>
<text x="310" y="76" text-anchor="middle" font-size="9" fill="{C_GRAY}" font-family="sans-serif">FP16→INT8/INT4</text>
<rect x="410" y="35" width="120" height="55" rx="8" fill="{C_LIGHT}" stroke="{C_ORANGE}" stroke-width="1.5" stroke-dasharray="4,2"/>
<text x="470" y="58" text-anchor="middle" font-size="10" fill="{C_DARK}" font-family="sans-serif">显存减少 2-4 倍</text>
<text x="470" y="76" text-anchor="middle" font-size="9" fill="{C_GRAY}" font-family="sans-serif">精度略降</text>
<!-- Distillation -->
<rect x="230" y="115" width="160" height="55" rx="8" fill="{C_LIGHT}" stroke="{C_GREEN}" stroke-width="2"/>
<text x="310" y="138" text-anchor="middle" font-size="12" fill="{C_DARK}" font-family="sans-serif">蒸馏 (Distillation)</text>
<text x="310" y="156" text-anchor="middle" font-size="9" fill="{C_GRAY}" font-family="sans-serif">大模型教小模型</text>
<rect x="410" y="115" width="120" height="55" rx="8" fill="{C_LIGHT}" stroke="{C_GREEN}" stroke-width="1.5" stroke-dasharray="4,2"/>
<text x="470" y="138" text-anchor="middle" font-size="10" fill="{C_DARK}" font-family="sans-serif">参数量减少</text>
<text x="470" y="156" text-anchor="middle" font-size="9" fill="{C_GRAY}" font-family="sans-serif">保留软标签知识</text>
<!-- Pruning -->
<rect x="230" y="195" width="160" height="55" rx="8" fill="{C_LIGHT}" stroke="{C_PURPLE}" stroke-width="2"/>
<text x="310" y="218" text-anchor="middle" font-size="12" fill="{C_DARK}" font-family="sans-serif">剪枝 (Pruning)</text>
<text x="310" y="236" text-anchor="middle" font-size="9" fill="{C_GRAY}" font-family="sans-serif">删除冗余参数</text>
<rect x="410" y="195" width="120" height="55" rx="8" fill="{C_LIGHT}" stroke="{C_PURPLE}" stroke-width="1.5" stroke-dasharray="4,2"/>
<text x="470" y="218" text-anchor="middle" font-size="10" fill="{C_DARK}" font-family="sans-serif">稀疏化</text>
<text x="470" y="236" text-anchor="middle" font-size="9" fill="{C_GRAY}" font-family="sans-serif">加速推理</text>
<!-- Combined result -->
<line x1="530" y1="120" x2="600" y2="120" stroke="{C_GRAY}" stroke-width="1.5" marker-end="url(#ah-pt)"/>
<line x1="530" y1="140" x2="600" y2="140" stroke="{C_GRAY}" stroke-width="1.5" marker-end="url(#ah-pt)"/>
<line x1="530" y1="160" x2="600" y2="160" stroke="{C_GRAY}" stroke-width="1.5" marker-end="url(#ah-pt)"/>
<rect x="610" y="100" width="120" height="80" rx="8" fill="{C_GREEN}" stroke="{C_GREEN}" stroke-width="2"/>
<text x="670" y="130" text-anchor="middle" font-size="12" fill="white" font-family="sans-serif">压缩后模型</text>
<text x="670" y="150" text-anchor="middle" font-size="10" fill="white" font-family="sans-serif">INT4 / 3.5GB</text>
<text x="670" y="168" text-anchor="middle" font-size="9" fill="white" font-family="sans-serif">可跑在消费级 GPU</text>
<defs><marker id="ah-pt" markerWidth="10" markerHeight="10" refX="8" refY="3" orient="auto"><path d="M0,0 L8,3 L0,6 z" fill="{C_GRAY}"/></marker></defs>
</svg><figcaption>图 5-4 模型压缩三件套：量化、蒸馏、剪枝各有侧重，可组合使用</figcaption></figure>'''

# Insert after the pruning section, before key-box
html = html.replace(
    '<div class="key-box">\n<h4>认证要点</h4>\n<ul>\n<li>贪心搜索每步取最大概率',
    fig_compression + '\n<div class="key-box">\n<h4>认证要点</h4>\n<ul>\n<li>贪心搜索每步取最大概率'
)

# ============================================================
# Figure 4: Decoding strategy comparison (Chapter 5)
# ============================================================
fig_decoding = f'''<figure class="textbook-fig"><svg xmlns="http://www.w3.org/2000/svg" width="820" height="260" viewBox="0 0 820 260">
<text x="410" y="25" text-anchor="middle" font-size="14" fill="{C_DARK}" font-family="sans-serif" font-weight="bold">三种解码策略对比</text>
<!-- Greedy -->
<rect x="30" y="50" width="230" height="180" rx="8" fill="{C_LIGHT}" stroke="{C_BLUE}" stroke-width="2"/>
<text x="145" y="75" text-anchor="middle" font-size="12" fill="{C_DARK}" font-family="sans-serif" font-weight="bold">贪心搜索</text>
<line x1="50" y1="85" x2="240" y2="85" stroke="{C_GRAY}" stroke-width="1"/>
<text x="50" y="105" font-size="10" fill="{C_DARK}" font-family="sans-serif">每步选概率最高的词元</text>
<text x="50" y="125" font-size="10" fill="{C_DARK}" font-family="sans-serif">结果确定、可复现</text>
<text x="50" y="145" font-size="10" fill="{C_DARK}" font-family="sans-serif">缺点：输出千篇一律</text>
<rect x="50" y="160" width="190" height="30" rx="4" fill="{C_BLUE}" stroke="none"/>
<text x="145" y="180" text-anchor="middle" font-size="10" fill="white" font-family="sans-serif">适合：数学、代码</text>
<text x="50" y="210" font-size="9" fill="{C_GRAY}" font-family="sans-serif">T=0 或 argmax</text>
<!-- Beam Search -->
<rect x="295" y="50" width="230" height="180" rx="8" fill="{C_LIGHT}" stroke="{C_ORANGE}" stroke-width="2"/>
<text x="410" y="75" text-anchor="middle" font-size="12" fill="{C_DARK}" font-family="sans-serif" font-weight="bold">束搜索 (Beam)</text>
<line x1="315" y1="85" x2="505" y2="85" stroke="{C_GRAY}" stroke-width="1"/>
<text x="315" y="105" font-size="10" fill="{C_DARK}" font-family="sans-serif">保留 B 条最优路径</text>
<text x="315" y="125" font-size="10" fill="{C_DARK}" font-family="sans-serif">选累计概率最高的</text>
<text x="315" y="145" font-size="10" fill="{C_DARK}" font-family="sans-serif">平衡准确性和多样性</text>
<rect x="315" y="160" width="190" height="30" rx="4" fill="{C_ORANGE}" stroke="none"/>
<text x="410" y="180" text-anchor="middle" font-size="10" fill="white" font-family="sans-serif">适合：翻译、摘要</text>
<text x="315" y="210" font-size="9" fill="{C_GRAY}" font-family="sans-serif">beam=4~5</text>
<!-- Sampling -->
<rect x="560" y="50" width="230" height="180" rx="8" fill="{C_LIGHT}" stroke="{C_GREEN}" stroke-width="2"/>
<text x="675" y="75" text-anchor="middle" font-size="12" fill="{C_DARK}" font-family="sans-serif" font-weight="bold">温度采样</text>
<line x1="580" y1="85" x2="770" y2="85" stroke="{C_GRAY}" stroke-width="1"/>
<text x="580" y="105" font-size="10" fill="{C_DARK}" font-family="sans-serif">按概率分布随机抽</text>
<text x="580" y="125" font-size="10" fill="{C_DARK}" font-family="sans-serif">每次结果可能不同</text>
<text x="580" y="145" font-size="10" fill="{C_DARK}" font-family="sans-serif">多样性高，可能不连贯</text>
<rect x="580" y="160" width="190" height="30" rx="4" fill="{C_GREEN}" stroke="none"/>
<text x="675" y="180" text-anchor="middle" font-size="10" fill="white" font-family="sans-serif">适合：创意写作、对话</text>
<text x="580" y="210" font-size="9" fill="{C_GRAY}" font-family="sans-serif">T=0.7~1.0 + top-p</text>
</svg><figcaption>图 5-3 三种解码策略：贪心追求确定性，束搜索平衡质量，采样追求多样性</figcaption></figure>'''

# Insert after the decoding case table
html = html.replace(
    '<div class="note">实战选择：写代码 / 数学题用贪心或 T=0.1',
    fig_decoding + '\n<div class="note">实战选择：写代码 / 数学题用贪心或 T=0.1'
)

# ============================================================
# Figure 5: Causal mask visualization (Chapter 2)
# ============================================================
fig_causal_mask = f'''<figure class="textbook-fig"><svg xmlns="http://www.w3.org/2000/svg" width="500" height="320" viewBox="0 0 500 320">
<text x="250" y="25" text-anchor="middle" font-size="14" fill="{C_DARK}" font-family="sans-serif" font-weight="bold">因果掩码示意图（4 个词元）</text>
<!-- Column headers -->
<text x="180" y="55" text-anchor="middle" font-size="11" fill="{C_DARK}" font-family="sans-serif">春</text>
<text x="230" y="55" text-anchor="middle" font-size="11" fill="{C_DARK}" font-family="sans-serif">风</text>
<text x="280" y="55" text-anchor="middle" font-size="11" fill="{C_DARK}" font-family="sans-serif">又</text>
<text x="330" y="55" text-anchor="middle" font-size="11" fill="{C_DARK}" font-family="sans-serif">绿</text>
<!-- Row headers -->
<text x="140" y="90" text-anchor="middle" font-size="11" fill="{C_DARK}" font-family="sans-serif">春</text>
<text x="140" y="140" text-anchor="middle" font-size="11" fill="{C_DARK}" font-family="sans-serif">风</text>
<text x="140" y="190" text-anchor="middle" font-size="11" fill="{C_DARK}" font-family="sans-serif">又</text>
<text x="140" y="240" text-anchor="middle" font-size="11" fill="{C_DARK}" font-family="sans-serif">绿</text>
<!-- Grid: 4x4, each cell 50x50, starting at (155, 65) -->
<!-- Row 1: 春 -->
<rect x="155" y="65" width="50" height="50" fill="{C_GREEN}" fill-opacity="0.3" stroke="{C_GRAY}" stroke-width="1"/>
<rect x="205" y="65" width="50" height="50" fill="{C_GRAY}" fill-opacity="0.6" stroke="{C_GRAY}" stroke-width="1"/>
<rect x="255" y="65" width="50" height="50" fill="{C_GRAY}" fill-opacity="0.6" stroke="{C_GRAY}" stroke-width="1"/>
<rect x="305" y="65" width="50" height="50" fill="{C_GRAY}" fill-opacity="0.6" stroke="{C_GRAY}" stroke-width="1"/>
<!-- Row 2: 风 -->
<rect x="155" y="115" width="50" height="50" fill="{C_GREEN}" fill-opacity="0.3" stroke="{C_GRAY}" stroke-width="1"/>
<rect x="205" y="115" width="50" height="50" fill="{C_GREEN}" fill-opacity="0.3" stroke="{C_GRAY}" stroke-width="1"/>
<rect x="255" y="115" width="50" height="50" fill="{C_GRAY}" fill-opacity="0.6" stroke="{C_GRAY}" stroke-width="1"/>
<rect x="305" y="115" width="50" height="50" fill="{C_GRAY}" fill-opacity="0.6" stroke="{C_GRAY}" stroke-width="1"/>
<!-- Row 3: 又 -->
<rect x="155" y="165" width="50" height="50" fill="{C_GREEN}" fill-opacity="0.3" stroke="{C_GRAY}" stroke-width="1"/>
<rect x="205" y="165" width="50" height="50" fill="{C_GREEN}" fill-opacity="0.3" stroke="{C_GRAY}" stroke-width="1"/>
<rect x="255" y="165" width="50" height="50" fill="{C_GREEN}" fill-opacity="0.3" stroke="{C_GRAY}" stroke-width="1"/>
<rect x="305" y="165" width="50" height="50" fill="{C_GRAY}" fill-opacity="0.6" stroke="{C_GRAY}" stroke-width="1"/>
<!-- Row 4: 绿 -->
<rect x="155" y="215" width="50" height="50" fill="{C_GREEN}" fill-opacity="0.3" stroke="{C_GRAY}" stroke-width="1"/>
<rect x="205" y="215" width="50" height="50" fill="{C_GREEN}" fill-opacity="0.3" stroke="{C_GRAY}" stroke-width="1"/>
<rect x="255" y="215" width="50" height="50" fill="{C_GREEN}" fill-opacity="0.3" stroke="{C_GRAY}" stroke-width="1"/>
<rect x="305" y="215" width="50" height="50" fill="{C_GREEN}" fill-opacity="0.3" stroke="{C_GRAY}" stroke-width="1"/>
<!-- Legend -->
<rect x="380" y="90" width="20" height="20" fill="{C_GREEN}" fill-opacity="0.3" stroke="{C_GRAY}" stroke-width="1"/>
<text x="410" y="105" font-size="10" fill="{C_DARK}" font-family="sans-serif">可看到</text>
<rect x="380" y="120" width="20" height="20" fill="{C_GRAY}" fill-opacity="0.6" stroke="{C_GRAY}" stroke-width="1"/>
<text x="410" y="135" font-size="10" fill="{C_DARK}" font-family="sans-serif">被遮蔽</text>
<!-- Annotation -->
<text x="250" y="295" text-anchor="middle" font-size="10" fill="{C_GRAY}" font-family="sans-serif">"风"只能看到"春"和自己，看不到"又"和"绿"</text>
</svg><figcaption>图 2-4 因果掩码：对角线以下可看到（绿色），以上被遮蔽（灰色），确保自回归生成</figcaption></figure>'''

# Insert after the masking note
html = html.replace(
    '<div class="note">认证常考：因果解码器（如 GPT/Qwen）使用因果掩码确保自回归生成',
    fig_causal_mask + '\n<div class="note">认证常考：因果解码器（如 GPT/Qwen）使用因果掩码确保自回归生成'
)

with open(HTML_PATH, 'w', encoding='utf-8') as f:
    f.write(html)

# Verify
svg_count = html.count('<svg')
print(f"Total SVGs: {svg_count}")
# Check new figures are present
for fig_name in ['图 4-1', '图 3-5', '图 5-4', '图 5-3', '图 2-4']:
    if fig_name in html:
        print(f"  Found: {fig_name}")
    else:
        print(f"  MISSING: {fig_name}")
print("Done!")
