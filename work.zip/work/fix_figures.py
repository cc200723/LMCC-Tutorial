#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Patch non-standard / defective SVG figures in the enhanced textbook."""
import re, shutil, os

HTML = "LMCC青少年组教材-增强版.html"
backup = HTML + ".fig-fix-backup"
if not os.path.exists(backup):
    shutil.copy(HTML, backup)

html = open(HTML, encoding="utf-8").read()

# ---------- 1. Fix X-placeholder captions (and remove emoji in 5-X, 10-2 later) ----------
# Order matters: replace caption text first, then SVG content.
html = html.replace(
    '<figcaption>图 5-X 模型压缩三件套对比：蒸馏（大教小）、剪枝（去冗余）、量化（降精度）</figcaption>',
    '<figcaption>图 5-3 模型压缩三件套对比：蒸馏（大教小）、剪枝（去冗余）、量化（降精度）</figcaption>')
html = html.replace(
    '<figcaption>图 6-X 提示工程四种常见模式对比：零样本、少样本、思维链、检索增强</figcaption>',
    '<figcaption>图 6-4 提示工程四种常见模式对比：零样本、少样本、思维链、检索增强</figcaption>')
html = html.replace(
    '<figcaption>图 7-X Self-Consistency（多次独立采样→多数投票）与 Tree-of-Thoughts（树状搜索→最优路径）对比</figcaption>',
    '<figcaption>图 7-2 Self-Consistency（多次独立采样→多数投票）与 Tree-of-Thoughts（树状搜索→最优路径）对比</figcaption>')
html = html.replace(
    '<figcaption>图 8-X 四大公开评测集对比：MMLU（英文知识面）、BIG-Bench（极端能力）、HELM（综合评价）、C-Eval（中文知识）</figcaption>',
    '<figcaption>图 8-3 四大公开评测集对比：MMLU（英文知识面）、BIG-Bench（极端能力）、HELM（综合评价）、C-Eval（中文知识）</figcaption>')
html = html.replace(
    '<figcaption>图 9-X 多智能体三种通信结构：星型、链式、全连接</figcaption>',
    '<figcaption>图 9-3 多智能体三种通信结构：星型、链式、全连接</figcaption>')

# Also update SVG titles that may reference the figure number? None do, but be safe with anchors in the text.

# ---------- 2. Fix figure 0-1 bottom-left clipping ----------
# Move the 4 items in the bottom-left green box from y=392,434,476,518 to y=392,430,468,506
# (tighten spacing from 42 to 38, so the last item stays inside the box ending at y=510).
html = html.replace('y="518.0">多模态模型', 'y="506.0">多模态模型')
# Also shift the other two items in the same box for consistent spacing
html = html.replace('y="476.0">智能体与工具', 'y="468.0">智能体与工具')
html = html.replace('y="434.0">检索增强 RAG', 'y="430.0">检索增强 RAG')

# ---------- 3. Fix figure 1-11 header text clipping ----------
# Replace the top header paths with full-width header rects, and lower text baseline.
html = html.replace(
    '<path d="M 40,75 a 8,8 0 0 1 -8,-8 h 344 a 8,8 0 0 1 8,8 v 20 h -360 Z" fill="#2c5f8a"/>',
    '<rect x="40" y="55" width="360" height="40" rx="8" fill="#2c5f8a"/>')
html = html.replace(
    '<path d="M 440,75 a 8,8 0 0 1 -8,-8 h 344 a 8,8 0 0 1 8,8 v 20 h -360 Z" fill="#c1572f"/>',
    '<rect x="440" y="55" width="360" height="40" rx="8" fill="#c1572f"/>')
html = html.replace('y="70" text-anchor="middle" fill="white" font-size="14" font-weight="600">国际主流代表', 'y="82" text-anchor="middle" fill="white" font-size="14" font-weight="600">国际主流代表')
html = html.replace('y="70" text-anchor="middle" fill="white" font-size="14" font-weight="600">国内代表模型', 'y="82" text-anchor="middle" fill="white" font-size="14" font-weight="600">国内代表模型')

# ---------- 4. Fix figure 8-2 empty header boxes (drawing order bug) ----------
# Left branch: white rect currently drawn after colored header/text, covering them.
# Reorder with regex so whitespace variations are tolerated: rect -> path -> text.
html = re.sub(
    r'(<path d="M40,122 a10,10 0 0 1 10,-10 h355 a10,10 0 0 1 10,10 v20 h-375 Z" fill="#c1572f"/>)\s*'
    r'(<text x="227\.5" y="132" text-anchor="middle" fill="white" font-size="14" font-weight="600">客观评测（可计算）</text>)\s*'
    r'(<rect x="40" y="112" width="375" height="44" rx="10" fill="#f4f7fa" stroke="#cfd6dd" stroke-width="1\.5"/>)',
    r'\3\n\1\n\2', html, flags=re.S)
html = re.sub(
    r'(<path d="M435,122 a10,10 0 0 1 10,-10 h355 a10,10 0 0 1 10,10 v20 h-375 Z" fill="#3a7d44"/>)\s*'
    r'(<text x="622\.5" y="132" text-anchor="middle" fill="white" font-size="14" font-weight="600">主观评测（人/模型判）</text>)\s*'
    r'(<rect x="435" y="112" width="375" height="44" rx="10" fill="#f4f7fa" stroke="#cfd6dd" stroke-width="1\.5"/>)',
    r'\3\n\1\n\2', html, flags=re.S)

# ---------- 4b. Fix figure 4-1 colored emoji circles ----------
html = html.replace(
    '<text x="330" y="110" font-family=\'Noto Sans CJK SC,Microsoft YaHei,PingFang SC,sans-serif\' font-size="11.5" fill="#1f2a37">🔴 事实性（与事实不符）</text>',
    '<circle cx="336" cy="106" r="6" fill="#d32f2f"/><text x="350" y="110" font-family=\'Noto Sans CJK SC,Microsoft YaHei,PingFang SC,sans-serif\' font-size="11.5" fill="#1f2a37">事实性（与事实不符）</text>')
html = html.replace(
    '<text x="330" y="140" font-family=\'Noto Sans CJK SC,Microsoft YaHei,PingFang SC,sans-serif\' font-size="11.5" fill="#1f2a37">🟠 忠实度（偏离上下文）</text>',
    '<circle cx="336" cy="136" r="6" fill="#f57c00"/><text x="350" y="140" font-family=\'Noto Sans CJK SC,Microsoft YaHei,PingFang SC,sans-serif\' font-size="11.5" fill="#1f2a37">忠实度（偏离上下文）</text>')
html = html.replace(
    '<text x="330" y="170" font-family=\'Noto Sans CJK SC,Microsoft YaHei,PingFang SC,sans-serif\' font-size="11.5" fill="#1f2a37">🟡 逻辑（推理链错误）</text>',
    '<circle cx="336" cy="166" r="6" fill="#f9a825"/><text x="350" y="170" font-family=\'Noto Sans CJK SC,Microsoft YaHei,PingFang SC,sans-serif\' font-size="11.5" fill="#1f2a37">逻辑（推理链错误）</text>')
html = html.replace(
    '<text x="330" y="200" font-family=\'Noto Sans CJK SC,Microsoft YaHei,PingFang SC,sans-serif\' font-size="11.5" fill="#1f2a37">🔵 虚构引用（编造来源）</text>',
    '<circle cx="336" cy="196" r="6" fill="#1976d2"/><text x="350" y="200" font-family=\'Noto Sans CJK SC,Microsoft YaHei,PingFang SC,sans-serif\' font-size="11.5" fill="#1f2a37">虚构引用（编造来源）</text>')

# ---------- 5. Fix figure 5-X emoji headers ----------
html = html.replace('y="79">🧑‍🏫 蒸馏 Distillation', 'y="79">蒸馏 Distillation')
html = html.replace('y="79">📦 量化 Quantization', 'y="79">量化 Quantization')

# ---------- 6. Fix figure 10-2 emoji icons, center the labels ----------
# Remove emoji text elements and center the Chinese labels inside each modality box.
html = html.replace(
    '<text font-family=\'Noto Sans CJK SC,Microsoft YaHei,PingFang SC,sans-serif\' font-size="22" text-anchor="middle" x="380" y="100">📝</text>\n<text font-family=\'Noto Sans CJK SC,Microsoft YaHei,PingFang SC,sans-serif\' font-size="13" fill="#1f6f9c" font-weight="700" text-anchor="middle" x="445" y="100">文本</text>',
    '<text font-family=\'Noto Sans CJK SC,Microsoft YaHei,PingFang SC,sans-serif\' font-size="13" fill="#1f6f9c" font-weight="700" text-anchor="middle" x="420" y="100">文本</text>')
html = html.replace(
    '<text font-family=\'Noto Sans CJK SC,Microsoft YaHei,PingFang SC,sans-serif\' font-size="22" text-anchor="middle" x="100" y="250">🖼️</text>\n<text font-family=\'Noto Sans CJK SC,Microsoft YaHei,PingFang SC,sans-serif\' font-size="13" fill="#c1572f" font-weight="700" text-anchor="middle" x="165" y="250">图像</text>',
    '<text font-family=\'Noto Sans CJK SC,Microsoft YaHei,PingFang SC,sans-serif\' font-size="13" fill="#c1572f" font-weight="700" text-anchor="middle" x="140" y="250">图像</text>')
html = html.replace(
    '<text font-family=\'Noto Sans CJK SC,Microsoft YaHei,PingFang SC,sans-serif\' font-size="22" text-anchor="middle" x="660" y="250">🎵</text>\n<text font-family=\'Noto Sans CJK SC,Microsoft YaHei,PingFang SC,sans-serif\' font-size="13" fill="#2f7d4f" font-weight="700" text-anchor="middle" x="720" y="250">语音</text>',
    '<text font-family=\'Noto Sans CJK SC,Microsoft YaHei,PingFang SC,sans-serif\' font-size="13" fill="#2f7d4f" font-weight="700" text-anchor="middle" x="700" y="250">语音</text>')
html = html.replace(
    '<text font-family=\'Noto Sans CJK SC,Microsoft YaHei,PingFang SC,sans-serif\' font-size="22" text-anchor="middle" x="380" y="410">🎬</text>\n<text font-family=\'Noto Sans CJK SC,Microsoft YaHei,PingFang SC,sans-serif\' font-size="13" fill="#6a4c93" font-weight="700" text-anchor="middle" x="445" y="410">视频</text>',
    '<text font-family=\'Noto Sans CJK SC,Microsoft YaHei,PingFang SC,sans-serif\' font-size="13" fill="#6a4c93" font-weight="700" text-anchor="middle" x="420" y="410">视频</text>')

# ---------- 7. Fix figure 12-1 duplicated labels ----------
html = html.replace('y="96">中央服务器中央服务器', 'y="96">中央服务器')
html = html.replace('y="215">医院医院 A', 'y="215">医院 A')
html = html.replace('y="215">医院医院 B', 'y="215">医院 B')
html = html.replace('y="215">医院医院 C', 'y="215">医院 C')

# ---------- 8. Replace remaining emoji checkmarks/pins with monochrome symbols ----------
html = html.replace('✅', '✓')
html = html.replace('❌', '✗')
html = html.replace('📌', '•')

# ---------- Save ----------
open(HTML, "w", encoding="utf-8").write(html)
print("Figure fixes applied and saved.")
print("Backup at:", backup)
