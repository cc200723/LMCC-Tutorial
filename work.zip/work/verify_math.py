# -*- coding: utf-8 -*-
"""Verify KaTeX math renders non-blank in the built HTML."""
import os
from playwright.sync_api import sync_playwright

HERE = os.path.dirname(os.path.abspath(__file__))
HTML = os.path.join(HERE, "..", "LMCC青少年组教材.html")
HTML = os.path.abspath(HTML)

with sync_playwright() as p:
    b = p.chromium.launch(args=["--no-sandbox"])
    pg = b.new_page(viewport={"width": 1000, "height": 800})
    pg.goto("file://" + HTML, wait_until="load")
    pg.wait_for_timeout(1200)  # let deferred katex + auto-render run
    info = pg.evaluate("""()=>{
        const katex = document.querySelectorAll('.katex');
        let rendered=0, blank=0, errs=0;
        katex.forEach(el=>{
            const r = el.getBoundingClientRect();
            if (r.width>0 && r.height>0) rendered++; else blank++;
        });
        document.querySelectorAll('.katex-error').forEach(()=>errs++);
        // count math blocks and inline
        const blocks = document.querySelectorAll('.math-block');
        const inline = document.querySelectorAll('p .katex, li .katex, td .katex, span.katex');
        return {
            totalKatex: katex.length,
            rendered, blank, errs,
            blockDivs: blocks.length,
            hasRenderFn: typeof window.renderMathInElement
        };
    }""")
    print("KaTeX 渲染检查:")
    for k,v in info.items():
        print(f"  {k}: {v}")
    b.close()
