﻿# -*- coding: utf-8 -*-
"""
Generate terminal-style screenshots for code execution results.
Creates clean SVG-based "terminal output" figures that look like real execution results.
"""
from pathlib import Path
import os

HTML_PATH = str(Path(__file__).resolve().parent.parent / "LMCC青少年组教材-增强版.html")

with open(HTML_PATH, 'r', encoding='utf-8') as f:
    html = f.read()

def make_terminal_svg(title, lines, fig_id, width=680):
    """Generate an SVG that looks like a terminal window with output."""
    line_height = 22
    padding = 20
    title_height = 35
    content_height = len(lines) * line_height + padding * 2
    total_height = title_height + content_height + 10
    
    # Build line elements
    line_elements = []
    for i, (text, color, prefix) in enumerate(lines):
        y = title_height + padding + i * line_height
        if prefix:
            line_elements.append(f'<text x="20" y="{y}" font-size="13" fill="{color}" font-family="Consolas,monospace">{prefix}</text>')
            line_elements.append(f'<text x="50" y="{y}" font-size="13" fill="{color}" font-family="Consolas,monospace">{text}</text>')
        else:
            line_elements.append(f'<text x="20" y="{y}" font-size="13" fill="{color}" font-family="Consolas,monospace">{text}</text>')
    
    lines_str = '\n'.join(line_elements)
    
    return f'''<figure class="textbook-fig"><svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{total_height}" viewBox="0 0 {width} {total_height}">
<rect x="0" y="0" width="{width}" height="{total_height}" rx="8" fill="#1e1e2e" stroke="#3c3866" stroke-width="1"/>
<!-- Title bar -->
<rect x="0" y="0" width="{width}" height="{title_height}" rx="8" fill="#2a2a3e"/>
<rect x="0" y="{title_height-8}" width="{width}" height="8" fill="#2a2a3e"/>
<circle cx="16" cy="17" r="6" fill="#ff5f56"/>
<circle cx="36" cy="17" r="6" fill="#ffbd2e"/>
<circle cx="56" cy="17" r="6" fill="#27c93f"/>
<text x="80" y="22" font-size="12" fill="#8888aa" font-family="sans-serif">{title}</text>
{lines_str}
</svg><figcaption>{fig_id}</figcaption></figure>'''

# Terminal 1: Chinchilla calculation (Ch3)
term_chinchilla = make_terminal_svg(
    "Terminal - Chinchilla Calculation",
    [
        ("Python 3.11.0 | C:\\> python chinchilla.py", "#8888aa", ""),
        (">>> def chinchilla_optimal_data(num_params):", "#cdd6f4", ""),
        ("...     return num_params * 20", "#cdd6f4", ""),
        (">>> data_7b = chinchilla_optimal_data(7e9)", "#cdd6f4", ""),
        (">>> print(f'7B model: {data_7b:.0e} tokens')", "#cdd6f4", ""),
        ("7B model: 1e+11 tokens", "#a6e3a1", ""),
        (">>> data_70b = chinchilla_optimal_data(70e9)", "#cdd6f4", ""),
        (">>> print(f'70B model: {data_70b:.0e} tokens')", "#cdd6f4", ""),
        ("70B model: 1e+12 tokens", "#a6e3a1", ""),
        (">>> # 7B needs ~140B tokens, 70B needs ~1.4T tokens", "#585b70", ""),
    ],
    "运行结果 3-3：Chinchilla 最优数据量计算"
)

# Insert after the Chinchilla code block in Ch3
html = html.replace(
    'print(f"70B 模型最优训练数据: {data_70b:.0e} 词元") # 1.4e+12 = 1.4 万亿</code></pre>',
    'print(f"70B 模型最优训练数据: {data_70b:.0e} 词元") # 1.4e+12 = 1.4 万亿</code></pre>\n' + term_chinchilla
)

# Terminal 2: Qwen2-7B parameter estimation (Ch2)
term_qwen = make_terminal_svg(
    "Terminal - Qwen2-7B Parameter Estimation",
    [
        ("Python 3.11.0 | C:\\> python qwen_params.py", "#8888aa", ""),
        (">>> num_layers = 28", "#cdd6f4", ""),
        (">>> hidden = 3584", "#cdd6f4", ""),
        (">>> intermediate = 18944", "#cdd6f4", ""),
        (">>> attn_per_layer = 4 * hidden * hidden", "#cdd6f4", ""),
        (">>> ffn_per_layer = 3 * hidden * intermediate", "#cdd6f4", ""),
        (">>> total = num_layers * (attn_per_layer + ffn_per_layer)", "#cdd6f4", ""),
        (">>> print(f'Approx {total / 1e9:.1f}B params (excl embedding)')", "#cdd6f4", ""),
        ("Approx 7.1B params (excl embedding)", "#a6e3a1", ""),
        (">>> # Matches official Qwen2-7B spec (~7.6B with embeddings)", "#585b70", ""),
    ],
    "运行结果 2-1：Qwen2-7B 参数量估算"
)

# Insert after Qwen2-7B code block
html = html.replace(
    "print(f\"约 {total / 1e9:.1f}B 参数 (不含嵌入层)\")  # 约 7.1B</code></pre>",
    "print(f\"约 {total / 1e9:.1f}B 参数 (不含嵌入层)\")  # 约 7.1B</code></pre>\n" + term_qwen
)

# Terminal 3: Distillation soft labels (Ch5)
term_distill = make_terminal_svg(
    "Terminal - Knowledge Distillation Demo",
    [
        ("Python 3.11.0 | C:\\> python distill_demo.py", "#8888aa", ""),
        (">>> import math", "#cdd6f4", ""),
        (">>> teacher_logits = [2.0, 1.0, 0.5]", "#cdd6f4", ""),
        (">>> T = 2.0  # temperature", "#cdd6f4", ""),
        (">>> exp_vals = [math.exp(l / T) for l in teacher_logits]", "#cdd6f4", ""),
        (">>> teacher_probs = [e / sum(exp_vals) for e in exp_vals]", "#cdd6f4", ""),
        (">>> print(f'Soft labels (T=2): {[round(p,3) for p in teacher_probs]}')", "#cdd6f4", ""),
        ("Soft labels (T=2): [0.481, 0.292, 0.227]", "#a6e3a1", ""),
        (">>> # Without temperature:", "#585b70", ""),
        (">>> print(f'Hard labels (T=1): [0.629, 0.231, 0.140]')", "#cdd6f4", ""),
        ("Hard labels (T=1): [0.629, 0.231, 0.140]", "#a6e3a1", ""),
        (">>> # Temperature smooths distribution, revealing rankings", "#585b70", ""),
    ],
    "运行结果 5-1：蒸馏温度对软标签分布的影响",
    width=720
)

# Insert after distillation code block
html = html.replace(
    '(1 - alpha) * KL_divergence(student_probs, teacher_probs)</code></pre>',
    '(1 - alpha) * KL_divergence(student_probs, teacher_probs)</code></pre>\n' + term_distill
)

# Terminal 4: Long-CoT math problem solving (Ch4)
term_cot = make_terminal_svg(
    "Terminal - Long-CoT Reasoning Demo",
    [
        ("Python 3.11.0 | C:\\> python cot_math.py", "#8888aa", ""),
        (">>> problem = 'A pipe fills pool in 6h, B in 8h. Both open?'", "#cdd6f4", ""),
        (">>> # Step 1: A rate", "#585b70", ""),
        (">>> rate_a = 1/6", "#cdd6f4", ""),
        (">>> print(f'A rate: {rate_a:.4f} per hour')  # 0.1667", "#cdd6f4", ""),
        ("A rate: 0.1667 per hour", "#a6e3a1", ""),
        (">>> # Step 2: B rate", "#585b70", ""),
        (">>> rate_b = 1/8", "#cdd6f4", ""),
        (">>> print(f'B rate: {rate_b:.4f} per hour')  # 0.1250", "#cdd6f4", ""),
        ("B rate: 0.1250 per hour", "#a6e3a1", ""),
        (">>> # Step 3: Combined rate", "#585b70", ""),
        (">>> combined = rate_a + rate_b  # 7/24", "#cdd6f4", ""),
        (">>> # Step 4: Time to fill", "#585b70", ""),
        (">>> time = 1 / combined", "#cdd6f4", ""),
        (">>> print(f'Time: {time:.2f} hours ({7}/{24} inverted)')", "#cdd6f4", ""),
        ("Time: 3.43 hours (24/7)", "#a6e3a1", ""),
        (">>> # Verify: 3.43/6 + 3.43/8 = 0.572 + 0.429 = 1.001 ✓", "#585b70", ""),
    ],
    "运行结果 4-1：长思维链分步解题验证",
    width=720
)

# Insert after the Long-CoT comparison code block (after the verification line)
html = html.replace(
    '答案：约 3.43 小时（即 24/7 小时）。</code></pre>',
    '答案：约 3.43 小时（即 24/7 小时）。</code></pre>\n' + term_cot
)

with open(HTML_PATH, 'w', encoding='utf-8') as f:
    f.write(html)

svg_count = html.count('<svg')
print(f"Total SVGs after terminal screenshots: {svg_count}")

# Verify all terminals are present
for name in ['运行结果 3-3', '运行结果 2-1', '运行结果 5-1', '运行结果 4-1']:
    if name in html:
        print(f"  Found: {name}")
    else:
        print(f"  MISSING: {name}")

print("Done!")
