# -*- coding: utf-8 -*-
"""
LMCC 青少年组教材 · HTML 组装器
读取 chapters/ 下的 HTML 片段，内嵌 SVG 矢量图，生成单文件教材。
"""
import os, re, glob

BASE = os.path.dirname(os.path.abspath(__file__))
CHAPTER_DIR = os.path.join(BASE, "chapters")
FIG_DIR = os.path.join(BASE, "figs")
OUT_HTML = os.path.join(BASE, "..", "LMCC青少年组教材.html")

def load_svg(name):
    p = os.path.join(FIG_DIR, name)
    if not os.path.exists(p):
        return f"<!-- missing figure {name} -->"
    s = open(p, encoding="utf-8").read()
    # 去掉 XML 声明，保留 svg 标签
    s = re.sub(r'<\?xml.*?\?>', '', s).strip()
    return s

def inline_figures(html):
    def repl(m):
        attrs = m.group(1)
        src = re.search(r'data-svg="([^"]+)"', attrs)
        cap = re.search(r'data-caption="([^"]*)"', attrs)
        svg = load_svg(src.group(1)) if src else ""
        caption = f'<figcaption>{cap.group(1)}</figcaption>' if cap else ''
        return f'<figure class="textbook-fig">{svg}{caption}</figure>'
    return re.sub(r'<figure\b([^>]*)></figure>', repl, html)

def assemble():
    chapters = []
    for f in sorted(glob.glob(os.path.join(CHAPTER_DIR, "*.html"))):
        name = os.path.basename(f)
        # 排序：preface, ch01-ch10, appendix
        chapters.append((name, f))
    chapters.sort(key=lambda x: (not x[0].startswith("ch"), x[0]))

    body_parts = []
    toc_items = []
    for name, f in chapters:
        html = open(f, encoding="utf-8").read()
        # 提取标题（第一个 <h1>）
        m = re.search(r'<h1[^>]*>(.*?)</h1>', html, re.S)
        title = re.sub(r'<.*?>', '', m.group(1)) if m else name
        # 添加章锚点
        anchor = re.sub(r'[^\w\-]', '-', title)
        html = re.sub(r'<h1([^>]*)>', f'<h1 id="{anchor}"$1>', html, count=1)
        body_parts.append(f'<section class="chapter" id="sec-{anchor}">\n{html}\n</section>')
        toc_items.append(f'<li><a href="#{anchor}">{title}</a></li>')

    toc = '<nav id="toc"><h2>目录</h2><ol>' + '\n'.join(toc_items) + '</ol></nav>'
    full_body = inline_figures('\n'.join(body_parts))

    html = f'''<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>LMCC 青少年组人工智能与大模型能力认证教材</title>
<style>
:root{{
  --ink:#1a1a1a;
  --sub:#555;
  --bg:#fff;
  --panel:#f8f9fa;
  --accent:#2c5f8a;
  --accent-light:#e8f0f7;
  --orange:#c1572f;
  --green:#3a7d44;
  --border:#ddd;
  --code-bg:#f4f5f7;
}}
*{{box-sizing:border-box}}
html{{scroll-behavior:smooth}}
body{{
  margin:0; padding:0;
  font-family:Georgia,"Noto Serif CJK SC","SimSun",serif;
  font-size:16px; line-height:1.75; color:var(--ink);
  background:var(--bg);
}}
#wrapper{{
  max-width:920px; margin:0 auto; padding:48px 32px 80px;
}}
#titlepage{{
  text-align:center; padding:90px 0 60px; border-bottom:2px solid var(--ink); margin-bottom:40px;
}}
#titlepage h1{{
  font-family:"Microsoft YaHei","PingFang SC",sans-serif; font-size:34px; font-weight:700;
  margin-bottom:12px; letter-spacing:1px;
}}
#titlepage .subtitle{{
  font-size:18px; color:var(--sub); margin-bottom:8px;
}}
#titlepage .meta{{
  font-size:13px; color:#888;
}}
#toc{{
  background:var(--panel); border:1px solid var(--border); padding:22px 28px; margin:30px 0 50px;
  border-radius:5px;
}}
#toc h2{{margin:0 0 14px; font-size:20px; font-family:"Microsoft YaHei",sans-serif;}}
#toc ol{{columns:2; margin:0; padding-left:22px;}}
#toc li{{margin-bottom:6px; font-size:14px;}}
#toc a{{color:var(--ink); text-decoration:none;}}
#toc a:hover{{text-decoration:underline;}}
.chapter{{margin-bottom:60px;}}
h1{{
  font-family:"Microsoft YaHei","PingFang SC",sans-serif; font-size:28px; font-weight:700;
  color:var(--ink); border-bottom:2px solid var(--accent); padding-bottom:8px; margin:48px 0 22px;
  page-break-before:always;
}}
.chapter:first-of-type h1{{page-break-before:auto}}
h2{{
  font-family:"Microsoft YaHei","PingFang SC",sans-serif; font-size:21px; font-weight:600;
  color:var(--accent); margin:34px 0 14px;
}}
h3{{
  font-family:"Microsoft YaHei","PingFang SC",sans-serif; font-size:17px; font-weight:600;
  color:var(--ink); margin:26px 0 10px;
}}
p{{margin:0 0 14px; text-align:justify;}}
ul,ol{{margin:6px 0 14px; padding-left:28px;}}
li{{margin-bottom:5px;}}
strong{{font-weight:600; color:#111;}}
code{{
  font-family:Consolas,"SFMono-Regular",monospace; font-size:14px; background:var(--code-bg);
  padding:1px 4px; border-radius:3px; color:#2a2a2a;
}}
pre{{
  background:var(--code-bg); border:1px solid var(--border); border-radius:5px;
  padding:14px 18px; overflow-x:auto; margin:14px 0; line-height:1.55;
}}
pre code{{background:transparent; padding:0;}}
.textbook-fig{{
  margin:24px 0; text-align:center; page-break-inside:avoid;
}}
.textbook-fig svg{{
  display:block; margin:0 auto; max-width:100%; height:auto;
}}
.textbook-fig figcaption{{
  font-family:"Microsoft YaHei",sans-serif; font-size:13px; color:var(--sub);
  margin-top:8px; font-style:italic;
}}
.key-box{{
  background:var(--accent-light); border-left:4px solid var(--accent);
  padding:14px 18px; margin:22px 0; border-radius:0 6px 6px 0; page-break-inside:avoid;
}}
.key-box h4{{
  margin:0 0 8px; font-family:"Microsoft YaHei",sans-serif; font-size:15px; color:var(--accent);
}}
.key-box ul{{margin:0; padding-left:20px;}}
.exercise-box{{
  background:#fff; border:1px solid var(--border); padding:16px 20px; margin:28px 0;
  border-radius:6px; page-break-inside:avoid;
}}
.exercise-box h4{{
  margin:0 0 10px; font-family:"Microsoft YaHei",sans-serif; font-size:15px; color:var(--orange);
}}
.exercise-box ol{{margin:0; padding-left:22px;}}
.exercise-box li{{margin-bottom:8px;}}
.answer{{color:var(--green); font-weight:600;}}
.note{{
  font-size:14px; color:var(--sub); border-left:3px solid #ccc; padding-left:12px; margin:12px 0;
}}
.warn{{
  font-size:14px; color:var(--orange); border-left:3px solid var(--orange);
  background:#fdf3ee; padding:10px 14px; margin:12px 0; border-radius:0 5px 5px 0;
}}
.tbl{{border-collapse:collapse; width:100%; margin:16px 0; font-size:14px; page-break-inside:avoid;}}
.tbl th,.tbl td{{border:1px solid var(--border); padding:7px 11px; text-align:left; vertical-align:top;}}
.tbl thead th{{background:var(--accent); color:#fff; font-family:"Microsoft YaHei","PingFang SC",sans-serif; font-weight:600;}}
.tbl tbody tr:nth-child(even){{background:var(--panel);}}
.tbl td code{{font-size:13px;}}
.glossary{{margin:14px 0; page-break-inside:avoid;}}
.glossary dt{{font-family:"Microsoft YaHei","PingFang SC",sans-serif; font-weight:600; color:var(--accent); margin-top:12px;}}
.glossary dd{{margin:2px 0 0 0; padding:0; color:var(--ink);}}
@media print{{
  body{{font-size:14px; line-height:1.65;}}
  #wrapper{{padding:0; max-width:100%;}}
  #toc{{display:none;}}
  h1{{page-break-before:always;}}
  .chapter{{page-break-inside:avoid;}}
  .textbook-fig{{page-break-inside:avoid;}}
}}
.katex-display{{ margin:18px 0; text-align:center; page-break-inside:avoid; }}
.katex{{ font-size:1.04em; }}
.math-block{{ margin:18px 0; text-align:center; page-break-inside:avoid; font-size:1.05em; }}
</style>
<link rel="stylesheet" href="work/katex/katex.min.css">
<script defer src="work/katex/katex.min.js"></script>
<script defer src="work/katex/auto-render.min.js"></script>
<script>
document.addEventListener("DOMContentLoaded", function(){{
  if (window.renderMathInElement) {{
    renderMathInElement(document.body, {{
      delimiters: [
        {{left:"$$", right:"$$", display:true}},
        {{left:"\\[", right:"\\]", display:true}},
        {{left:"\\(", right:"\\)", display:false}}
      ],
      throwOnError:false, errorColor:"#b23a3a"
    }});
  }}
}});
</script>
</head>
<body>
<div id="wrapper">
<div id="titlepage">
  <h1>LMCC 青少年组<br>人工智能与大模型能力认证教材</h1>
  <div class="subtitle">考纲覆盖 · 知识点详解 · 工程实操 · 认证要点</div>
  <div class="meta">依据 LMCC 青少年组公开试题、考纲与实战任务整理</div>
</div>
{toc}
{full_body}
</div>
</body>
</html>'''

    with open(OUT_HTML, "w", encoding="utf-8") as f:
        f.write(html)
    print("已生成：", OUT_HTML)

if __name__ == "__main__":
    assemble()
