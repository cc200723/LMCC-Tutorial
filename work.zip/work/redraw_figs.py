# -*- coding: utf-8 -*-
"""Redraw 6 non-standard figures + update appendix for consistency.
All 6 figures use ONE canonical palette (Set B) at the book's 840 width, no emoji,
clean layouts. Appendix E gains frontier glossary terms; Appendix B cites chapter 10
and adds B.4; a body->appendix reference is fixed.
"""
import re, xml.dom.minidom as M

PATH = "LMCC青少年组教材-增强版.html"
src = open(PATH, encoding="utf-8").read()

PAL = {
 'BLUE':'#2c5f8a','ORANGE':'#c1572f','GREEN':'#3a7d44','PURPLE':'#6a4c93',
 'RED':'#d13c3c','INK':'#1a1a1a','MUTE':'#5b6770','PANEL':'#f4f7fa','BORDER':'#cfd6dd',
 'FONT':"Noto Sans CJK SC,Microsoft YaHei,PingFang SC,sans-serif",
 'BLUE_P':'#eaf2f8','ORANGE_P':'#fbeee6','GREEN_P':'#e9f3ec'
}
def fill(s):
    for k,v in PAL.items():
        s = s.replace(k, v)
    return s

# ---------------- FIG 1-4 涌现能力 ----------------
FIG1_4 = fill("""<figure class="textbook-fig"><svg xmlns="http://www.w3.org/2000/svg" width="840" height="360" viewBox="0 0 840 360" font-family="FONT">
<rect width="840" height="360" fill="#ffffff"/>
<text x="420" y="26" text-anchor="middle" font-size="16" font-weight="700" fill="INK">涌现能力：模型规模突破阈值后，复杂能力突然跳升</text>
<line x1="80" y1="290" x2="790" y2="290" stroke="INK" stroke-width="1.8"/>
<line x1="80" y1="290" x2="80" y2="60" stroke="INK" stroke-width="1.8"/>
<text x="435" y="336" text-anchor="middle" font-size="13" fill="MUTE">模型参数量（对数尺度）</text>
<text x="26" y="180" text-anchor="middle" font-size="13" fill="MUTE" transform="rotate(-90,26,180)">任务准确率</text>
<text x="130" y="308" text-anchor="middle" font-size="11" fill="MUTE">1M</text>
<text x="250" y="308" text-anchor="middle" font-size="11" fill="MUTE">100M</text>
<text x="390" y="308" text-anchor="middle" font-size="11" fill="MUTE">1B</text>
<text x="530" y="308" text-anchor="middle" font-size="11" fill="MUTE">10B</text>
<text x="660" y="308" text-anchor="middle" font-size="11" fill="MUTE">100B</text>
<text x="770" y="308" text-anchor="middle" font-size="11" fill="MUTE">1T</text>
<text x="70" y="74" text-anchor="end" font-size="11" fill="MUTE">100%</text>
<text x="70" y="132" text-anchor="end" font-size="11" fill="MUTE">75%</text>
<text x="70" y="190" text-anchor="end" font-size="11" fill="MUTE">50%</text>
<text x="70" y="248" text-anchor="end" font-size="11" fill="MUTE">25%</text>
<text x="70" y="294" text-anchor="end" font-size="11" fill="MUTE">0%</text>
<polyline points="130,272 250,254 390,224 530,200 660,182 770,168" fill="none" stroke="BLUE" stroke-width="2.6"/>
<text x="782" y="166" font-size="12" fill="BLUE">简单任务</text>
<polyline points="130,284 250,280 390,277 480,275 530,150 660,100 770,78" fill="none" stroke="ORANGE" stroke-width="2.6"/>
<text x="782" y="80" font-size="12" fill="ORANGE">数学推理</text>
<polyline points="130,286 250,283 390,280 530,277 580,160 660,105 770,86" fill="none" stroke="GREEN" stroke-width="2.6"/>
<text x="782" y="94" font-size="12" fill="GREEN">代码生成</text>
<line x1="530" y1="64" x2="530" y2="288" stroke="RED" stroke-width="1.4" stroke-dasharray="5,4"/>
<circle cx="530" cy="150" r="5.5" fill="none" stroke="RED" stroke-width="2"/>
<circle cx="580" cy="160" r="5.5" fill="none" stroke="RED" stroke-width="2"/>
<text x="530" y="56" text-anchor="middle" font-size="12" font-weight="700" fill="RED">涌现阈值</text>
</svg><figcaption>图 1-4 涌现能力示意：简单任务（蓝色）平滑增长，复杂任务（橙色/绿色）在特定规模处突然跳升</figcaption></figure>""")

# ---------------- FIG 2-1 缩放点积注意力 ----------------
FIG2_1 = fill("""<figure class="textbook-fig"><svg xmlns="http://www.w3.org/2000/svg" width="840" height="380" viewBox="0 0 840 380" font-family="FONT">
<defs><marker id="ar-m" markerWidth="9" markerHeight="9" refX="6" refY="3" orient="auto"><path d="M0,0 L6,3 L0,6 z" fill="MUTE"/></marker></defs>
<rect width="840" height="380" fill="#ffffff"/>
<text x="420" y="28" text-anchor="middle" font-size="16" font-weight="700" fill="INK">缩放点积注意力：Q、K、V 如何产生输出</text>
<rect x="60" y="60" width="180" height="170" rx="10" fill="BLUE_P" stroke="BLUE" stroke-width="1.6"/>
<text x="150" y="92" text-anchor="middle" font-size="14" font-weight="700" fill="BLUE">Q（查询）</text>
<text x="150" y="116" text-anchor="middle" font-size="11" fill="MUTE">question</text>
<text x="150" y="150" text-anchor="middle" font-size="12" fill="INK">来自当前位置</text>
<text x="150" y="170" text-anchor="middle" font-size="12" fill="INK">去和其他位置比对</text>
<text x="150" y="200" text-anchor="middle" font-size="11" fill="MUTE">“要问什么”</text>
<rect x="330" y="60" width="180" height="170" rx="10" fill="ORANGE_P" stroke="ORANGE" stroke-width="1.6"/>
<text x="420" y="92" text-anchor="middle" font-size="14" font-weight="700" fill="ORANGE">K（键）</text>
<text x="420" y="116" text-anchor="middle" font-size="11" fill="MUTE">key</text>
<text x="420" y="150" text-anchor="middle" font-size="12" fill="INK">每个位置的特征</text>
<text x="420" y="170" text-anchor="middle" font-size="12" fill="INK">用来被查询</text>
<text x="420" y="200" text-anchor="middle" font-size="11" fill="MUTE">“是什么”</text>
<rect x="600" y="60" width="180" height="170" rx="10" fill="GREEN_P" stroke="GREEN" stroke-width="1.6"/>
<text x="690" y="92" text-anchor="middle" font-size="14" font-weight="700" fill="GREEN">V（值）</text>
<text x="690" y="116" text-anchor="middle" font-size="11" fill="MUTE">value</text>
<text x="690" y="150" text-anchor="middle" font-size="12" fill="INK">每个位置真正</text>
<text x="690" y="170" text-anchor="middle" font-size="12" fill="INK">要取出的信息</text>
<text x="690" y="200" text-anchor="middle" font-size="11" fill="MUTE">“携带什么”</text>
<rect x="110" y="272" width="170" height="46" rx="8" fill="PANEL" stroke="BORDER"/>
<text x="195" y="300" text-anchor="middle" font-size="13" fill="INK">Q·Kᵀ / √d</text>
<rect x="320" y="272" width="120" height="46" rx="8" fill="PANEL" stroke="BORDER"/>
<text x="380" y="300" text-anchor="middle" font-size="13" fill="INK">softmax</text>
<rect x="480" y="272" width="120" height="46" rx="8" fill="PANEL" stroke="BORDER"/>
<text x="540" y="300" text-anchor="middle" font-size="13" fill="INK">× V</text>
<rect x="650" y="272" width="120" height="46" rx="8" fill="PANEL" stroke="BORDER"/>
<text x="710" y="300" text-anchor="middle" font-size="13" font-weight="700" fill="BLUE">输出</text>
<line x1="150" y1="230" x2="188" y2="272" stroke="MUTE" stroke-width="1.6" marker-end="url(#ar-m)"/>
<line x1="420" y1="230" x2="240" y2="272" stroke="MUTE" stroke-width="1.6" marker-end="url(#ar-m)"/>
<line x1="290" y1="295" x2="318" y2="295" stroke="MUTE" stroke-width="1.6" marker-end="url(#ar-m)"/>
<line x1="440" y1="295" x2="478" y2="295" stroke="MUTE" stroke-width="1.6" marker-end="url(#ar-m)"/>
<line x1="690" y1="230" x2="562" y2="272" stroke="MUTE" stroke-width="1.6" marker-end="url(#ar-m)"/>
<line x1="600" y1="295" x2="648" y2="295" stroke="MUTE" stroke-width="1.6" marker-end="url(#ar-m)"/>
</svg><figcaption>图 2-1 缩放点积注意力：Q 查询、K 键、V 值如何相互作用产生输出</figcaption></figure>""")

# ---------------- FIG 3-2 三种浮点精度（按比例） ----------------
FIG3_2 = fill("""<figure class="textbook-fig"><svg xmlns="http://www.w3.org/2000/svg" width="840" height="320" viewBox="0 0 840 320" font-family="FONT">
<rect width="840" height="320" fill="#ffffff"/>
<text x="420" y="28" text-anchor="middle" font-size="16" font-weight="700" fill="INK">三种浮点精度的 bit 分配（宽度按比例，每 bit 20px）</text>
<text x="44" y="96" font-size="13" font-weight="700" fill="INK">FP32</text>
<rect x="60" y="64" width="20" height="54" fill="RED"/><text x="70" y="96" text-anchor="middle" font-size="10" fill="#ffffff">S</text>
<rect x="80" y="64" width="160" height="54" fill="BLUE"/><text x="160" y="96" text-anchor="middle" font-size="12" fill="#ffffff">指数 8 bit</text>
<rect x="240" y="64" width="460" height="54" fill="GREEN"/><text x="470" y="96" text-anchor="middle" font-size="12" fill="#ffffff">尾数 23 bit</text>
<text x="44" y="176" font-size="13" font-weight="700" fill="INK">FP16</text>
<rect x="60" y="144" width="20" height="54" fill="RED"/><text x="70" y="176" text-anchor="middle" font-size="10" fill="#ffffff">S</text>
<rect x="80" y="144" width="100" height="54" fill="BLUE"/><text x="130" y="176" text-anchor="middle" font-size="12" fill="#ffffff">指数 5 bit</text>
<rect x="180" y="144" width="200" height="54" fill="GREEN"/><text x="280" y="176" text-anchor="middle" font-size="12" fill="#ffffff">尾数 10 bit</text>
<text x="410" y="176" font-size="11.5" fill="RED">问题：范围窄（最大 65504），训练易溢出</text>
<text x="42" y="256" font-size="13" font-weight="700" fill="INK">BF16</text>
<rect x="60" y="224" width="20" height="54" fill="RED"/><text x="70" y="256" text-anchor="middle" font-size="10" fill="#ffffff">S</text>
<rect x="80" y="224" width="160" height="54" fill="BLUE"/><text x="160" y="256" text-anchor="middle" font-size="12" fill="#ffffff">指数 8 bit</text>
<rect x="240" y="224" width="140" height="54" fill="GREEN"/><text x="310" y="256" text-anchor="middle" font-size="12" fill="#ffffff">尾数 7 bit</text>
<text x="410" y="256" font-size="11.5" fill="GREEN">优点：范围同 FP32，精度略低但训练稳定</text>
</svg><figcaption>图 3-2 三种浮点精度的 bit 分配：BF16 用与 FP32 相同的指数位（8 bit），牺牲尾数精度换取大范围</figcaption></figure>""")

# ---------------- FIG 6-3 一条好提示的四种组成 ----------------
FIG6_3 = fill("""<figure class="textbook-fig"><svg xmlns="http://www.w3.org/2000/svg" width="840" height="430" viewBox="0 0 840 430" font-family="FONT">
<rect width="840" height="430" fill="#ffffff"/>
<text x="420" y="28" text-anchor="middle" font-size="16" font-weight="700" fill="INK">一条好提示的四种组成（以“失物招领”为例）</text>
<rect x="60" y="52" width="720" height="338" rx="12" fill="PANEL" stroke="BORDER" stroke-width="1.5"/>
<rect x="60" y="52" width="720" height="44" rx="12" fill="BLUE"/>
<text x="420" y="80" text-anchor="middle" font-size="15" font-weight="700" fill="#ffffff">完整提示 Prompt</text>
<rect x="92" y="120" width="34" height="34" rx="8" fill="BLUE"/><text x="109" y="143" text-anchor="middle" font-size="15" font-weight="700" fill="#ffffff">1</text>
<text x="144" y="144" font-size="14.5" font-weight="700" fill="INK">目标</text>
<text x="144" y="166" font-size="13" fill="INK">要做什么：写一则失物招领公告</text>
<rect x="92" y="192" width="34" height="34" rx="8" fill="BLUE"/><text x="109" y="215" text-anchor="middle" font-size="15" font-weight="700" fill="#ffffff">2</text>
<text x="144" y="216" font-size="14.5" font-weight="700" fill="INK">背景</text>
<text x="144" y="238" font-size="13" fill="INK">给什么信息：捡到物品、时间地点、联系方式</text>
<rect x="92" y="264" width="34" height="34" rx="8" fill="BLUE"/><text x="109" y="287" text-anchor="middle" font-size="15" font-weight="700" fill="#ffffff">3</text>
<text x="144" y="288" font-size="14.5" font-weight="700" fill="INK">约束</text>
<text x="144" y="310" font-size="13" fill="INK">限制条件：别编造、语气礼貌、不超过 80 字</text>
<rect x="92" y="336" width="34" height="34" rx="8" fill="BLUE"/><text x="109" y="359" text-anchor="middle" font-size="15" font-weight="700" fill="#ffffff">4</text>
<text x="144" y="360" font-size="14.5" font-weight="700" fill="INK">格式</text>
<text x="144" y="382" font-size="13" fill="INK">输出样式：先标题后正文，最后留联系电话</text>
<text x="420" y="414" text-anchor="middle" font-size="13" fill="MUTE">四件套越清楚，模型输出越稳定、越贴近你的需要。</text>
</svg><figcaption>图 6-3 一条好提示的四种组成</figcaption></figure>""")

# ---------------- FIG 9-2 智能体标准工作流（明确循环） ----------------
FIG9_2 = fill("""<figure class="textbook-fig"><svg xmlns="http://www.w3.org/2000/svg" width="840" height="440" viewBox="0 0 840 440" font-family="FONT">
<defs><marker id="ar-o" markerWidth="10" markerHeight="10" refX="7" refY="3.2" orient="auto"><path d="M0,0 L7,3.2 L0,6.4 z" fill="ORANGE"/></marker></defs>
<rect width="840" height="440" fill="#ffffff"/>
<text x="420" y="28" text-anchor="middle" font-size="16" font-weight="700" fill="INK">智能体标准工作流：感知—规划—行动—观察 的循环</text>
<circle cx="250" cy="150" r="52" fill="BLUE" stroke="#ffffff" stroke-width="2"/>
<text x="250" y="144" text-anchor="middle" font-size="13" font-weight="700" fill="#ffffff">感知 Perceive</text>
<text x="250" y="164" text-anchor="middle" font-size="11" fill="#ffffff">读取任务与</text>
<text x="250" y="180" text-anchor="middle" font-size="11" fill="#ffffff">环境信息</text>
<circle cx="590" cy="150" r="52" fill="BLUE" stroke="#ffffff" stroke-width="2"/>
<text x="590" y="144" text-anchor="middle" font-size="13" font-weight="700" fill="#ffffff">规划 Plan</text>
<text x="590" y="164" text-anchor="middle" font-size="11" fill="#ffffff">把目标拆成</text>
<text x="590" y="180" text-anchor="middle" font-size="11" fill="#ffffff">可执行步骤</text>
<circle cx="590" cy="310" r="52" fill="BLUE" stroke="#ffffff" stroke-width="2"/>
<text x="590" y="304" text-anchor="middle" font-size="13" font-weight="700" fill="#ffffff">行动 Act</text>
<text x="590" y="324" text-anchor="middle" font-size="11" fill="#ffffff">调用工具</text>
<text x="590" y="340" text-anchor="middle" font-size="11" fill="#ffffff">执行一步</text>
<circle cx="250" cy="310" r="52" fill="BLUE" stroke="#ffffff" stroke-width="2"/>
<text x="250" y="304" text-anchor="middle" font-size="13" font-weight="700" fill="#ffffff">观察 Observe</text>
<text x="250" y="324" text-anchor="middle" font-size="11" fill="#ffffff">看结果，</text>
<text x="250" y="340" text-anchor="middle" font-size="11" fill="#ffffff">决定下一步</text>
<path d="M 300,124 Q 420,96 540,124" fill="none" stroke="ORANGE" stroke-width="2.6" marker-end="url(#ar-o)"/>
<path d="M 616,200 Q 644,230 616,260" fill="none" stroke="ORANGE" stroke-width="2.6" marker-end="url(#ar-o)"/>
<path d="M 540,336 Q 420,364 300,336" fill="none" stroke="ORANGE" stroke-width="2.6" marker-end="url(#ar-o)"/>
<path d="M 224,260 Q 196,230 224,200" fill="none" stroke="ORANGE" stroke-width="2.6" marker-end="url(#ar-o)"/>
<rect x="338" y="200" width="164" height="60" rx="12" fill="PANEL" stroke="PURPLE" stroke-width="1.6"/>
<text x="420" y="226" text-anchor="middle" font-size="13" font-weight="700" fill="PURPLE">记忆模块</text>
<text x="420" y="246" text-anchor="middle" font-size="11" fill="MUTE">记录历史与状态</text>
<line x1="300" y1="178" x2="345" y2="215" stroke="MUTE" stroke-width="1.2"/>
<line x1="540" y1="178" x2="495" y2="215" stroke="MUTE" stroke-width="1.2"/>
<line x1="540" y1="282" x2="495" y2="262" stroke="MUTE" stroke-width="1.2"/>
<line x1="300" y1="282" x2="345" y2="262" stroke="MUTE" stroke-width="1.2"/>
<text x="420" y="418" text-anchor="middle" font-size="12.5" fill="MUTE">每完成一轮，就把观察结果写回记忆，再进入下一轮，直到任务结束。</text>
</svg><figcaption>图 9-2 智能体标准工作流：感知—规划—行动—观察</figcaption></figure>""")

# ---------------- FIG 9-6 开源智能体的典型结构（辐条到边缘） ----------------
FIG9_6 = fill("""<figure class="textbook-fig"><svg xmlns="http://www.w3.org/2000/svg" width="840" height="400" viewBox="0 0 840 400" font-family="FONT">
<rect width="840" height="400" fill="#ffffff"/>
<text x="420" y="30" text-anchor="middle" font-size="16" font-weight="700" fill="INK">开源智能体的典型结构：四模块 + 本地记忆</text>
<circle cx="420" cy="200" r="66" fill="PANEL" stroke="INK" stroke-width="2"/>
<text x="420" y="196" text-anchor="middle" font-size="14" font-weight="700" fill="INK">智能体</text>
<text x="420" y="216" text-anchor="middle" font-size="13" fill="INK">内核</text>
<rect x="335" y="46" width="170" height="58" rx="12" fill="#ffffff" stroke="BLUE" stroke-width="2"/>
<text x="420" y="74" text-anchor="middle" font-size="13.5" font-weight="700" fill="BLUE">渠道适配器</text>
<text x="420" y="94" text-anchor="middle" font-size="11" fill="MUTE">WhatsApp / 微信 / 飞书</text>
<line x1="420" y1="104" x2="420" y2="134" stroke="BLUE" stroke-width="1.6"/>
<rect x="645" y="169" width="170" height="62" rx="12" fill="#ffffff" stroke="ORANGE" stroke-width="2"/>
<text x="730" y="197" text-anchor="middle" font-size="13.5" font-weight="700" fill="ORANGE">决策核心</text>
<text x="730" y="217" text-anchor="middle" font-size="11" fill="MUTE">灵活切换大模型</text>
<line x1="645" y1="200" x2="486" y2="200" stroke="ORANGE" stroke-width="1.6"/>
<rect x="335" y="320" width="170" height="58" rx="12" fill="#ffffff" stroke="GREEN" stroke-width="2"/>
<text x="420" y="348" text-anchor="middle" font-size="13.5" font-weight="700" fill="GREEN">技能插件 Skills</text>
<text x="420" y="368" text-anchor="middle" font-size="11" fill="MUTE">控制浏览器 / 邮件 / 代码</text>
<line x1="420" y1="320" x2="420" y2="266" stroke="GREEN" stroke-width="1.6"/>
<rect x="25" y="169" width="170" height="62" rx="12" fill="#ffffff" stroke="PURPLE" stroke-width="2"/>
<text x="110" y="197" text-anchor="middle" font-size="13.5" font-weight="700" fill="PURPLE">双模记忆</text>
<text x="110" y="217" text-anchor="middle" font-size="11" fill="MUTE">本地 Markdown 长期记忆</text>
<line x1="195" y1="200" x2="354" y2="200" stroke="PURPLE" stroke-width="1.6"/>
<text x="420" y="394" text-anchor="middle" font-size="12" fill="MUTE">代表项目：OpenClaw（本地运行的个人智能体）、Hermes Agent（内置技能与跨会话记忆的“会成长的智能体”）</text>
</svg><figcaption>图 9-6 开源智能体的典型结构：四模块 + 本地记忆</figcaption></figure>""")

# ---------------- replacement helper ----------------
def replace_fig(html, cap_anchor, new_fig):
    i = html.index(cap_anchor)
    fs = html.rfind('<figure', 0, i)
    fe = html.find('</figure>', i) + len('</figure>')
    return html[:fs] + new_fig + html[fe:]

html = src
html = replace_fig(html, "图 1-4 涌现能力示意", FIG1_4)
html = replace_fig(html, "图 2-1 缩放点积注意力", FIG2_1)
html = replace_fig(html, "图 3-2 三种浮点精度的 bit 分配", FIG3_2)
html = replace_fig(html, "图 6-3 一条好提示的四种组成", FIG6_3)
html = replace_fig(html, "图 9-2 智能体标准工作流", FIG9_2)
html = replace_fig(html, "图 9-6 开源智能体的典型结构", FIG9_6)

# ---------------- appendix updates ----------------
# B intro: cite chapter 10
html = html.replace("建议结合第 2、5、6、7 章理解其来源。",
                   "建议结合第 2、5、6、7、10 章理解其来源。", 1)

# B.4 insert before B-section closes (just before 附录 C)
B4 = ('<h3>B.4 第 10 章前沿概念</h3>\n'
      '<p>第 10 章的世界模型把训练目标从“下一词预测（NTP）”推向“下一状态预测（NSP）”，'
      '让模型学习物理与因果；AI4S 则用“假设生成 → 模拟验证 → 实验优化”的循环加速科研。'
      '这两节以概念与流程为主，核心式仍以上述注意力、训练与评测公式为基础。</p>\n')
html = html.replace('</div>\n<h2>附录 C', B4 + '</div>\n<h2>附录 C', 1)

# glossary: append frontier terms before </dl> of glossary
NEW_GLOSSARY = """
<dt>世界模型 World Model</dt><dd>用“预测下一时刻状态”替代“预测下一个词”来学习物理与因果规律，是迈向具身与仿真智能的关键方向（第 10 章）。</dd>
<dt>AI4S（AI for Science）</dt><dd>让 AI 承担“假设生成 → 模拟验证 → 实验优化”的科研循环，2026 年已成为高增长方向（第 10 章）。</dd>
<dt>循环工程 Loop Engineering</dt><dd>把智能体从“写好单次提示”升级为设计“感知—规划—行动—观察”的可持续循环（第 9.12 章）。</dd>
<dt>OpenClaw</dt><dd>本地运行的个人智能体框架，强调隐私可控、数据不出本机（第 9.12 章）。</dd>
<dt>Hermes Agent</dt><dd>内置技能与跨会话记忆、可随使用“成长”的开源智能体（第 9.12 章）。</dd>
<dt>技能 Skills</dt><dd>用 SKILL.md 这类文件描述可复用、可移植的工作流，让智能体即插即用新能力（第 9.12 章）。</dd>
<dt>GPT-5.6</dt><dd>OpenAI 于 2026 年发布的旗舰模型，强调长程推理与高推理强度模式（第 1.4 章）。</dd>
<dt>Claude Fable</dt><dd>Anthropic 于 2026 年发布的模型，以长上下文与强代理能力著称（第 1.4 章）。</dd>
"""
dl_start = html.index('<dl class="glossary">')
dl_end = html.index('</dl>', dl_start)
html = html[:dl_end] + NEW_GLOSSARY + html[dl_end:]

# body -> appendix reference fix
html = html.replace("第 12 章附录 B.2 的", "附录 B.2 的", 1)

open(PATH, "w", encoding="utf-8").write(html)

# ---------------- self validation ----------------
def _try(s):
    try: M.parseString(s.encode("utf-8")); return True
    except Exception: return False
svgs = re.findall(r"<svg\b", html); svge = re.findall(r"</svg>", html)
figs = re.findall(r"<figure\b", html); fige = re.findall(r"</figure>", html)
bad = sum(1 for m in re.finditer(r"<svg.*?</svg>", html, re.S) if not _try(m.group(0)))
print("svg", len(svgs), len(svge), "| figure", len(figs), len(fige), "| xml_fail", bad)
for k in ["世界模型","AI4S","循环工程","OpenClaw","Hermes Agent","技能 Skills","GPT-5.6","Claude Fable","B.4 第 10 章前沿概念"]:
    print("  marker", k, html.count(k))
