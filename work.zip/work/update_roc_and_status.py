#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Regenerate ROC figure (1-9) and update section 1.4.3 with latest LLM developments."""
import re, shutil, os

HTML = "LMCC青少年组教材-增强版.html"
backup = HTML + ".roc-backup"
shutil.copy(HTML, backup)
html = open(HTML, encoding="utf-8").read()

# ---------- 1. ROC SVG ----------
BLUE = "#2c5f8a"
GREEN = "#2f7d4f"
ORANGE = "#c1572f"
RED = "#d13c3c"
GRAY = "#9aa5b0"
LIGHT_GRID = "#e3e8ed"
INK = "#1a1a1a"

def x(v): return 80 + v * 720
def y(v): return 460 - v * 390

svg = '''<svg xmlns="http://www.w3.org/2000/svg" width="840" height="560" viewBox="0 0 840 560" font-family="Noto Sans CJK SC, Microsoft YaHei, sans-serif">
<rect x="0" y="0" width="840" height="560" fill="white"/>
<text x="420" y="40" text-anchor="middle" font-size="18" font-weight="600" fill="{INK}">ROC 曲线：整体区分能力的体检单</text>
<text x="420" y="66" text-anchor="middle" font-size="13" fill="{GRAY}">曲线越靠近左上角，模型区分正负样本的能力越强</text>

<!-- 坐标轴 -->
<line x1="{x0}" y1="{y0}" x2="{x1}" y2="{y0}" stroke="{INK}" stroke-width="1.5"/>
<line x1="{x0}" y1="{y0}" x2="{x0}" y2="{y1}" stroke="{INK}" stroke-width="1.5"/>

<!-- 网格线 -->
<line x1="{x0_5}" y1="{y1}" x2="{x0_5}" y2="{y0}" stroke="{LIGHT_GRID}" stroke-width="1"/>
<line x1="{x1}" y1="{y1}" x2="{x1}" y2="{y0}" stroke="{LIGHT_GRID}" stroke-width="1"/>
<line x1="{x0}" y1="{y0_5}" x2="{x1}" y2="{y0_5}" stroke="{LIGHT_GRID}" stroke-width="1"/>
<line x1="{x0}" y1="{y1}" x2="{x1}" y2="{y1}" stroke="{LIGHT_GRID}" stroke-width="1"/>

<!-- 刻度文字 -->
<text x="{x0}" y="{y0_lbl}" text-anchor="middle" font-size="14" fill="{INK}">0.0</text>
<text x="{x0_5}" y="{y0_lbl}" text-anchor="middle" font-size="14" fill="{INK}">0.5</text>
<text x="{x1}" y="{y0_lbl}" text-anchor="middle" font-size="14" fill="{INK}">1.0</text>
<text x="{x_lbl}" y="{y0}" text-anchor="middle" font-size="15" fill="{INK}">假阳性率（False Positive Rate）</text>
<text x="{x0_lbl}" y="{y0}" text-anchor="end" font-size="14" fill="{INK}">0.0</text>
<text x="{x0_lbl}" y="{y0_5}" text-anchor="end" font-size="14" fill="{INK}">0.5</text>
<text x="{x0_lbl}" y="{y1}" text-anchor="end" font-size="14" fill="{INK}">1.0</text>
<text x="{y_title_x}" y="{y_title_y}" text-anchor="middle" font-size="15" fill="{INK}" transform="rotate(-90 {y_title_x},{y_title_y})">真阳性率（True Positive Rate）</text>

<!-- 对角线：随机分类器 -->
<line x1="{x0}" y1="{y0}" x2="{x1}" y2="{y1}" stroke="{RED}" stroke-width="2.5" stroke-dasharray="10,7"/>
<text x="{x_rand_lbl}" y="{y_rand_lbl}" font-size="14" fill="{RED}" transform="rotate(38 {x_rand_lbl},{y_rand_lbl})">随机分类器</text>

<!-- 蓝色曲线：理想分类器 -->
<path d="M {x0},{y0} Q {x0},{y_perf1} {x0_q},{y1} L {x1},{y1}" fill="none" stroke="{BLUE}" stroke-width="3"/>
<circle cx="{x0_p}" cy="{y1_p}" r="5" fill="{BLUE}"/>
<text x="{x0_p_lbl}" y="{y1_p_t}" text-anchor="start" font-size="14" fill="{BLUE}" font-weight="600">理想分类器</text>

<!-- 绿色曲线：好分类器 -->
<path d="M {x0},{y0} C {x0_15},{y0_55} {x0_3},{y0_72} {x0_55},{y0_82} S {x0_9},{y0_92} {x1},{y1}" fill="none" stroke="{GREEN}" stroke-width="2.8"/>
<text x="{x_green_lbl}" y="{y_green_lbl}" font-size="14" fill="{GREEN}" font-weight="600">较好</text>

<!-- 橙色曲线：一般分类器 -->
<path d="M {x0},{y0} C {x0_25},{y0_32} {x0_45},{y0_48} {x0_65},{y0_58} S {x0_9},{y0_72b} {x1},{y1}" fill="none" stroke="{ORANGE}" stroke-width="2.8"/>
<text x="{x_orange_lbl}" y="{y_orange_lbl}" font-size="14" fill="{ORANGE}" font-weight="600">一般</text>

<!-- Better / Worse 箭头 -->
<defs>
  <marker id="arrowh" markerWidth="10" markerHeight="10" refX="8" refY="3" orient="auto">
    <path d="M0,0 L8,3 L0,6 z" fill="{INK}"/>
  </marker>
</defs>
<line x1="{x_b1}" y1="{y_b1}" x2="{x_b2}" y2="{y_b2}" stroke="{INK}" stroke-width="2" marker-end="url(#arrowh)"/>
<text x="{xb_lbl}" y="{yb_lbl}" font-size="14" fill="{INK}" font-weight="600">更好</text>
<line x1="{x_w1}" y1="{y_w1}" x2="{x_w2}" y2="{y_w2}" stroke="{INK}" stroke-width="2" marker-end="url(#arrowh)"/>
<text x="{xw_lbl}" y="{yw_lbl}" font-size="14" fill="{INK}" font-weight="600">更差</text>
</svg>'''.format(
    INK=INK, GRAY=GRAY, LIGHT_GRID=LIGHT_GRID,
    BLUE=BLUE, GREEN=GREEN, ORANGE=ORANGE, RED=RED,
    x0=x(0), x0_5=x(0.5), x1=x(1),
    y0=y(0), y0_5=y(0.5), y1=y(1),
    x0_lbl=x(0)-12, y0_lbl=y(0)+22,
    x_lbl=x(0.5), y_title_x=x(0)-55, y_title_y=(y(0)+y(1))/2,
    x_rand_lbl=x(0.32), y_rand_lbl=y(0.32),
    x0_p=x(0.02), x0_p_lbl=x(0.06), y1_p=y(0.97), y1_p_t=y(0.97)-8,
    y_perf1=y(0.99),
    x0_15=x(0.15), x0_3=x(0.3), x0_55=x(0.55), x0_9=x(0.9),
    x0_25=x(0.25), x0_45=x(0.45), x0_65=x(0.65),
    y0_55=y(0.55), y0_72=y(0.72), y0_82=y(0.82), y0_92=y(0.92),
    y0_32=y(0.32), y0_48=y(0.48), y0_58=y(0.58), y0_72b=y(0.72),
    x_green_lbl=x(0.35), y_green_lbl=y(0.86),
    x_orange_lbl=x(0.68), y_orange_lbl=y(0.62),
    x_b1=x(0.78), y_b1=y(0.78), x_b2=x(0.52), y_b2=y(0.94),
    xb_lbl=x(0.55), yb_lbl=y(0.88),
    x_w1=x(0.82), y_w1=y(0.72), x_w2=x(0.95), y_w2=y(0.55),
    xw_lbl=x(0.92), yw_lbl=y(0.58),
    x0_q=x(0.08),
)

new_fig = f'<figure class="textbook-fig">{svg}\n<figcaption>图 1-9 ROC 曲线与 AUC：整体区分能力的体检单</figcaption></figure>\n'

# ---------- 2. Replace ROC figure ----------
# Find the LAST figure block whose caption contains "图 1-9" to avoid matching from earlier figures.
fig_blocks = [(m.start(), m.end()) for m in re.finditer(r'<figure class="textbook-fig">.*?</figure>', html, re.S)]
roc_block = None
for s, e in fig_blocks:
    if '图 1-9' in html[s:e]:
        roc_block = html[s:e]
if roc_block is None:
    raise SystemExit("ERROR: figure 1-9 not found")
html = html.replace(roc_block, new_fig, 1)

# ---------- 3. Update section 1.4.3 ----------
start_marker = '<h3 id="1.4.3-大模型现状">1.4.3 大模型现状：国际主流与国内发展</h3>'
start = html.find(start_marker)
if start == -1:
    raise SystemExit("ERROR: section 1.4.3 start marker not found")
start = start + len(start_marker)

end = len(html)
for nxt in ['<h3', '<h2', '<h1']:
    pos = html.find(nxt, start)
    if pos != -1 and pos < end:
        end = pos

new_sec = '''\n<p>大模型已经从实验室走进日常工具，并且每隔几个月就会迭代一次。国际上，OpenAI 的 GPT-4 系列持续强化推理、代码、多模态和长任务执行能力；Google 的 Gemini 系列在多模态理解和推理上不断突破；Anthropic 的 Claude 系列强调安全、可控和代码能力；Meta 的 Llama 系列则代表开源大模型的重要路线，允许研究者下载并在本地部署。与此同时，国内模型也在快速追赶，并在部分领域形成差异化优势。</p>
<p>国内大模型呈现出“百花齐放”的局面。2025 年初，DeepSeek-R1 的发布引发广泛关注，它在推理和数学能力上表现突出，同时以极低的训练成本和开源策略展示了“低成本高性能”的可能性。阿里巴巴的通义千问（Qwen）系列持续升级，在中文理解、数学推理和开源生态方面表现亮眼，成为全球开发者使用最广泛的开源模型家族之一。百度的文心一言（已焕新为“文小言”）在中文知识问答和企业级服务上保持优势。字节跳动的豆包依托抖音和今日头条的流量生态，成为国内用户规模最大的 AI 助手之一。智谱 AI 的 GLM 系列、月之暗面的 Kimi（以长文本处理能力著称）、MiniMax、腾讯混元、科大讯飞星火等也各有侧重，覆盖从编程、智能体到语音交互的多个场景。</p>
<p>根据斯坦福大学 2026 年《AI 指数报告》，中美顶级大模型的性能差距已缩小到约 2.7%，双方在主要评测排行榜上处于同一梯队。与此同时，中国模型的全球使用量快速增长，开源模型在代码、数学等任务上的表现已逼近闭源旗舰。竞争焦点已经从单纯的“谁更聪明”转向“谁更便宜、更可靠、更适合真实任务”。</p>
<p>总体趋势可概括为四点：一是多模态能力增强，模型能同时理解文字、图片、音频和视频；二是推理能力强化，通过“长思维链”或强化学习训练，模型在数学、编程、科研问题上的表现大幅提升；三是 AI 智能体（Agent）兴起，模型不再只回答提问，而是能调用工具、规划步骤并执行多步任务；四是成本和效率持续下降，大模型从“技术展示”走向“商业落地”。</p>
<div class="note">使用大模型时，记住三条原则：第一，关键信息要核实，模型可能会“一本正经地胡说八道”；第二，保护个人隐私，不要输入敏感信息；第三，关键决策仍要由人把关，模型是辅助工具，不是最终责任人。</div>
\n'''

html = html[:start] + new_sec + html[end:]

open(HTML, "w", encoding="utf-8").write(html)
print("Updated figure 1-9 and section 1.4.3.")
print("Backup saved at:", backup)
