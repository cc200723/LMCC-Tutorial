# -*- coding: utf-8 -*-
"""
Comprehensive structural fix script for LMCC textbook.
Fixes:
1. Chapter 1: Add missing h3 headings 1.4.1 and 1.4.2
2. Chapter 2: Renumber h3 2.4.1/2.4.2 to 2.5.1/2.5.2 (they're under h2 2.5)
3. Chapter 4: Expand nearly-empty section 4.3 (SFT)
4. Chapter 8: Expand nearly-empty sections 8.2, 8.10, 8.11
5. Chapter 3: Expand section 3.4 if too thin
6. Chapter 6: Expand section 6.5
7. Chapter 7: Expand section 7.4
"""
import re

HTML_PATH = r'C:\Users\MINXIN\Desktop\CCF LMCC\LMCC青少年组教材-增强版.html'

with open(HTML_PATH, 'r', encoding='utf-8') as f:
    html = f.read()

# ============================================================
# FIX 1: Chapter 1 - Add h3 headings 1.4.1 and 1.4.2
# ============================================================
# Current: <h2>1.4</h2> followed by <ol><li>统计语言模型...<li>神经网络...
# Then <h3>1.4.3</h3> and <h3>1.4.4</h3>
# Need to wrap first two list items in h3 sections

old_14 = '''<h2>1.4 语言模型发展的四个阶段</h2>
<ol>
<li><strong>统计语言模型</strong>：以 N-gram 为代表，根据局部词频估计下一个词的概率；直观但难以处理长距离依赖。</li>
<li><strong>神经网络语言模型</strong>：用前馈网络、RNN 或 LSTM 学习连续表示，泛化能力超过纯词频。</li>
<li><strong>预训练语言模型</strong>：先在大语料上学通用表示，再微调做分类、问答等；BERT 的掩码语言模型与早期 GPT 的自回归预训练是两条典型路线。</li>
<li><strong>大语言模型</strong>：用更大的参数、数据与算力，把生成、理解、推理、工具调用统一起来，并表现出上下文学习与指令遵循能力。</li>
</ol>

<h3 id="1.4.3-大模型现状">1.4.3 大模型现状：国际主流与国内发展</h3>'''

new_14 = '''<h2>1.4 语言模型发展的四个阶段</h2>
<p>语言模型的能力边界在过去三十年里经历了四次关键跃迁。理解这四个阶段，有助于把握大模型为什么能"理解"和"生成"——它不是魔法，而是技术路线的层层积累。</p>

<h3>1.4.1 统计语言模型</h3>
<p><strong>统计语言模型（Statistical Language Model）</strong>是语言建模的起点，以 N-gram 为代表。核心思想很简单：给定前面 N-1 个词，统计语料中第 N 个词出现的频率，用这个频率估计下一个词的概率。</p>
<ul>
<li><strong>核心假设</strong>：一个词出现的概率只与前面 N-1 个词有关（马尔可夫假设）。</li>
<li><strong>局限性</strong>：N 不能太大（N=3 的 trigram 需要存储海量词组），且无法捕捉长距离依赖——句子开头的信息很难影响到结尾的预测。</li>
<li><strong>代表</strong>：IBM 的语音识别系统、早期的机器翻译模型。</li>
</ul>
<div class="note">零基础理解：N-gram 就像"看过很多文章后记住常见搭配"。你总看到"今天天气真"后面接"好"，所以预测下一个词是"好"的概率最高。但它没见过的新搭配就束手无策。</div>

<h3>1.4.2 神经网络语言模型</h3>
<p>2003 年，Bengio 等人提出了<strong>神经网络语言模型（Neural Network Language Model, NNLM）</strong>，用神经网络替代了简单的词频统计：</p>
<ul>
<li><strong>词嵌入</strong>：每个词不再是孤立的编号，而是被表示为一个连续向量（几十到几百维）。语义相近的词，向量距离也相近——"国王"和"王后"的向量只差一个"性别"方向。</li>
<li><strong>前馈网络</strong>：用固定窗口内的词嵌入拼接后输入神经网络，预测下一个词。</li>
<li><strong>RNN/LSTM</strong>：循环神经网络让模型能"记住"前文信息，理论上可以处理任意长的上下文（虽然实际中也会遗忘）。</li>
</ul>
<p>神经网络语言模型的核心突破是<strong>泛化能力</strong>：它没见过"猫坐在沙发上"，但见过"狗坐在沙发上"和"猫趴在垫子上"，就能推断出"猫坐在沙发上"也是合理的——因为"坐"和"沙发"的向量关系已经学到了。</p>

<h3>1.4.3 预训练语言模型</h3>
<p>2018 年前后，<strong>预训练语言模型（Pre-trained Language Model）</strong>成为主流。核心思路是"先通用、后专用"：</p>
<ul>
<li><strong>预训练阶段</strong>：在大规模通用语料上训练，学习通用的语言表示能力（语法、语义、常识）。</li>
<li><strong>微调阶段</strong>：在特定任务的小数据上微调，把通用能力适配到具体任务。</li>
</ul>
<p>两条经典路线：</p>
<table class="tbl">
<thead><tr><th>路线</th><th>代表</th><th>预训练目标</th><th>特点</th></tr></thead>
<tbody>
<tr><td>掩码语言模型</td><td>BERT</td><td>遮住部分词，让模型预测被遮住的词</td><td>双向理解强，适合分类、问答</td></tr>
<tr><td>自回归语言模型</td><td>GPT-1/2</td><td>给定前文，预测下一个词</td><td>生成能力强，适合续写、对话</td></tr>
</tbody>
</table>
<div class="note">认证常考：BERT 用掩码语言模型（Masked LM）做预训练，GPT 用自回归语言模型（Autoregressive LM）做预训练。这是理解"编码器 vs 解码器"架构差异的历史根源。</div>

<h3>1.4.4 大语言模型</h3>
<p>2020 年以后，随着算力和数据量的指数级增长，模型规模从几亿参数膨胀到几千亿参数，<strong>大语言模型（Large Language Model, LLM）</strong>诞生。它的核心特征：</p>
<ul>
<li><strong>涌现能力（Emergence）</strong>：规模大到一定程度后，模型突然表现出小模型没有的能力——如上下文学习（in-context learning）、指令遵循（instruction following）、思维链推理（chain-of-thought reasoning）。</li>
<li><strong>统一架构</strong>：一个模型搞定生成、理解、推理、工具调用，不再需要为每个任务单独训练模型。</li>
<li><strong>通用助手</strong>：通过指令微调和对齐训练，模型从"会续写"变成"会听话"，能按用户指令完成各种任务。</li>
</ul>
<div class="key-box">
<h4>四个阶段对比</h4>
<table class="tbl">
<thead><tr><th>阶段</th><th>核心方法</th><th>能力边界</th><th>代表</th></tr></thead>
<tbody>
<tr><td>统计语言模型</td><td>N-gram 词频统计</td><td>局部搭配</td><td>早期语音识别</td></tr>
<tr><td>神经网络语言模型</td><td>词嵌入 + RNN/前馈</td><td>连续语义、泛化</td><td>Bengio NNLM</td></tr>
<tr><td>预训练语言模型</td><td>预训练 + 微调</td><td>通用表示 + 任务适配</td><td>BERT, GPT-2</td></tr>
<tr><td>大语言模型</td><td>超大规模 + 指令对齐</td><td>通用助手、涌现能力</td><td>GPT-4, Qwen, DeepSeek</td></tr>
</tbody>
</table>
</div>

<h3 id="1.4.5-大模型现状">1.4.5 大模型现状：国际主流与国内发展</h3>'''

html = html.replace(old_14, new_14)
print("[Fix 1] Chapter 1: Added 1.4.1, 1.4.2, expanded 1.4.3/1.4.4, renamed 1.4.3->1.4.5")

# ============================================================
# FIX 2: Chapter 2 - Renumber 2.4.1/2.4.2 to 2.5.1/2.5.2
# ============================================================
html = html.replace('<h3>2.4.1 三种架构的适用场景对比</h3>', '<h3>2.5.1 三种架构的适用场景对比</h3>')
html = html.replace('<h3>2.4.2 以 Qwen2-7B 为例解读因果解码器架构</h3>', '<h3>2.5.2 以 Qwen2-7B 为例解读因果解码器架构</h3>')
print("[Fix 2] Chapter 2: Renumbered 2.4.1->2.5.1, 2.4.2->2.5.2")

# ============================================================
# FIX 3: Chapter 4 - Expand section 4.3 (SFT)
# ============================================================
# Find 4.3 section and expand it
old_43 = '''<h2>4.3 监督微调（SFT）</h2>
<p>监督微调是后训练的核心环节，用"指令—回答"数据对让预训练模型学会按指令输出。</p>

<h2>4.4 LoRA：用低秩更新省参数</h2>'''

new_43 = '''<h2>4.3 监督微调（SFT）</h2>
<p>监督微调（Supervised Fine-Tuning, SFT）是后训练的核心环节。预训练模型虽然"会续写"，但它不懂"这是指令、这是要求、这是格式"。SFT 的目标就是教会它这些规则。</p>

<h3>4.3.1 SFT 的基本原理</h3>
<p>SFT 的训练方式和预训练几乎一样——都是"给定前文，预测下一个词元"——只是训练数据从"任意网页文本"换成了"指令—回答对"。</p>
<pre><code># SFT 数据格式示例
instruction = "请用三句话介绍太阳系"
response = "太阳系是以太阳为中心的天体系统，包含八大行星..."

# 训练时把指令和回答拼接
input_text = f"用户：{instruction}\\n助手：{response}"
# 模型学习：看到"用户：...\\n助手："后，接"太阳系是..."

# 关键：只计算回答部分的损失（指令部分的损失被屏蔽）
loss = cross_entropy(output[response_start:], response_tokens)</code></pre>
<div class="note">SFT 的核心技巧：训练时只让模型学习"怎么回答"，而不是"怎么复述指令"。如果指令部分的损失也被计算，模型会倾向于把指令内容也背下来——这会导致它在回答时重复用户的问题。</div>

<h3>4.3.2 SFT 与预训练的区别</h3>
<table class="tbl">
<thead><tr><th>对比维度</th><th>预训练</th><th>SFT（监督微调）</th></tr></thead>
<tbody>
<tr><td>数据</td><td>海量网页、书籍、代码</td><td>高质量指令—回答对（几万到几十万条）</td></tr>
<tr><td>目标</td><td>学会语言的统计规律</td><td>学会按指令格式回答</td></tr>
<tr><td>训练时长</td><td>数天到数周</td><td>数小时到一两天</td></tr>
<tr><td>可训练参数</td><td>全部参数</td><td>全部或部分（如 LoRA）</td></tr>
<tr><td>损失计算</td><td>所有词元</td><td>通常只计算回答部分</td></tr>
</tbody>
</table>

<h3>4.3.3 全量微调 vs LoRA 微调</h3>
<p>SFT 可以用两种方式训练：</p>
<ul>
<li><strong>全量微调（Full Fine-tuning）</strong>：更新模型的所有参数。需要大量显存（一个 7B 模型 FP16 需要约 14GB 显存，加上优化器状态需要 40GB+），训练时间长。</li>
<li><strong>LoRA 微调（Low-Rank Adaptation）</strong>：冻结大部分参数，只在每层注意力旁边加两个小型低秩矩阵（如秩 r=8 或 16），只训练这两个小矩阵。显存需求大幅降低，训练速度更快，且不同任务可以保存不同的 LoRA 权重，灵活切换。</li>
</ul>
<div class="note">认证常考：LoRA 的可训练参数量 ≈ 2 × r × d_model × 层数 × 4（4 个投影矩阵）。r=8 时，LoRA 参数通常只占全量参数的 0.1%~1%。</div>

<h2>4.4 LoRA：用低秩更新省参数</h2>'''

html = html.replace(old_43, new_43)
print("[Fix 3] Chapter 4: Expanded section 4.3 (SFT)")

# ============================================================
# FIX 4: Chapter 8 - Expand sections 8.2, 8.10, 8.11
# ============================================================
# 8.2 is very short - add a worked example
old_82 = '''<h2>8.2 分类评测：混淆矩阵</h2>
<p>分类评测最基础的工具是<strong>混淆矩阵</strong>。对二分类，四个格分别是：</p>
<ul>
<li>TP（真正例）：真实为正、预测也为正；</li>
<li>FP（假正例）：真实为负、预测为正；</li>
<li>FN（假负例）：真实为正、预测为负；</li>
<li>TN（真负例）：真实为负、预测也为负。</li>
</ul>

<h2>8.3 精确率、召回率与 F1</h2>'''

new_82 = '''<h2>8.2 分类评测：混淆矩阵</h2>
<p>分类评测最基础的工具是<strong>混淆矩阵</strong>。对二分类，四个格分别是：</p>
<ul>
<li>TP（真正例）：真实为正、预测也为正；</li>
<li>FP（假正例）：真实为负、预测为正；</li>
<li>FN（假负例）：真实为正、预测为负；</li>
<li>TN（真负例）：真实为负、预测也为负。</li>
</ul>

<h3>8.2.1 混淆矩阵实例：垃圾邮件分类</h3>
<p>假设一个垃圾邮件过滤器在 1000 封邮件上的测试结果：</p>
<table class="tbl">
<thead><tr><th></th><th>预测为正（垃圾）</th><th>预测为负（正常）</th></tr></thead>
<tbody>
<tr><td><strong>真实为正</strong>（200 封垃圾）</td><td>TP=180</td><td>FN=20</td></tr>
<tr><td><strong>真实为负</strong>（800 封正常）</td><td>FP=40</td><td>TN=760</td></tr>
</tbody>
</table>
<pre><code># 计算指标
TP, FP, FN, TN = 180, 40, 20, 760

Precision = TP / (TP + FP)      # 180 / 220 = 81.8%
Recall = TP / (TP + FN)          # 180 / 200 = 90.0%
Accuracy = (TP + TN) / (TP + TN + FP + FN)  # 940 / 1000 = 94.0%
F1 = 2 * Precision * Recall / (Precision + Recall)  # 85.7%

print(f"精确率: {Precision:.1%}")   # 81.8%
print(f"召回率: {Recall:.1%}")       # 90.0%
print(f"准确率: {Accuracy:.1%}")     # 94.0%
print(f"F1: {F1:.1%}")               # 85.7%</code></pre>
<div class="note">这个例子说明：准确率高达 94%，但精确率只有 81.8%——意味着每 5 封被标为"垃圾"的邮件中，就有 1 封其实是正常邮件（FP=40）。如果误标垃圾的代价很高，就需要提高精确率。</div>

<h2>8.3 精确率、召回率与 F1</h2>'''

html = html.replace(old_82, new_82)
print("[Fix 4a] Chapter 8: Expanded section 8.2 with worked example")

# 8.10 - expand fairness and timeliness
old_810 = '''<h2>8.10 公平性与时效性</h2>
<p>模型评测不仅要关注准确率，还要关注<strong>公平性</strong>——不同群体、语言、地域的用户是否获得同等质量的服务——以及<strong>时效性</strong>——模型知识是否有截止日期，对最新事件能否正确回答。</p>

<h2>8.11 评测范式：公开与隐藏、格式与字段</h2>'''

new_810 = '''<h2>8.10 公平性与时效性</h2>
<p>模型评测不仅要关注准确率，还要关注<strong>公平性</strong>——不同群体、语言、地域的用户是否获得同等质量的服务——以及<strong>时效性</strong>——模型知识是否有截止日期，对最新事件能否正确回答。</p>

<h3>8.10.1 公平性评测</h3>
<p>大模型在训练时接触到的数据来自互联网，而互联网上存在各种偏见（性别、种族、地域、职业）。模型可能"学会"这些偏见并在生成时表现出来。</p>
<ul>
<li><strong>刻板印象测试</strong>：让模型补全"程序员大多是____"，如果它倾向于填"男性"，说明存在性别偏见。</li>
<li><strong>交叉验证</strong>：在不同群体子集上分别评测，看性能是否有显著差异。</li>
<li><strong>缓解方法</strong>：数据去偏（平衡训练数据中的群体表示）、训练时加公平性约束、后处理时检测并修正偏见输出。</li>
</ul>
<div class="note">认证常考：公平性不是"越高越好"的单一指标，而是"不同群体性能差距尽量小"的相对指标。一个模型对所有人准确率 80%，可能比"对 A 群体 95%、对 B 群体 60%"更公平。</div>

<h3>8.10.2 时效性问题</h3>
<p>大模型的"知识"来自训练数据，而训练数据有截止日期。2024 年训练的模型不知道 2025 年发生的事。解决方法：</p>
<ul>
<li><strong>RAG（检索增强生成）</strong>：给模型提供最新的外部文档，让它基于检索到的信息回答。</li>
<li><strong>工具调用</strong>：让模型调用搜索引擎或 API 获取实时信息。</li>
<li><strong>持续预训练</strong>：用最新数据继续训练模型（成本高，通常只用于关键知识更新）。</li>
</ul>
<div class="warn">不要问大模型"今天股价是多少"或"最新新闻"——它不知道，除非接入了实时工具。这是初学者最常见的误解之一。</div>

<h2>8.11 评测范式：公开与隐藏、格式与字段</h2>'''

html = html.replace(old_810, new_810)
print("[Fix 4b] Chapter 8: Expanded section 8.10")

# 8.11 - expand evaluation paradigms
old_811 = '''<h2>8.11 评测范式：公开与隐藏、格式与字段</h2>
<p>评测集的设计直接影响结论的可靠性。常见的范式包括：</p>
<ul>
<li><strong>公开测试集（Public Test Set）</strong>：所有人都能看到题目和答案。好处是透明、可复现；坏处是模型可能"刷题"——把测试集内容背下来。</li>
<li><strong>隐藏测试集（Hidden Test Set）</strong>：只公布题目，不公布答案。组织者保留私有的评分服务器，防止模型提前看过答案。</li>
<li><strong>格式评测</strong>：检查模型输出是否符合要求的格式（如 JSON、Markdown 表格、特定字段）。</li>
</ul>

<h2>8.12 公开综合评测集</h2>'''

new_811 = '''<h2>8.11 评测范式：公开与隐藏、格式与字段</h2>
<p>评测集的设计直接影响结论的可靠性。常见范式有三种，对应不同的信任级别：</p>

<h3>8.11.1 公开测试集 vs 隐藏测试集</h3>
<table class="tbl">
<thead><tr><th>范式</th><th>做法</th><th>优点</th><th>缺点</th></tr></thead>
<tbody>
<tr><td>公开测试集</td><td>题目和答案都公开</td><td>透明、可复现、社区可验证</td><td>模型可能"刷题"背答案</td></tr>
<tr><td>隐藏测试集</td><td>只公开题目，答案由组织者保密</td><td>防止刷题、结果更真实</td><td>无法自行复现评分</td></tr>
<tr><td>动态测试集</td><td>定期更新题目，防止记忆</td><td>持续有效、难以刷题</td><td>维护成本高</td></tr>
</tbody>
</table>
<div class="note">LMCC 认证采用隐藏测试集：学生提交代码后，由后台用私有测试用例评分。这和 LeetCode、Kaggle 的评测方式一致。</div>

<h3>8.11.2 格式评测</h3>
<p>很多任务要求模型输出特定格式。如果格式错了，即使内容正确也可能得零分：</p>
<ul>
<li><strong>JSON 输出</strong>：要求 {"answer": "...", "reason": "..."}，但模型输出多余文字或引号不匹配。</li>
<li><strong>代码评测</strong>：要求函数签名 def solve(n):，但模型输出 class Solution 或其他格式。</li>
<li><strong>选择题</strong>：要求只输出 A/B/C/D，但模型输出了完整解释。</li>
</ul>
<p>格式评测通常先用正则表达式或 JSON parser 检查输出格式，格式通过后再评判内容。这是自动化评测中"先过形式关，再过内容关"的标准流程。</p>

<h2>8.12 公开综合评测集</h2>'''

html = html.replace(old_811, new_811)
print("[Fix 4c] Chapter 8: Expanded section 8.11")

# ============================================================
# FIX 5: Chapter 3 - Expand section 3.4 (参数量计算)
# ============================================================
# Find and check 3.4
idx_34 = html.find('<h2>3.4 参数量怎么算</h2>')
idx_35 = html.find('<h2>3.5')
if idx_34 >= 0 and idx_35 > idx_34:
    sec34 = html[idx_34:idx_35]
    text_len = len(re.sub(r'<[^>]+>', '', sec34))
    print(f"[Info] Chapter 3.4 text length: {text_len} chars")
    if text_len < 500:
        # Expand 3.4
        old_34 = '''<h2>3.4 参数量怎么算</h2>
<p>参数量直接决定训练成本、推理速度和显存占用。本节教你怎么快速估算一个模型的参数量。</p>

<h2>3.5'''
        new_34 = '''<h2>3.4 参数量怎么算</h2>
<p>参数量直接决定训练成本、推理速度和显存占用。本节教你怎么快速估算一个模型的参数量。</p>

<h3>3.4.1 标准 Transformer 的参数量公式</h3>
<p>一个标准的因果解码器（如 GPT/Qwen）的参数量主要来自以下几个部分：</p>
<ul>
<li><strong>词嵌入层</strong>：词表大小 V × 隐藏维度 d。例如 50,000 词表 × 4096 维度 = 约 200M 参数。</li>
<li><strong>注意力层（每层）</strong>：4 个投影矩阵（Q/K/V/O），每个是 d × d。总共 4d²。</li>
<li><strong>前馈层（每层）</strong>：两个矩阵 d × 4d 和 4d × d（标准 FFN 中间维度是 4d）。总共 8d²。</li>
<li><strong>层数</strong>：L 层，所以总参数 ≈ L × (4d² + 8d²) = 12Ld²（不含嵌入层）。</li>
<li><strong>输出层</strong>：和嵌入层共享权重（weight tying），不额外增加参数。</li>
</ul>
<div class="math-block">$$ N_{\\text{total}} \\approx V \\cdot d + 12 \\cdot L \\cdot d^2 $$</div>

<h3>3.4.2 快速估算示例</h3>
<pre><code># GPT-2 small: V=50257, d=768, L=12
V, d, L = 50257, 768, 12
embedding = V * d          # ~38.6M
layers = 12 * L * d * d    # 12 * 12 * 768^2 = ~84.9M
total = embedding + layers # ~123.5M
print(f"GPT-2 small: {total/1e6:.1f}M")  # ~124M (官方 124M)

# Qwen2-7B: V=152064, d=3584, L=28
V, d, L = 152064, 3584, 28
embedding = V * d          # ~545M
layers = 12 * L * d * d    # 12 * 28 * 3584^2 = ~4.3B
total = embedding + layers # ~4.8B
# 实际 7.6B，因为使用了 SwiGLU (FFN 更大) + GQA (注意力结构不同)
print(f"Qwen2-7B estimate: {total/1e9:.1f}B")  # 约 4.8B</code></pre>
<div class="note">快速记忆法：一个标准 Transformer 的参数量 ≈ 12 × 层数 × 隐藏维度²。7B 模型通常有 28-32 层、隐藏维度 4096 左右；70B 模型有 80 层、隐藏维度 8192 左右。</div>

<h3>3.4.3 不同架构的参数量差异</h3>
<table class="tbl">
<thead><tr><th>变体</th><th>改动</th><th>对参数量的影响</th></tr></thead>
<tbody>
<tr><td>SwiGLU 激活</td><td>FFN 用 3 个矩阵替代 2 个</td><td>FFN 参数增加 ~50%</td></tr>
<tr><td>GQA / MQA</td><td>多 Query 共享 KV</td><td>KV 投影减少，总参数略降</td></tr>
<tr><td>ALiBi / RoPE</td><td>位置编码不增加可训练参数</td><td>无影响</td></tr>
<tr><td>Weight Tying</td><td>输入嵌入与输出层共享权重</td><td>减少 V×d 参数</td></tr>
</tbody>
</table>

<h2>3.5'''
        html = html.replace(old_34, new_34)
        print("[Fix 5] Chapter 3: Expanded section 3.4 (parameter counting)")
    else:
        print("[Info] Chapter 3.4 already has sufficient content, skipping expansion")

# ============================================================
# FIX 6: Chapter 6 - Expand section 6.5 (RAG two-stage evaluation)
# ============================================================
idx_65 = html.find('<h2>6.5 RAG 的两段式评测</h2>')
idx_66 = html.find('<h2>6.6')
if idx_65 >= 0 and idx_66 > idx_65:
    sec65 = html[idx_65:idx_66]
    text_len = len(re.sub(r'<[^>]+>', '', sec65))
    print(f"[Info] Chapter 6.5 text length: {text_len} chars")
    if text_len < 500:
        old_65 = '''<h2>6.5 RAG 的两段式评测</h2>
<p>RAG 系统的评测要分开两段：检索段（找到的资料准不准）和生成段（基于资料回答得好不好）。</p>

<h2>6.6'''
        new_65 = '''<h2>6.5 RAG 的两段式评测</h2>
<p>RAG 系统的评测要分开两段：检索段（找到的资料准不准）和生成段（基于资料回答得好不好）。两段分别评测，才能定位问题。</p>

<h3>6.5.1 检索段评测</h3>
<p>检索段负责"找到相关的文档"。评测指标：</p>
<ul>
<li><strong>Recall@K</strong>：前 K 个检索结果中，包含正确答案的比例。K=5 时 Recall@5=80% 意味着 80% 的问题在前 5 个结果里找到了答案。</li>
<li><strong>MRR（Mean Reciprocal Rank）</strong>：正确答案在检索结果中的排名的倒数平均。答案排第 1 贡献 1.0，排第 2 贡献 0.5，排第 3 贡献 0.33……</li>
<li><strong>NDCG</strong>：考虑检索结果的相关性等级（不只是"有没有"，而是"有多相关"）。</li>
</ul>

<h3>6.5.2 生成段评测</h3>
<p>生成段负责"基于检索到的文档回答问题"。评测指标：</p>
<ul>
<li><strong>Faithfulness（忠实性）</strong>：生成的回答是否忠实于检索到的文档？有没有编造文档中没有的信息？</li>
<li><strong>Answer Relevance（回答相关性）</strong>：回答是否切题？有没有答非所问？</li>
<li><strong>Context Relevance（上下文相关性）</strong>：检索到的文档和问题是否相关？</li>
</ul>
<div class="note">RAG 评测的"三段式"框架：检索质量（Recall/MRR）→ 上下文质量（相关性）→ 生成质量（忠实性/回答质量）。任何一段出问题，都会导致最终回答不佳。</div>

<h3>6.5.3 RAG 评测实例</h3>
<pre><code># RAG 系统评测示例
question = "爱因斯坦获得过诺贝尔奖吗？"
retrieved_docs = [
    "爱因斯坦因对光电效应的解释获得 1921 年诺贝尔物理学奖。",
    "爱因斯坦出生于 1879 年，是德国物理学家。",
    "相对论是爱因斯坦提出的重要理论。"
]

# 检索段评测
correct_doc_idx = 0  # 第一个文档包含答案
recall_at_3 = 1.0 if correct_doc_idx < 3 else 0.0
mrr = 1.0 / (correct_doc_idx + 1)  # 1.0

# 生成段评测（假设模型回答）
answer = "是的，爱因斯坦因解释光电效应获得 1921 年诺贝尔物理学奖。"
# Faithfulness: 答案信息都在文档中 ✓
# Relevance: 直接回答了问题 ✓</code></pre>

<h2>6.6'''
        html = html.replace(old_65, new_65)
        print("[Fix 6] Chapter 6: Expanded section 6.5 (RAG evaluation)")
    else:
        print("[Info] Chapter 6.5 already has sufficient content, skipping expansion")

# ============================================================
# FIX 7: Chapter 7 - Expand section 7.4 (Paper reading R/M/D/E/L)
# ============================================================
idx_74 = html.find('<h2>7.4 论文阅读标注法（R/M/D/E/L）</h2>')
idx_75 = html.find('<h2>7.5')
if idx_74 >= 0 and idx_75 > idx_74:
    sec74 = html[idx_74:idx_75]
    text_len = len(re.sub(r'<[^>]+>', '', sec74))
    print(f"[Info] Chapter 7.4 text length: {text_len} chars")
    if text_len < 500:
        old_74 = '''<h2>7.4 论文阅读标注法（R/M/D/E/L）</h2>
<p>阅读论文时用五个字母做标注：</p>
<ul>
<li><strong>R（Result）</strong>：结果是什么？指标提高了多少？</li>
<li><strong>M（Method）</strong>：方法的核心创新点是什么？</li>
<li><strong>D（Difference）</strong>：和前人方法的区别在哪里？</li>
<li><strong>E（Evidence）</strong>：证据是否充分？实验设计是否合理？</li>
<li><strong>L（Limitation）</strong>：局限性是什么？适用范围？</li>
</ul>

<h2>7.5'''
        new_74 = '''<h2>7.4 论文阅读标注法（R/M/D/E/L）</h2>
<p>面对海量论文，初学者往往"读不完、记不住、用不上"。R/M/D/E/L 五步法帮你高效提取论文核心信息，尤其适用于大模型领域的论文阅读。</p>

<h3>7.4.1 五步标注法详解</h3>
<table class="tbl">
<thead><tr><th>字母</th><th>含义</th><th>问自己</th><th>示例（读一篇关于 LoRA 的论文）</th></tr></thead>
<tbody>
<tr><td><strong>R</strong></td><td>Result</td><td>结果是什么？指标提高了多少？</td><td>在 GPT-3 175B 上微调，LoRA 达到全量微调 99.3% 的性能</td></tr>
<tr><td><strong>M</strong></td><td>Method</td><td>方法的核心创新点是什么？</td><td>用低秩矩阵近似全量更新，冻结原参数</td></tr>
<tr><td><strong>D</strong></td><td>Difference</td><td>和前人方法的区别在哪里？</td><td>Adapter 加在网络内部，LoRA 加在注意力旁路；LoRA 推理时无额外延迟</td></tr>
<tr><td><strong>E</strong></td><td>Evidence</td><td>证据是否充分？</td><td>在 NLU、NLG、多任务上做了实验，使用了不同秩 r=1,2,4,8,64</td></tr>
<tr><td><strong>L</strong></td><td>Limitation</td><td>局限性是什么？</td><td>只测了 Transformer，对 CNN/RNN 未验证；秩 r 的选择需要调参</td></tr>
</tbody>
</table>

<h3>7.4.2 实战标注示例</h3>
<p>以 Attention Is All You Need（Transformer 论文）为例：</p>
<pre><code># R/M/D/E/L 标注示例

# [R] Result
"在英德翻译任务上，BLEU 达到 28.4，超过之前最好的 RNN+Attention 模型（24.6），"
"且训练时间从 3.5 天降到 12 小时。"

# [M] Method  
"核心创新：完全用注意力机制替代 RNN/CNN，提出 Multi-Head Self-Attention。"
"位置信息通过 Positional Encoding 注入，而非递归传播。"

# [D] Difference
"RNN 必须顺序计算（t 依赖 t-1），Transformer 可以并行计算所有位置的注意力。"
"CNN 需要多层才能捕获长距离依赖，注意力直接连接任意两个位置。"

# [E] Evidence
"在 WMT 2014 英德（4.5M 句对）和英法（36M 句对）上做了实验。"
"消融实验验证了多头、位置编码、残差连接各自的作用。"

# [L] Limitation
"自注意力计算复杂度 O(n²)，长序列（如 10K 词元）时显存和计算量爆炸。"
"对小数据集可能过拟合（论文用了大规模数据）。"</code></pre>
<div class="note">R/M/D/E/L 不仅是读论文的工具，也是写论文的框架。写论文时先想清楚这五个问题，论文结构自然就清晰了：先讲 Motivation（为什么做），再讲 Method（怎么做），然后 Result（效果如何），最后 Limitation（还有什么没解决）。</div>

<h2>7.5'''
        html = html.replace(old_74, new_74)
        print("[Fix 7] Chapter 7: Expanded section 7.4 (Paper reading method)")
    else:
        print("[Info] Chapter 7.4 already has sufficient content, skipping expansion")

# Write back
with open(HTML_PATH, 'w', encoding='utf-8') as f:
    f.write(html)

new_len = len(html)
print(f"\nDone! HTML updated to {new_len} chars")

# Quick validation
import re
h2s = re.findall(r'<h2>([^<]+)</h2>', html)
h3s = re.findall(r'<h3>([^<]+)</h3>', html)
print(f"Total h2: {len(h2s)}, h3: {len(h3s)}")

# Check chapter 1
ch1_h3 = [h for h in h3s if h.startswith('1.4')]
print(f"Chapter 1.4 subsections: {ch1_h3}")

# Check chapter 2
ch2_h3 = [h for h in h3s if h.startswith('2.5')]
print(f"Chapter 2.5 subsections: {ch2_h3}")
