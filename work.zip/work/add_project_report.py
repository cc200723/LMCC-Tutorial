# -*- coding: utf-8 -*-
"""
Add project report (附录 G) to the textbook HTML.
Based on the LMCC IDE practical session with real evaluation results.
"""
import os

BASE = r"C:\Users\MINXIN\Desktop\CCF LMCC"
HTML = os.path.join(BASE, "LMCC青少年组教材-增强版.html")

with open(HTML, "r", encoding="utf-8") as f:
    html = f.read()

# 1. Update TOC: add 附录 G
old_toc = '<li><a href="#附录-F-LMCC-IDE-实战指南">附录 F LMCC IDE 实战指南</a></li></ol></nav>'
new_toc = '''<li><a href="#附录-F-LMCC-IDE-实战指南">附录 F LMCC IDE 实战指南</a></li>
<li><a href="#附录-G-LMCC-IDE-项目报告">附录 G LMCC IDE 项目报告</a></li></ol></nav>'''

if old_toc in html:
    html = html.replace(old_toc, new_toc)
    print("[OK] TOC updated with 附录 G")
else:
    print("[WARN] TOC entry not found")

# 2. Insert the project report section before the closing divs
# Find the end of 附录 F
appendix_f_end = html.find('</section>', html.find('附录 F LMCC IDE 实战指南'))
if appendix_f_end < 0:
    print("[ERROR] Cannot find end of 附录 F")
    exit(1)
appendix_f_end += len('</section>')

project_report = '''
<section class="chapter" id="sec-附录-G-LMCC-IDE-项目报告">
<h1 id="附录-G-LMCC-IDE-项目报告">附录 G LMCC IDE 项目报告</h1>

<div class="key-box" style="background:#f0f7ff;border-left-color:#4a90d9;">
<h4>本附录导读</h4>
<p>本附录是一份完整的项目报告，记录了使用 LMCC IDE 完成 JY2026-LMCC 实战任务的全过程。报告涵盖任务分析、解题策略、代码实现、评测结果与反思总结，可作为参赛者撰写项目报告的参考模板。</p>
</div>

<h2>G.1 项目概述</h2>
<p>本项目在 LMCC IDE 环境中完成了 CCF 大模型能力认证青少年组的两道实战题：</p>
<ul>
<li><strong>T1 诗词格式标准化</strong>：设计 System Prompt 和生成参数，引导 Qwen3-0.6B 模型将各种格式混乱的古诗词填空题转换为标准 JSON 格式</li>
<li><strong>T2 新春诗词大会 RAG 系统</strong>：实现检索函数和 Prompt 构建，让模型根据从 100 首唐诗知识库中检索到的参考诗词回答填空选择题</li>
</ul>
<p>最终成绩：<strong>T1 得 45/50 分（9/10 正确），T2 得 40/50 分（8/10 正确），总计 85/100 分</strong>。</p>

<div class="key-box">
<h4>参考资源</h4>
<ul>
<li>LMCC IDE 使用教程：<a href="https://jy.hpe.cn/jhkx/jsxx/706058.htm" target="_blank">https://jy.hpe.cn/jhkx/jsxx/706058.htm</a></li>
<li>LMCC IDE 学习仓库（Gitee）：<a href="https://gitee.com/lmcc-ide/learn" target="_blank">https://gitee.com/lmcc-ide/learn</a></li>
<li>CCF 中小学大模型教育提纲：<a href="https://lmcc.ccf.org.cn/101/1010/10261.html" target="_blank">https://lmcc.ccf.org.cn/101/1010/10261.html</a></li>
<li>CCF 大模型能力认证大纲：<a href="https://lmcc.ccf.org.cn/101/1002/10080.html" target="_blank">https://lmcc.ccf.org.cn/101/1002/10080.html</a></li>
</ul>
</div>

<h2>G.2 任务 T1 —— 诗词格式标准化工程</h2>

<h3>G.2.1 问题分析与痛点</h3>
<p>T1 的核心挑战在于<strong>格式多样性</strong>。题目以古诗词填空题的形式出现，但每道题的选项格式、答案标注方式和干扰信息各不相同：</p>
<table class="tbl">
<thead><tr><th>维度</th><th>出现的格式变体</th><th>难点</th></tr></thead>
<tbody>
<tr><td>选项标记</td><td><code>A. xxx</code> / <code>(A)xxx</code> / <code>[A]xxx</code> / <code>①xxx</code> / <code>选择&lt;A&gt;即：xxx</code> / <code>◆ 第一个选项（记作A）</code></td><td>模型需识别所有格式并统一提取</td></tr>
<tr><td>答案标注</td><td><code>正确答案：A</code> / <code>答案为：(C)</code> / <code>标准答案：[A]</code> / <code>参考解析：此题应选择【第一个选项】</code></td><td>输出必须只保留大写字母，去除所有括号</td></tr>
<tr><td>干扰信息</td><td>"答案往往在前面哦"、"相信自己的第一感觉"、"加油"等</td><td>需区分答案标注与干扰提示</td></tr>
<tr><td>question 字段</td><td>诗句可能带前缀（"题目：""填空："），可能缺少句号</td><td>必须保留 <code>_____</code> 且以句号结尾</td></tr>
</tbody>
</table>

<h3>G.2.2 System Prompt 设计策略</h3>
<p>初版 Prompt 仅列出格式说明和 3 个示例，评测得分 35/50（7/10）。分析失败案例后，发现两类高频错误：</p>
<ul>
<li><strong>答案带括号</strong>：输入答案为 <code>(C)</code>，模型输出 <code>"answer": "(C)"</code> 而非 <code>"C"</code></li>
<li><strong>question 丢失 _____</strong>：模型将 <code>"_____,粒粒皆辛苦."</code> 错误地变成 <code>"粒粒皆辛苦."</code>，或直接填入答案诗句</li>
</ul>
<p>针对这两类错误，在 Prompt 中增加了<strong>明确的正反例对比</strong>：</p>
<pre><code>【answer字段关键规则】
answer字段必须只包含一个大写字母：A、B、C或D。
绝对不能包含括号、方括号、尖括号或其他任何字符。
错误示例："(C)"、"[A]"、"<B>"
正确示例："C"、"A"、"B"

【question字段关键规则】
- 必须保留原文中的"_____"作为空缺标记，不能替换成实际诗句
- 错误示例：把"_____,粒粒皆辛苦."变成"粒粒皆辛苦."
- 正确做法：原样保留"_____"，如"_____,粒粒皆辛苦."</code></pre>
<p>同时增加了 5 个针对性示例，每个示例都标注了"注意"说明关键点。优化后得分提升至 <strong>45/50（9/10）</strong>，仅第 9 题（使用 <code>◆ 第一个选项（记作A）</code> 格式）出错。</p>

<h3>G.2.3 生成参数调优</h3>
<p>生成参数的选择直接影响输出的稳定性和耗时：</p>
<table class="tbl">
<thead><tr><th>参数</th><th>设置值</th><th>理由</th></tr></thead>
<tbody>
<tr><td><code>max_new_tokens</code></td><td>512</td><td>JSON 输出通常不超过 200 token，512 留足余量</td></tr>
<tr><td><code>do_sample</code></td><td>False</td><td>贪心解码确保输出确定性，同一输入永远得到同一输出</td></tr>
<tr><td><code>enable_thinking</code></td><td>False</td><td>关闭思考模式，避免模型输出冗长推理过程导致超时</td></tr>
</tbody>
</table>

<h3>G.2.4 遇到的困难与解决</h3>
<table class="tbl">
<thead><tr><th>困难</th><th>表现</th><th>解决方法</th></tr></thead>
<tbody>
<tr><td>Python 输出缓冲</td><td>后台运行评测时输出文件为空</td><td>使用 <code>python -u</code> 强制无缓冲输出</td></tr>
<tr><td>CPU 推理慢</td><td>平均每题 30-90 秒，10 题需 10-16 分钟</td><td>确认 10 分钟时限内可完成；关闭 thinking 模式减少输出量</td></tr>
<tr><td>特殊 token 残留</td><td>模型输出末尾有 <code>&lt;|im_end|&gt;</code></td><td>评测脚本自动去除，无需特殊处理</td></tr>
<tr><td>复杂选项格式</td><td><code>◆ 第一个选项（记作A）</code> 格式未被识别</td><td>增加映射规则示例（第一个→A），但仍有个别失败</td></tr>
</tbody>
</table>

<h2>G.3 任务 T2 —— 新春诗词大会 RAG 系统</h2>

<h3>G.3.1 检索模块实现细节</h3>
<p>T2 提供了一个包含 100 首唐诗的知识库（<code>knowledge_base.json</code>），每首诗包含标题、作者、诗句（<code>paragraphs</code>）和释义（<code>prologue</code>）。检索函数需要从题目文本中提取关键词，在知识库中找到最相关的 top_k 首诗。</p>
<p>实现的检索策略包含三层匹配：</p>
<ol>
<li><strong>子串精确匹配</strong>：将题目中的诗句片段（<code>_____</code> 前后的中文）与每首诗的原文做子串匹配，长匹配得分更高（<code>score += len(fragment) * 2</code>）</li>
<li><strong>2-gram 匹配</strong>：将长关键词拆成相邻二字组（如"明月光"拆为"明月""月光"），分别匹配以提升召回率</li>
<li><strong>选项关键词补充</strong>：将四个选项的内容也作为关键词参与检索，因为正确答案的诗句一定在知识库中</li>
</ol>
<p>实测检索成功率：<strong>10/10 题全部检索到正确诗词</strong>，说明检索策略有效。</p>

<h3>G.3.2 上下文构建与 Prompt 设计</h3>
<p><code>build_user_message()</code> 函数将检索到的诗词和题目组装成用户消息：</p>
<pre><code>【参考诗词】
1. 《静夜思》 - 李白
   床前明月光，疑是地上霜。
   举头望明月，低头思故乡。
   释义：明亮的月光洒在床前...
2. 《竹里馆》 - 王维
   ...

【题目】
床前明月光,_____.
选项：A. 疑是地上霜  B. 低头思故乡  C. 举头望明月  D. 月是故乡明

请根据参考诗词，选出正确答案。只输出 [Answer]: X 格式。</code></pre>

<p>System Prompt 的核心设计是<strong>推理链引导</strong>：</p>
<pre><code>【关键答题策略】
1. 先在参考诗词中找到题目给出的诗句
2. 确定空缺"_____"在原诗中的位置：
   - 空缺在逗号前（如"_____,低头思故乡"）→ 答案是逗号前的内容
   - 空缺在逗号后（如"床前明月光,_____"）→ 答案是逗号后的内容
3. 选项格式可能不同：A. xxx / (A)xxx / [A]xxx / ①xxx</code></pre>
<p>初版 Prompt 仅有简单示例，得分 30/50（6/10）。增加推理链引导和 3 个针对性示例后，得分提升至 <strong>40/50（8/10）</strong>。</p>

<h3>G.3.3 RAG 流程的协同优化</h3>
<p>RAG 系统的性能取决于检索和生成的协同：</p>
<table class="tbl">
<thead><tr><th>环节</th><th>初版表现</th><th>优化后表现</th><th>优化措施</th></tr></thead>
<tbody>
<tr><td>检索</td><td>10/10 正确</td><td>10/10 正确</td><td>增加 2-gram 匹配和选项关键词</td></tr>
<tr><td>生成</td><td>6/10 正确</td><td>8/10 正确</td><td>增加推理链示例（先找原诗→定位置→选答案）</td></tr>
<tr><td>耗时</td><td>约 15s/题</td><td>约 19s/题</td><td>Prompt 更长导致推理稍慢，但准确率提升更值</td></tr>
</tbody>
</table>

<h3>G.3.4 输出格式控制</h3>
<p>评测脚本期望模型输出 <code>[Answer]: X</code> 格式。实测 Qwen3-0.6B 在贪心解码下格式遵循率 100%，所有 10 题的输出都包含 <code>[Answer]: </code> 前缀，提取答案成功。</p>
<p>需要注意的是，模型输出末尾会附带 <code>&lt;|im_end|&gt;</code> 特殊 token，评测脚本的 <code>extract_answer()</code> 函数会自动去除，无需在 Prompt 中特殊处理。</p>

<h2>G.4 评测结果与分析</h2>

<h3>G.4.1 成绩汇总</h3>
<table class="tbl">
<thead><tr><th>评测轮次</th><th>T1 得分</th><th>T2 得分</th><th>总计</th><th>主要优化内容</th></tr></thead>
<tbody>
<tr><td>第 1 轮（初版）</td><td>35/50 (7/10)</td><td>30/50 (6/10)</td><td>65/100</td><td>基础 Prompt + 简单检索</td></tr>
<tr><td>第 2 轮（优化后）</td><td><strong>45/50 (9/10)</strong></td><td><strong>40/50 (8/10)</strong></td><td><strong>85/100</strong></td><td>答案格式约束 + question 保留规则 + RAG 推理链示例</td></tr>
</tbody>
</table>

<h3>G.4.2 T1 失败案例分析</h3>
<p>第 9 题是唯一失败的题目，其输入格式非常复杂：</p>
<pre><code>※古诗词知识测验※
【题干】请完成下列诗句：
    _____,天涯若比邻
【选项说明】
  ◆ 第一个选项（记作A）的内容是：海内存知己
  ◆ 第二个选项（记作B）的内容是：相逢何必曾相识
  ◆ 第三个选项（记作C）的内容是：莫愁前路无知己
  ◆ 第四个选项（记作D）的内容是：桃花潭水深千尺
【重要提示】
  • 正确答案一定在A/B/C/D中
  • 注意：有些选项是干扰项！
【温馨提醒】相信自己的第一感觉，答案往往在前面哦！
━━━━━━━━━━━━━━━━━━
参考解析：经查证，此题应选择【第一个选项】</code></pre>
<p>模型错误地将 question 填入了答案（输出 <code>"海内存知己,天涯若比邻"</code> 而非 <code>"_____,天涯若比邻."</code>），且将选项 D 的"桃花潭水深千尺"错误生成为"桃花潭水深千贯彻"（字符幻觉）。这说明对于极端复杂的格式，0.6B 参数的小模型仍有局限。</p>

<h3>G.4.3 T2 失败案例分析</h3>
<p>T2 的两道失败题都是<strong>模型推理错误</strong>而非检索错误：</p>
<ul>
<li><strong>第 2 题</strong>：题目"春眠不觉晓,_____"，正确答案 B（处处闻啼鸟），模型选了 C（夜来风雨声）。模型混淆了同一首诗《春晓》中的相邻诗句——"处处闻啼鸟"和"夜来风雨声"是同一联的上下句，模型未能正确确定空缺位置。</li>
<li><strong>第 4 题</strong>：题目"_____,低头思故乡"，正确答案 C（举头望明月），模型选了 D。空缺在前半句时，模型推理更容易出错，因为需要"反向"找到逗号前的内容。</li>
</ul>

<h2>G.5 总结与收获</h2>

<h3>G.5.1 核心经验</h3>
<ol>
<li><strong>Prompt 优化是最有效的提分手段</strong>：每增加一个针对性示例或约束规则，就能修复一类错误。T1 从 35→45 分、T2 从 30→40 分的提分全部来自 Prompt 优化，未修改任何代码逻辑。</li>
<li><strong>正反例对比比抽象规则更有效</strong>：告诉模型"answer 不能带括号"不如直接展示 <code>"(C)" → 错误</code>、<code>"C" → 正确</code>。</li>
<li><strong>检索质量是 RAG 的基石</strong>：本项目的检索成功率达 100%，说明子串匹配 + 2-gram + 选项关键词的三层策略对小规模知识库（100 首）足够有效。</li>
<li><strong>CPU 推理在时限内可行</strong>：Qwen3-0.6B 在 CPU 上平均 15-30 秒/题，10 题约 3-16 分钟，在 10 分钟时限内可完成。关键是关闭 thinking 模式以减少输出量。</li>
</ol>

<h3>G.5.2 不足与改进方向</h3>
<ul>
<li><strong>极端格式处理</strong>：对于 <code>◆ 第一个选项（记作A）</code> 等非常规格式，0.6B 模型仍有困难。可以在 Prompt 中增加更多映射示例，或在 <code>submission.py</code> 中做预处理。</li>
<li><strong>相邻诗句混淆</strong>：T2 中模型容易混淆同一首诗的相邻诗句。可以在 Prompt 中强调"先在参考诗词中逐行查找题目给出的诗句，再确定空缺位置"。</li>
<li><strong>字符幻觉</strong>：小模型偶尔生成不存在的字符（如"桃花潭水深千贯彻"），可以通过降低 <code>max_new_tokens</code> 或增加重复惩罚来缓解。</li>
</ul>

<h3>G.5.3 对认证备考的建议</h3>
<ol>
<li>先用 <code>--mode demo</code> 反复练习，熟悉所有题型和评测流程</li>
<li>每次评测后仔细阅读"字段对比"和"模型原始输出"，找到具体的失败模式</li>
<li>针对每种失败模式在 Prompt 中增加一个正反例对比</li>
<li>最后用 <code>--mode grading</code> 验证优化效果</li>
<li>关注 <a href="https://gitee.com/lmcc-ide/learn" target="_blank">Gitee 学习仓库</a> 获取最新题型和更新</li>
</ol>

<h2>G.6 AI 使用记录</h2>
<p>本项目在完成过程中使用了 AI 辅助工具，具体使用情况如下：</p>
<table class="tbl">
<thead><tr><th>环节</th><th>AI 辅助内容</th><th>人工验证/修改</th></tr></thead>
<tbody>
<tr><td>题目理解</td><td>AI 阅读 README.md 和 evaluate.py，总结题目要求和评分逻辑</td><td>人工确认理解正确</td></tr>
<tr><td>Prompt 初版</td><td>AI 根据 T1/T2 题目要求生成初版 System Prompt</td><td>直接使用，评测 7/10 和 6/10</td></tr>
<tr><td>错误分析</td><td>AI 分析 demo 评测输出，定位失败原因（答案带括号、question 丢失 _____）</td><td>人工确认分析合理</td></tr>
<tr><td>Prompt 优化</td><td>AI 根据错误分析增加正反例对比和针对性示例</td><td>人工审核后采纳，评测提升至 9/10 和 8/10</td></tr>
<tr><td>检索函数</td><td>AI 实现 retrieve_relevant_poems() 的三层匹配策略</td><td>人工验证检索结果，确认 10/10 检索正确</td></tr>
<tr><td>项目报告</td><td>AI 根据评测记录撰写本报告初稿</td><td>人工审核、修订、确认内容准确</td></tr>
</tbody>
</table>

<div class="note">本报告所有评测数据均来自真实运行环境（Windows + LMCC IDE Python 3.12 + PyTorch 2.4.0 + Transformers 4.55.0 + Qwen3-0.6B 模型），终端输出未做任何人工修改。建议参考 <a href="https://jy.hpe.cn/jhkx/jsxx/706058.htm" target="_blank">LMCC IDE 使用教程</a> 和 <a href="https://gitee.com/lmcc-ide/learn" target="_blank">Gitee 学习仓库</a> 了解更多实战技巧。</div>

</section>
'''

html = html[:appendix_f_end] + project_report + html[appendix_f_end:]

with open(HTML, "w", encoding="utf-8") as f:
    f.write(html)

print(f"[OK] Project report (附录 G) inserted")
print(f"HTML size: {len(html)} chars")
