# -*- coding: utf-8 -*-
"""
LMCC 青少年组教材 · 矢量图生成器（Nature 风格重绘版）
全部图形用手绘 SVG（流程图/结构图）或 matplotlib（数据图）生成，
所有内容包在 <g id="content"> 内，便于自动检测遮挡/截断。
设计原则：白底、留白充足、文字不溢出 viewBox、字号统一、配色克制。
"""
import os, re, math
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch
import matplotlib.patches as mpatches

# ---------- 配色 ----------
INK   = "#1f2a37"   # 主文字/描边
SUB   = "#5b6770"   # 次文字
BLUE  = "#1f6f9c"   # 主蓝
BLUE_T= "#e8f1f8"
ORANGE= "#c1572f"   # 橙
ORANGE_T="#fbeee6"
GREEN = "#2f7d4f"   # 绿
GREEN_T= "#e7f3ec"
PURPLE="#6a4c93"  # 紫
PURPLE_T="#f0ebf6"
RED   = "#b23a3a"   # 红（注意/错误）
RED_T = "#f6e7e7"
GREY  = "#8a949c"
GRID  = "#d9dee3"
PANEL = "#f7f9fb"

FONTS = '"Noto Sans CJK SC","Microsoft YaHei","PingFang SC",sans-serif'
# matplotlib 用系统字体
plt.rcParams["font.family"] = "Microsoft YaHei"
plt.rcParams["font.sans-serif"] = ["Microsoft YaHei"]
plt.rcParams["axes.unicode_minus"] = False
plt.rcParams["svg.fonttype"] = "path"   # 文字转路径，避免缺字

# ---------- 基础工具 ----------
def e(tag, attrs, inner=""):
    a = " ".join(f'{k}="{v}"' for k, v in attrs.items())
    if inner == "":
        return f"<{tag} {a}/>"
    return f"<{tag} {a}>{inner}</{tag}>"

def box(x, y, w, h, fill="#fff", stroke=INK, sw=1.4, rx=10, dash=None):
    a = {"x":x,"y":y,"width":w,"height":h,"rx":rx,
          "fill":fill,"stroke":stroke,"stroke-width":sw}
    if dash: a["stroke-dasharray"]=dash
    return e("rect", a)

def arrow(x1,y1,x2,y2,color=BLUE,sw=1.6,dash=None,head=7):
    a = {"x1":x1,"y1":y1,"x2":x2,"y2":y2,"stroke":color,
          "stroke-width":sw,"marker-end":f"url(#ah{head})","fill":"none"}
    if dash: a["stroke-dasharray"]=dash
    return e("line", a)

def _char_w(ch, fs):
    return fs*1.02 if ord(ch) > 0x2E80 else fs*0.56

def wrap_lines(text, fs, maxw):
    """把字符串按 maxw(px) 自动折行；保留显式换行符。"""
    out=[]
    for para in text.split("\n"):
        if maxw is None:
            out.append(para); continue
        line=""; bw=0.0
        for ch in para:
            cw=_char_w(ch,fs)
            if bw+cw>maxw and line:
                out.append(line); line=""; bw=0.0
            line+=ch; bw+=cw
        out.append(line)
    return out

def ctext(x,y,text,fs=12,color=INK,anchor="start",bold=False,
          maxw=None,line_gap=None):
    """多行文字。anchor=middle/end 时每行各自居中/右对齐于 x。"""
    lines=wrap_lines(text,fs,maxw)
    if line_gap is None: line_gap=fs*1.32
    fw="700" if bold else "400"
    spans=[]
    for i,ln in enumerate(lines):
        ly=y+i*line_gap
        if anchor=="start":
            sx=x; txt=f'<tspan x="{sx:.1f}" y="{ly:.1f}">{ln}</tspan>'
        else:
            # 估算该行像素宽
            wsum=sum(_char_w(c,fs) for c in ln)
            sx = x - wsum/2 if anchor=="middle" else x - wsum
            txt=f'<tspan x="{sx:.1f}" y="{ly:.1f}">{ln}</tspan>'
        spans.append(txt)
    return e("text",{"font-family":FONTS,"font-size":fs,"fill":color,
                     "font-weight":fw,"text-anchor":"start"}, "".join(spans))

def circle(cx,cy,r,fill=BLUE,stroke=INK,sw=1.4):
    return e("circle",{"cx":cx,"cy":cy,"r":r,"fill":fill,"stroke":stroke,"stroke-width":sw})

def elabel(cx,cy,text,fs=12,color="#fff",bold=True):
    return ctext(cx,cy+fs*0.36,text,fs,color,"middle",bold)

def doc(W,H,body):
    # 箭头标记（多种尺寸）
    markers=""
    for h in (6,7,8):
        markers+=f'<marker id="ah{h}" markerWidth="{h+4}" markerHeight="{h+4}" refX="{h}" refY="{h/2:.1f}" orient="auto-start-reverse"><path d="M0,0 L{h},{h/2:.1f} L0,{h} z" fill="{BLUE}"/></marker>'
        markers+=f'<marker id="ah{h}o" markerWidth="{h+4}" markerHeight="{h+4}" refX="{h}" refY="{h/2:.1f}" orient="auto-start-reverse"><path d="M0,0 L{h},{h/2:.1f} L0,{h} z" fill="{ORANGE}"/></marker>'
        markers+=f'<marker id="ah{h}g" markerWidth="{h+4}" markerHeight="{h+4}" refX="{h}" refY="{h/2:.1f}" orient="auto-start-reverse"><path d="M0,0 L{h},{h/2:.1f} L0,{h} z" fill="{GREEN}"/></marker>'
        markers+=f'<marker id="ah{h}p" markerWidth="{h+4}" markerHeight="{h+4}" refX="{h}" refY="{h/2:.1f}" orient="auto-start-reverse"><path d="M0,0 L{h},{h/2:.1f} L0,{h} z" fill="{PURPLE}"/></marker>'
    head=f'<defs>{markers}</defs>'
    bg=e("rect",{"x":0,"y":0,"width":W,"height":H,"fill":"#ffffff"})
    return f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}">{head}{bg}<g id="content">{body}</g></svg>'

def save(name, svg):
    os.makedirs(FIG_DIR, exist_ok=True)
    p=os.path.join(FIG_DIR, name+".svg")
    open(p,"w",encoding="utf-8").write(svg)
    return p

FIG_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "figs")

# =====================================================================
# F1 认证结构总览
# =====================================================================
def fig_syllabus():
    W,H=840,560
    b=""
    b+=ctext(W/2,40,"LMCC 青少年组认证结构",17,BLUE,"middle",True)
    # 四个编
    parts=[
        (30, 80, "第一部分·基础素养", ["概念辨析","程序阅读四步法","数据划分与指标"], BLUE, BLUE_T),
        (450,80, "第二部分·原理与训练", ["注意力与架构","预训练与资源","指令微调与对齐"], ORANGE, ORANGE_T),
        (30, 330, "第三部分·应用工程", ["提示工程","检索增强 RAG","智能体与工具","多模态模型"], GREEN, GREEN_T),
        (450,330, "第四部分·评测与安全", ["模型评测","长思维链/论文","伦理与安全"], PURPLE, PURPLE_T),
    ]
    for x,y,t,items,c,ct in parts:
        b+=box(x,y,360,180,fill=ct,stroke=c,sw=1.6,rx=12)
        b+=box(x,y,360,34,fill=c,stroke=c,rx=12)
        b+=ctext(x+180,y+22,t,13.5,"#fff","middle",True)
        for i,it in enumerate(items):
            b+=ctext(x+24,y+62+i*42,it,12.5,INK,"start")
            b+=circle(x+12,y+57+i*42,3.2,fill=c)
    # T0-T3 条
    b+=box(30,530,780,18,fill=PANEL,stroke=GRID,sw=1,dash="2,3")
    b+=ctext(420,544,"实战任务：T0 教学题 · T1 简单题 · T2 困难题 · T3 探索题",11.5,SUB,"middle",True)
    return save("f1_syllabus", doc(W,H,b))

# =====================================================================
# F2 语言模型发展四阶段
# =====================================================================
def fig_lm_history():
    W,H=840,300
    b=""
    b+=ctext(W/2,34,"语言模型发展的四个阶段",16,BLUE,"middle",True)
    items=[("① 统计语言模型","N-gram，按局部词频估计下一个词","难以处理长距离依赖"),
           ("② 神经网络语言模型","前馈/RNN/LSTM 学连续表示","泛化优于纯词频"),
           ("③ 预训练语言模型","BERT 掩码 / GPT 自回归","先学通用表示再微调"),
           ("④ 大语言模型","更大参数·数据·计算","生成/理解/推理/工具统一")]
    x0=30; y=80; w=185; h=160; gap=15
    cols=[BLUE,ORANGE,GREEN,PURPLE]
    for i,(t,d1,d2) in enumerate(items):
        x=x0+i*(w+gap)
        b+=box(x,y,w,h,fill="#fff",stroke=cols[i],sw=1.6,rx=12)
        b+=box(x,y,w,38,fill=cols[i],stroke=cols[i],rx=12)
        b+=ctext(x+w/2,y+24,t,12.5,"#fff","middle",True)
        b+=ctext(x+14,y+64,d1,11.5,INK,"start",maxw=w-28)
        b+=ctext(x+14,y+118,d2,11,SUB,"start",maxw=w-28)
        if i<3:
            b+=arrow(x+w+3,y+h/2,x+w+gap-3,y+h/2,color=GREY,sw=1.5)
    return save("f2_lm_history", doc(W,H,b))

# =====================================================================
# F3 三种学习范式
# =====================================================================
def fig_paradigms():
    W,H=840,330
    b=""
    b+=ctext(W/2,34,"三种学习方式：训练信号来自哪里？",16,BLUE,"middle",True)
    items=[("监督学习","人工/业务标签","分类、回归",BLUE,BLUE_T),
           ("无监督学习","无人工目标标签","聚类、降维",ORANGE,ORANGE_T),
           ("自监督学习","从数据自身构造标签","下一词/掩码/对比",GREEN,GREEN_T)]
    x0=40;y=80;w=235;h=200
    for i,(t,sig,task,c,ct) in enumerate(items):
        x=x0+i*(w+25)
        b+=box(x,y,w,h,fill=ct,stroke=c,sw=1.6,rx=12)
        b+=ctext(x+w/2,y+34,t,14,c,"middle",True)
        b+=ctext(x+w/2,y+74,"训练信号",11,SUB,"middle",True)
        b+=ctext(x+w/2,y+96,sig,12,INK,"middle",maxw=w-30)
        b+=ctext(x+w/2,y+140,"典型任务",11,SUB,"middle",True)
        b+=ctext(x+w/2,y+162,task,12,INK,"middle",maxw=w-30)
    return save("f3_paradigms", doc(W,H,b))

# =====================================================================
# F4 训练生命周期
# =====================================================================
def fig_lifecycle():
    W,H=840,300
    b=""
    b+=ctext(W/2,34,"模型训练与推理生命周期",16,BLUE,"middle",True)
    steps=[("训练集","更新参数",BLUE),("验证集","选模型/调参",ORANGE),
           ("测试集","最终估计泛化",GREEN),("推理","部署后服务",PURPLE)]
    x0=40;y=110;w=170;h=90
    for i,(t,d,c) in enumerate(steps):
        x=x0+i*(w+30)
        b+=box(x,y,w,h,fill="#fff",stroke=c,sw=1.6,rx=12)
        b+=ctext(x+w/2,y+34,t,14,c,"middle",True)
        b+=ctext(x+w/2,y+64,d,11,SUB,"middle",maxw=w-20)
        if i<3:
            b+=arrow(x+w+4,y+h/2,x+w+26,y+h/2,color=GREY,sw=1.6)
    b+=ctext(420,250,"⚠ 测试集只用于最终评估；反复用于调参会造成数据泄漏（过拟合测试集）",12,RED,"middle",True,maxw=780)
    return save("f4_lifecycle", doc(W,H,b))

# =====================================================================
# F5 Transformer 解码器块
# =====================================================================
def fig_transformer():
    W,H=460,520
    b=""
    b+=ctext(W/2,34,"因果解码器中的一个 Transformer 块",15,BLUE,"middle",True)
    cy=70
    b+=box(60,cy,340,400,fill="#fff",stroke=BLUE,sw=1.8,rx=14)
    # 输入
    b+=box(120,cy+20,220,40,fill=BLUE_T,stroke=BLUE)
    b+=ctext(230,cy+45,"输入表示 x",12.5,BLUE,"middle",True)
    # 因果掩码注意力
    b+=box(100,cy+85,260,70,fill="#fff",stroke=ORANGE)
    b+=ctext(230,cy+112,"因果掩码自注意力",12.5,ORANGE,"middle",True)
    b+=ctext(230,cy+134,"Masked Multi-Head Attn",10.5,SUB,"middle")
    # 残差 + Add&Norm
    b+=box(100,cy+175,260,46,fill=ORANGE_T,stroke=ORANGE)
    b+=ctext(230,cy+202,"残差连接 + RMSNorm",12,ORANGE,"middle",True)
    # FFN
    b+=box(100,cy+240,260,70,fill="#fff",stroke=GREEN)
    b+=ctext(230,cy+267,"前馈网络 FFN",12.5,GREEN,"middle",True)
    b+=ctext(230,cy+289,"Linear→激活→Linear",10.5,SUB,"middle")
    # 残差 + Add&Norm
    b+=box(100,cy+325,260,46,fill=GREEN_T,stroke=GREEN)
    b+=ctext(230,cy+352,"残差连接 + RMSNorm",12,GREEN,"middle",True)
    # 输出
    b+=box(120,cy+385,220,34,fill=BLUE_T,stroke=BLUE)
    b+=ctext(230,cy+407,"输出表示",12.5,BLUE,"middle",True)
    # 残差线
    b+=arrow(190,cy+60,190,cy+85,color=GREY,sw=1.2,dash="4,3")
    b+=arrow(270,cy+60,270,cy+85,color=GREY,sw=1.2,dash="4,3")
    b+=arrow(230,cy+155,230,cy+175,color=GREY,sw=1.4)
    b+=arrow(230,cy+221,230,cy+240,color=GREY,sw=1.4)
    b+=arrow(230,cy+310,230,cy+325,color=GREY,sw=1.4)
    return save("f5_transformer", doc(W,H,b))

# =====================================================================
# F6 注意力计算 QKV
# =====================================================================
def fig_attention():
    W,H=840,360
    b=""
    b+=ctext(W/2,34,"缩放点积注意力：Q、K、V 如何产生输出",16,BLUE,"middle",True)
    # 三列
    b+=box(40,80,210,210,fill=BLUE_T,stroke=BLUE)
    b+=ctext(145,112,"Q（查询）",13,BLUE,"middle",True)
    b+=ctext(145,150,"question",11,SUB,"middle")
    b+=ctext(145,210,"来自当前位置\n要“问什么”",11.5,INK,"middle",maxw=190)
    b+=box(315,80,210,210,fill=ORANGE_T,stroke=ORANGE)
    b+=ctext(420,112,"K（键）",13,ORANGE,"middle",True)
    b+=ctext(420,150,"key",11,SUB,"middle")
    b+=ctext(420,210,"每个位置“是什么”\n用来被查询",11.5,INK,"middle",maxw=190)
    b+=box(590,80,210,210,fill=GREEN_T,stroke=GREEN)
    b+=ctext(695,112,"V（值）",13,GREEN,"middle",True)
    b+=ctext(695,150,"value",11,SUB,"middle")
    b+=ctext(695,210,"每个位置“携带什么”\n最终被取出",11.5,INK,"middle",maxw=190)
    # 计算流
    b+=ctext(420,330,"scores = Q·Kᵀ / √d  →  softmax  →  与 V 加权求和 = 输出",12.5,INK,"middle",True,maxw=800)
    b+=arrow(250,185,313,185,color=GREY,sw=1.6)
    b+=arrow(525,185,588,185,color=GREY,sw=1.6)
    b+=arrow(700,290,560,250,color=GREY,sw=1.4,dash="4,3")
    return save("f6_attention", doc(W,H,b))

# =====================================================================
# F7 三类架构
# =====================================================================
def fig_architectures():
    W,H=840,360
    b=""
    b+=ctext(W/2,34,"三类 Transformer 架构与信息可见范围",16,BLUE,"middle",True)
    items=[("编码器-解码器","编码器双向；解码器因果；交叉注意力读编码器","翻译/摘要/序列转换",BLUE),
           ("因果解码器","每个位置只看自身及左侧（过去）","通用生成、对话",ORANGE),
           ("前缀解码器","前缀内部双向，生成区因果","条件生成/统一理解生成",GREEN)]
    x0=30;y=80;w=250;h=230
    for i,(t,d,task,c) in enumerate(items):
        x=x0+i*(w+25)
        b+=box(x,y,w,h,fill="#fff",stroke=c,sw=1.6,rx=12)
        b+=box(x,y,w,38,fill=c,stroke=c,rx=12)
        b+=ctext(x+w/2,y+24,t,13,c,"middle",True)
        b+=ctext(x+w/2,y+78,d,12,INK,"middle",maxw=w-26)
        b+=ctext(x+w/2,y+170,task,11.5,SUB,"middle",maxw=w-26)
        # 小示意图：可见范围
        by=y+120
        b+=box(x+30,by,190,40,fill=PANEL,stroke=GRID)
        for k in range(6):
            col = c if (i==0) or (i==1 and k==0) or (i==2 and k<3) else GREY
            # 简化：用方块表示位置，彩色=可见
            fill = c if not (i==1 and k>0) and not (i==2 and k>=3) else "#dfe5ea"
            b+=box(x+36+k*30,by+10,22,20,fill=fill,stroke=INK,sw=0.8)
    return save("f7_architectures", doc(W,H,b))

# =====================================================================
# F8 注意力复杂度（matplotlib）
# =====================================================================
def fig_attn_complexity():
    W,H=820,420
    fig,ax=plt.subplots(figsize=(W/110.0,H/110.0),dpi=110)
    fig.patch.set_facecolor("white")
    L=list(range(32,1025,32))
    oL2=[n*n*4096/1e9 for n in L]      # O(L^2 d), d=4096
    oLd2=[n*4096*4096/1e9 for n in L]   # O(L d^2)
    ax.plot(L,oL2,color=BLUE,lw=2.4,marker="o",ms=4,label="O(L²·d)：序列变长时算力随 L² 增长")
    ax.plot(L,oLd2,color=ORANGE,lw=2.4,marker="s",ms=4,label="O(L·d²)：固定 d，只随 L 线性增长")
    ax.set_xlabel("序列长度 L",fontsize=12)
    ax.set_ylabel("相对算力（归一化）",fontsize=12)
    ax.set_title("注意力复杂度：为何长序列昂贵",fontsize=14,color="#1f2a37",weight="bold")
    ax.grid(True,ls="--",lw=0.6,color="#d9dee3")
    ax.legend(fontsize=10,loc="upper left",frameon=True)
    ax.tick_params(labelsize=10)
    for sp in ax.spines.values(): sp.set_color("#cfd6dd")
    fig.tight_layout()
    p=os.path.join(FIG_DIR,"f8_attn_complexity.svg")
    fig.savefig(p,format="svg",bbox_inches="tight"); plt.close(fig)
    return p

# =====================================================================
# F9 温度采样（matplotlib）
# =====================================================================
def fig_temperature():
    W,H=820,420
    fig,axes=plt.subplots(1,3,figsize=(W/110.0,H/110.0),dpi=110)
    fig.patch.set_facecolor("white")
    labels=["A","B","C","D","E","F"]
    probs=[0.05,0.15,0.30,0.25,0.15,0.10]
    temps=[0.01,1.0,2.0]
    titles=["T=0.01 几乎贪心","T=1.0 接近原始分布","T=2.0 更平坦/随机"]
    cols=[BLUE,ORANGE,GREEN]
    for ax,T,ti,c in zip(axes,temps,titles,cols):
        p=[max(pp**(1.0/T),1e-6) for pp in probs]
        s=sum(p); p=[x/s for x in p]
        ax.bar(labels,p,color=c,width=0.62)
        ax.set_title(ti,fontsize=11.5,weight="bold")
        ax.set_ylim(0,1.0)
        ax.tick_params(labelsize=9)
        ax.grid(axis="y",ls="--",lw=0.6,color="#d9dee3")
        for sp in ax.spines.values(): sp.set_color("#cfd6dd")
    fig.suptitle("温度 T 对输出概率分布的影响",fontsize=14,weight="bold",color="#1f2a37")
    fig.tight_layout(rect=[0,0,1,0.94])
    p=os.path.join(FIG_DIR,"f9_temperature.svg")
    fig.savefig(p,format="svg",bbox_inches="tight"); plt.close(fig)
    return p

# =====================================================================
# F10 解码树（贪心 vs 采样）
# =====================================================================
def fig_decode_tree():
    W,H=840,400
    b=""
    b+=ctext(W/2,34,"解码策略：贪心搜索 vs 温度采样",16,BLUE,"middle",True)
    # 左：贪心
    b+=ctext(200,66,"贪心（每步取最大概率）",12.5,ORANGE,"middle",True)
    nodes=[(200,100,"“今天”"),(130,170,"“天气”"),(270,170,"“吃饭”"),(130,245,"“很好”")]
    for x,y,t in nodes:
        b+=circle(x,y,30,fill=ORANGE_T,stroke=ORANGE)
        b+=ctext(x,y+4,t,11,INK,"middle")
    b+=arrow(200,130,135,143,ORANGE,1.4)
    b+=arrow(200,130,265,143,ORANGE,1.4)
    b+=arrow(130,200,130,217,ORANGE,1.4)
    b+=ctext(130,300,"确定性、稳定，但可能重复/局部最优",11,SUB,"middle",maxw=240)
    # 右：采样
    b+=ctext(640,66,"温度采样（按分布随机）",12.5,GREEN,"middle",True)
    snodes=[(640,100,"“今天”"),(560,170,"“天气”"),(640,170,"“心情”"),(720,170,"“会议”"),
            (560,245,"“晴”"),(640,245,"“不错”"),(720,245,"“改期”")]
    for x,y,t in snodes:
        b+=circle(x,y,27,fill=GREEN_T,stroke=GREEN)
        b+=ctext(x,y+4,t,10.5,INK,"middle")
    # 多分支
    for tx,ty in [(560,170),(640,170),(720,170)]:
        b+=arrow(640,127,tx,146,GREEN,1.3)
    b+=arrow(560,197,560,221,GREEN,1.2)
    b+=arrow(640,197,640,221,GREEN,1.2)
    b+=arrow(720,197,720,221,GREEN,1.2)
    b+=ctext(640,300,"多样、有创意，但可能离题/不稳定",11,SUB,"middle",maxw=240)
    # 分隔
    b+=e("line",{"x1":420,"y1":60,"x2":420,"y2":330,"stroke":GRID,"stroke-width":1.2,"stroke-dasharray":"4,4"})
    return save("f10_decode_tree", doc(W,H,b))

# =====================================================================
# F11 INT4 量化（matplotlib）
# =====================================================================
def fig_int4():
    W,H=820,420
    fig,ax=plt.subplots(figsize=(W/110.0,H/110.0),dpi=110)
    fig.patch.set_facecolor("white")
    bits=[16,8,4]
    mem=[28.0,14.0,7.0]
    cols=[BLUE,ORANGE,GREEN]
    bars=ax.bar([str(b)+" bit" for b in bits],mem,color=cols,width=0.55)
    for r,m in zip(bars,mem):
        ax.text(r.get_x()+r.get_width()/2,m+0.5,f"{m:.1f} GB",ha="center",fontsize=12,weight="bold")
    ax.set_ylabel("权重本体显存（GB，14B 模型）",fontsize=12)
    ax.set_title("INT4 量化：每参数 4 bit = 0.5 Byte，显存约降为 1/4",fontsize=13,weight="bold",color="#1f2a37")
    ax.set_ylim(0,32)
    ax.grid(axis="y",ls="--",lw=0.6,color="#d9dee3")
    ax.tick_params(labelsize=11)
    for sp in ax.spines.values(): sp.set_color("#cfd6dd")
    fig.tight_layout()
    p=os.path.join(FIG_DIR,"f11_int4.svg")
    fig.savefig(p,format="svg",bbox_inches="tight"); plt.close(fig)
    return p

# =====================================================================
# F12 RAG 流程
# =====================================================================
def fig_rag():
    W,H=840,330
    b=""
    b+=ctext(W/2,34,"检索增强生成（RAG）流程",16,BLUE,"middle",True)
    steps=[("① 查询","用户问题",BLUE),("② 编码","Embedding + L2 归一化",ORANGE),
           ("③ 检索","余弦相似度 Top-k",GREEN),("④ 拼接","参考知识 + 题目",PURPLE),
           ("⑤ 生成","基于参考作答",RED)]
    x0=25;y=90;w=150;h=110
    for i,(t,d,c) in enumerate(steps):
        x=x0+i*(w+12)
        b+=box(x,y,w,h,fill="#fff",stroke=c,sw=1.6,rx=12)
        b+=box(x,y,w,32,fill=c,stroke=c,rx=12)
        b+=ctext(x+w/2,y+21,t,12.5,"#fff","middle",True)
        b+=ctext(x+w/2,y+74,d,11,INK,"middle",maxw=w-18)
        if i<4:
            b+=arrow(x+w+3,y+h/2,x+w+9,y+h/2,color=GREY,sw=1.6)
    b+=ctext(420,250,"关键：先评检索（目标文档是否进 Top-k），再评生成（是否忠于参考）",12,SUB,"middle",True,maxw=790)
    return save("f12_rag", doc(W,H,b))

# =====================================================================
# F13 余弦相似度
# =====================================================================
def fig_cosine():
    W,H=360,360
    b=""
    b+=ctext(W/2,32,"余弦相似度：先 L2 归一化，再点积",15,BLUE,"middle",True)
    # 向量箭头
    b+=arrow(60,300,260,300,color=BLUE,sw=2.4)
    b+=ctext(160,292,"q",13,BLUE,"middle",True)
    b+=arrow(60,300,200,110,color=ORANGE,sw=2.4)
    b+=ctext(125,200,"d",13,ORANGE,"middle",True)
    b+=circle(60,300,4,fill=INK)
    # 角度
    b+=e("path",{"d":"M60,300 Q 130,250 200,160","fill":"none","stroke":GREY,"stroke-width":1.2,"stroke-dasharray":"3,3"})
    b+=ctext(120,250,"θ",14,RED,"middle",True)
    b+=ctext(180,330,"sim = cos θ =  q̂·d̂   （‖q̂‖=‖d̂‖=1）",12,INK,"middle",True,maxw=330)
    b+=ctext(180,355,"θ 越小 → 方向越接近 → 相似度越接近 1",11,SUB,"middle",maxw=330)
    return save("f13_cosine", doc(W,H,b))

# =====================================================================
# F14 工具调用 JSON 校验流程
# =====================================================================
def fig_agent():
    W,H=840,360
    b=""
    b+=ctext(W/2,34,"工具调用 JSON 校验流程",16,BLUE,"middle",True)
    steps=[("模型输出字符串",BLUE),("json.loads 可解析？",ORANGE),
           ("结构：仅 tool_name+arguments？",GREEN),("工具名在白名单？",PURPLE),
           ("参数类型/范围合规？",RED)]
    x0=30;y=90;w=150;h=110
    for i,(t,c) in enumerate(steps):
        x=x0+i*(w+12)
        b+=box(x,y,w,h,fill="#fff",stroke=c,sw=1.6,rx=12)
        b+=ctext(x+w/2,y+58,t,11.5,c,"middle",True,maxw=w-14)
        if i<4:
            b+=arrow(x+w+3,y+h/2,x+w+9,y+h/2,color=GREY,sw=1.6)
    b+=ctext(420,250,"任一环节失败 → 拒绝该次调用并抛出错误（绝不盲目执行）",12,RED,"middle",True,maxw=790)
    return save("f14_agent", doc(W,H,b))

# =====================================================================
# F15 表现型思维链（matplotlib）
# =====================================================================
def fig_performative():
    W,H=820,420
    fig,ax=plt.subplots(figsize=(W/110.0,H/110.0),dpi=110)
    fig.patch.set_facecolor("white")
    import numpy as np
    rng=np.random.default_rng(7)
    steps=list(range(1,9))
    # 内部答案在很早形成（高置信），外部文字逐步“解释”
    internal=[0.5,0.82,0.9,0.93,0.94,0.95,0.95,0.95]
    external=[0.1,0.25,0.45,0.6,0.72,0.82,0.9,0.95]
    ax.plot(steps,internal,color=BLUE,lw=2.6,marker="o",ms=6,label="内部表示：答案信息已稳定")
    ax.plot(steps,external,color=ORANGE,lw=2.6,marker="s",ms=6,label="外部文本：可观测线索逐步出现")
    ax.axvspan(2,3,color=GREEN,alpha=0.10)
    ax.annotate("答案早已形成",xy=(2.5,0.9),xytext=(3.2,0.62),
               fontsize=10.5,color=GREEN,weight="bold",
               arrowprops=dict(arrowstyle="->",color=GREEN))
    ax.set_xlabel("推理步数 / 文本长度",fontsize=12)
    ax.set_ylabel("答案置信度（示意）",fontsize=12)
    ax.set_title("表现型思维链：外显文字可能滞后于内部答案",fontsize=13.5,weight="bold",color="#1f2a37")
    ax.set_ylim(0,1.05); ax.set_xlim(1,8.2)
    ax.grid(True,ls="--",lw=0.6,color="#d9dee3")
    ax.legend(fontsize=10,loc="lower right",frameon=True)
    ax.tick_params(labelsize=10)
    for sp in ax.spines.values(): sp.set_color("#cfd6dd")
    fig.tight_layout()
    p=os.path.join(FIG_DIR,"f15_performative.svg")
    fig.savefig(p,format="svg",bbox_inches="tight"); plt.close(fig)
    return p

# =====================================================================
# F16 混淆矩阵
# =====================================================================
def fig_confusion():
    W,H=460,420
    b=""
    b+=ctext(W/2,34,"二分类混淆矩阵",15,BLUE,"middle",True)
    # 大框
    b+=box(90,80,280,280,fill="#fff",stroke=INK,sw=1.8,rx=10)
    # 内部 2x2
    b+=box(160,150,140,140,fill="#fff",stroke=GRID,sw=1.2)
    # 四个格
    cells=[(160,150,"TP",GREEN),(230,150,"FP",RED),(160,220,"FN",ORANGE),(230,220,"TN",BLUE)]
    for x,y,t,c in cells:
        b+=box(x,y,70,70,fill="#fff",stroke=c,sw=1.4)
        b+=ctext(x+35,y+38,t,16,c,"middle",True)
    # 轴标签
    b+=ctext(300,120,"预测为正",11,SUB,"middle",True)
    b+=ctext(50,185,"真实为正",11,SUB,"middle",True)
    b+=arrow(150,120,225,148,color=GREY,sw=1.3)
    b+=arrow(85,140,150,188,color=GREY,sw=1.3)
    # 释义
    b+=ctext(230,395,"精确率 = TP/(TP+FP)   召回率 = TP/(TP+FN)",11.5,INK,"middle",True,maxw=440)
    return save("f16_confusion", doc(W,H,b))

# =====================================================================
# F17 两条实战路线
# =====================================================================
def fig_practical():
    W,H=840,360
    b=""
    b+=ctext(W/2,34,"两条可复现的实战路线",16,BLUE,"middle",True)
    # A 格式控制类
    b+=box(30,70,380,260,fill=BLUE_T,stroke=BLUE,sw=1.6,rx=12)
    b+=box(30,70,380,34,fill=BLUE,stroke=BLUE,rx=12)
    b+=ctext(220,92,"A. 格式控制类（T0 / T1）",13,"#fff","middle",True)
    b+=box(60,125,320,46,fill="#fff",stroke=INK,sw=1.1)
    b+=ctext(220,153,"含干扰的自然语言输入",12,INK,"middle",True)
    b+=arrow(220,171,220,192,BLUE,1.6)
    b+=box(60,192,320,70,fill="#fff",stroke=INK,sw=1.1)
    b+=ctext(220,214,"System Prompt 四要素",12.5,BLUE,"middle",True)
    for i,t in enumerate(["任务定位（格式化助手）","明确输入/输出格式 + 示例","强调忽略干扰；稳定输出"]):
        b+=ctext(220,232+i*15,t,10,INK,"middle")
    b+=arrow(220,262,220,282,BLUE,1.6)
    b+=box(60,282,320,38,fill=GREEN_T,stroke=GREEN)
    b+=ctext(220,306,"稳定结构化输出（JSON / 三行文本）",11.5,GREEN,"middle",True)
    # B 检索增强类
    b+=box(430,70,380,260,fill=ORANGE_T,stroke=ORANGE,sw=1.6,rx=12)
    b+=box(430,70,380,34,fill=ORANGE,stroke=ORANGE,rx=12)
    b+=ctext(620,92,"B. 检索增强类（RAG）",13,"#fff","middle",True)
    b+=box(460,125,320,44,fill="#fff",stroke=INK,sw=1.1)
    b+=ctext(620,152,"查询 → Embedding → 余弦检索",12,INK,"middle",True)
    b+=arrow(620,169,620,190,ORANGE,1.6)
    b+=box(460,190,320,44,fill="#fff",stroke=INK,sw=1.1)
    b+=ctext(620,217,"拼装参考知识 + 题目",12,INK,"middle",True)
    b+=arrow(620,234,620,255,ORANGE,1.6)
    b+=box(460,255,320,44,fill="#fff",stroke=INK,sw=1.1)
    b+=ctext(620,282,"RAG System Prompt：基于参考知识作答",11.5,INK,"middle",maxw=300)
    b+=arrow(620,299,620,320,ORANGE,1.6)
    b+=box(460,320,320,38,fill=GREEN_T,stroke=GREEN)
    b+=ctext(620,344,"答案可溯源·抗幻觉·格式可控",11.5,GREEN,"middle",True)
    return save("f17_practical", doc(W,H,b))

# =====================================================================
# F18 认证题型 T0-T3
# =====================================================================
def fig_exam():
    W,H=840,460
    b=""
    b+=ctext(W/2,34,"认证实战题型 T0–T3 概览",16,BLUE,"middle",True)
    cards=[(30,"T0 教学题","同题双解：规则 / 大模型","验证环境与双路径能力",BLUE,BLUE_T,"归一化：舱门报码 → 标准 JSON"),
           (225,"T1 简单题","Prompt 控制","格式约束 · 稳定输出",ORANGE,ORANGE_T,"口令整理：三行调度文本"),
           (420,"T2 困难题","真实工具智能体 SFT","并行调用 · 全量微调",GREEN,GREEN_T,"Qwen3-0.6B 工具调用训练"),
           (615,"T3 探索题","阅读论文 + 补全机制","代码式验证核",PURPLE,PURPLE_T,"投机采样：动态 ensemble 验证")]
    for x,t,sub,goal,c,ct,ex in cards:
        b+=box(x,70,180,300,fill=ct,stroke=c,sw=1.6,rx=12)
        b+=box(x,70,180,42,fill=c,stroke=c,rx=12)
        b+=ctext(x+90,96,t,13.5,"#fff","middle",True)
        b+=ctext(x+90,138,sub,11,c,"middle",True,maxw=170)
        b+=ctext(x+90,178,goal,10.5,INK,"middle",maxw=170)
        b+=e("line",{"x1":x+12,"y1":214,"x2":x+168,"y2":214,"stroke":GRID,"stroke-width":0.8})
        b+=ctext(x+90,250,ex,10.5,SUB,"middle",maxw=168)
    b+=box(30,388,780,52,fill="#fff",stroke=INK,sw=1.2,dash="5,4")
    b+=ctext(420,416,"评测：精确字段命中 · 严格格式检查 · 轻量代理指标 · 分项计分；公开透明，隐藏只扩分布",11,INK,"middle",True,maxw=760)
    return save("f18_exam", doc(W,H,b))

# =====================================================================
# F19 多模态：CLIP 图文双编码器与对比学习
# =====================================================================
def fig_clip():
    W,H=840,470
    b=""
    b+=ctext(W/2,34,"CLIP：图文双编码器与对比学习",16,BLUE,"middle",True)
    b+=ctext(W/2,56,"训练信号来自“图与文是否配对”（自监督对比学习）",12,SUB,"middle")
    # 图像塔
    b+=box(60,90,230,60,fill="#fff",stroke=BLUE,sw=1.6,rx=12)
    b+=ctext(175,125,"① 图像（一张照片）",12.5,INK,"middle",True)
    b+=arrow(175,150,175,196,color=BLUE,sw=1.5)
    b+=box(60,196,230,54,fill=BLUE_T,stroke=BLUE,sw=1.4,rx=10)
    b+=ctext(175,225,"图像编码器 Vision",12,INK,"middle",True)
    b+=arrow(175,250,175,296,color=BLUE,sw=1.5)
    b+=box(60,296,230,50,fill="#fff",stroke=BLUE,sw=1.4,rx=10)
    b+=ctext(175,325,"图像向量 v_img",12,INK,"middle",True)
    # 文本塔
    b+=box(550,90,230,60,fill="#fff",stroke=ORANGE,sw=1.6,rx=12)
    b+=ctext(665,125,"② 文本（描述它的句子）",12.5,INK,"middle",True)
    b+=arrow(665,150,665,196,color=ORANGE,sw=1.5)
    b+=box(550,196,230,54,fill=ORANGE_T,stroke=ORANGE,sw=1.4,rx=10)
    b+=ctext(665,225,"文本编码器 Text",12,INK,"middle",True)
    b+=arrow(665,250,665,296,color=ORANGE,sw=1.5)
    b+=box(550,296,230,50,fill="#fff",stroke=ORANGE,sw=1.4,rx=10)
    b+=ctext(665,325,"文本向量 v_txt",12,INK,"middle",True)
    # 共享语义空间
    b+=box(330,360,180,70,fill=GREEN_T,stroke=GREEN,sw=1.6,rx=12)
    b+=ctext(420,392,"共享语义空间",13,GREEN,"middle",True)
    b+=ctext(420,412,"（对齐后的图文向量）",10.5,SUB,"middle")
    # 配对→靠近（绿）
    b+=arrow(175,346,395,372,color=GREEN,sw=1.8)
    b+=arrow(665,346,445,372,color=GREEN,sw=1.8)
    b+=ctext(300,351,"配对→靠近",10.5,GREEN,"middle",True)
    b+=ctext(540,351,"配对→靠近",10.5,GREEN,"middle",True)
    # 底部说明
    b+=ctext(W/2,448,"对比学习：配对的图文向量被拉近，不配对的被推远",11.5,INK,"middle",True,maxw=W-80)
    return save("f19_clip", doc(W,H,b))

if __name__ == "__main__":
    files=[]
    files.append(fig_syllabus()); files.append(fig_lm_history())
    files.append(fig_paradigms()); files.append(fig_lifecycle())
    files.append(fig_transformer()); files.append(fig_attention())
    files.append(fig_architectures()); files.append(fig_attn_complexity())
    files.append(fig_temperature()); files.append(fig_decode_tree())
    files.append(fig_int4()); files.append(fig_rag())
    files.append(fig_cosine()); files.append(fig_agent())
    files.append(fig_performative()); files.append(fig_confusion())
    files.append(fig_practical()); files.append(fig_exam())
    files.append(fig_clip())
    print("生成完成，共 %d 个 SVG：" % len(files))
    for f in files: print(" -", os.path.basename(f))
