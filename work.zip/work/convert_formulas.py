# -*- coding: utf-8 -*-
"""Convert text-form formula <pre><code> blocks into KaTeX-rendered math blocks.
Anchors on a unique start fragment inside each block; the inner content is
matched with .*? so special/combining characters never break the match.
"""
import os, re

BASE = os.path.dirname(os.path.abspath(__file__))
CH = os.path.join(BASE, "chapters")

def block(frag, new):
    return (frag, new)

REPL = {
    "01_ch1.html": [
        block("P(x_1,",
            r'''<div class="math-block">$$ P(x_1, \ldots, x_T) = \prod_{t=1}^{T} P\!\left(x_t \mid x_1, \ldots, x_{t-1}\right) $$</div>'''),
        block("Precision = TP / (TP + FP)",
            r'''<div class="math-block">$$ \text{Precision} = \frac{TP}{TP + FP} \qquad \text{Recall} = \frac{TP}{TP + FN} $$</div>
<div class="math-block">$$ F_1 = \frac{2 \cdot \text{Precision} \cdot \text{Recall}}{\text{Precision} + \text{Recall}} \qquad \text{Accuracy} = \frac{TP + TN}{TP + TN + FP + FN} $$</div>
<p class="note">说明：精确率（Precision）看“预测为正的里面多少是真的”，召回率（Recall）看“所有真实正例中找回多少”。</p>'''),
    ],
    "02_ch2.html": [
        block("Attention(Q, K, V) = softmax",
            r'''<div class="math-block">$$ \text{Attention}(Q, K, V) = \text{softmax}\!\left( \frac{Q K^{\top}}{\sqrt{d_k}} \right) V $$</div>'''),
        block("注意力算力",
            r'''<div class="math-block">$$ \text{注意力算力} \approx O(L^2 \cdot d) $$</div>
<div class="math-block">$$ \text{前馈网络算力} \approx O(L \cdot d^2) $$</div>
<p class="note">其中 L 为序列长度，d 为隐藏维度。当 L 远大于 d 时，注意力项 O(L²·d) 占主导。</p>'''),
    ],
    "04_ch4.html": [
        block("ΔW = B · A",
            r'''<div class="math-block">$$ \Delta W = B \cdot A $$</div>
<p class="note">其中 B 的形状为 [dout, r]，A 的形状为 [r, din]，秩 r 远小于 din、dout。新增可训练参数约为 r·(din + dout)，通常远小于原层的 din·dout。</p>'''),
    ],
    "08_ch8.html": [
        block("Accuracy = (TP + TN) / (TP + TN + FP + FN)",
            r'''<div class="math-block">$$ \text{Accuracy} = \frac{TP + TN}{TP + TN + FP + FN} $$</div>'''),
        block("Precision = TP / (TP + FP)",
            r'''<div class="math-block">$$ \text{Precision} = \frac{TP}{TP + FP} $$</div>'''),
        block("Recall = TP / (TP + FN)",
            r'''<div class="math-block">$$ \text{Recall} = \frac{TP}{TP + FN} $$</div>'''),
        block("F1 = 2 · Precision · Recall / (Precision + Recall)",
            r'''<div class="math-block">$$ F_1 = \frac{2 \cdot \text{Precision} \cdot \text{Recall}}{\text{Precision} + \text{Recall}} $$</div>'''),
        block("DCG = Σ_{i=1..k} (2^rel_i - 1) / log₂(i + 1)",
            r'''<div class="math-block">$$ \text{DCG} = \sum_{i=1}^{k} \frac{2^{\text{rel}_i} - 1}{\log_2(i + 1)} $$</div>'''),
        block("NDCG = DCG / IDCG",
            r'''<div class="math-block">$$ \text{NDCG} = \frac{\text{DCG}}{\text{IDCG}} $$</div>'''),
        block("PPL = exp( - (1/N) · Σ_t log P_θ(x_t | x_{&lt;t}) )",
            r'''<div class="math-block">$$ \text{PPL} = \exp\!\left( -\frac{1}{N} \sum_{t} \log P_\theta(x_t \mid x_{<t}) \right) $$</div>'''),
        block("pass@k = 1 − C(n − c, k) / C(n, k)",
            r'''<div class="math-block">$$ \text{pass@}k = 1 - \frac{\binom{n - c}{k}}{\binom{n}{k}} $$</div>'''),
        block("κ = (p_o − p_e) / (1 − p_e)",
            r'''<div class="math-block">$$ \kappa = \frac{p_o - p_e}{1 - p_e} $$</div>'''),
    ],
    "10_ch10.html": [
        block("w_t = f_θ(h_t^q, h_t^p)",
            r'''<div class="math-block">$$ w_t = f_\theta(h_t^q, h_t^p) $$</div>'''),
        block("ν_t^θ(x) = w_t · p_t(x) + (1 - w_t) · q_t(x)",
            r'''<div class="math-block">$$ \nu_t^\theta(x) = w_t \cdot p_t(x) + (1 - w_t) \cdot q_t(x) $$</div>'''),
    ],
    "11_appendix.html": [
        block("# 缩放点积注意力",
            r'''<div class="math-block">$$ \text{Attention}(Q,K,V) = \text{softmax}\!\left( \frac{Q K^{\top}}{\sqrt{d_k}} \right) V $$</div>
<div class="math-block">$$ o_i = \sum_{j} \text{softmax}_j\!\left( \frac{q_i \cdot k_j}{\sqrt{d_k}} \right) v_j,\quad j \le i $$</div>
<div class="math-block">$$ \text{MultiHead}(Q,K,V) = \text{Concat}(\text{head}_1,\ldots,\text{head}_h)\, W^{O} $$</div>
<div class="math-block">$$ \text{head}_i = \text{Attention}(Q W_i^{Q},\, K W_i^{K},\, V W_i^{V}) $$</div>
<div class="math-block">$$ \cos(a,b) = \frac{a \cdot b}{\lVert a \rVert \cdot \lVert b \rVert} $$</div>
<div class="math-block">$$ \text{sim} = \hat{a} \cdot \hat{b},\quad \hat{a}=\frac{a}{\lVert a \rVert},\ \hat{b}=\frac{b}{\lVert b \rVert} $$</div>
<p class="note">说明：第 2 章讲注意力，第 6 章 RAG 检索用余弦相似度（先 L2 归一化再点积，等价于上式）。</p>'''),
        block("# 下一词预测的交叉熵",
            r'''<div class="math-block">$$ \mathcal{L} = - \sum_{t} \log P_\theta(x_t \mid x_{<t}) $$</div>
<div class="math-block">$$ \text{model\_bytes} \approx \text{num\_params} \times 0.5 $$</div>
<div class="math-block">$$ P(x) = \text{softmax}\!\left( \frac{\text{logits}}{\text{temperature}} \right) $$</div>
<div class="math-block">$$ w_t = f_\theta(h_t^q, h_t^p) $$</div>
<div class="math-block">$$ \nu_t^\theta(x) = w_t \cdot p_t(x) + (1 - w_t) \cdot q_t(x) $$</div>
<div class="math-block">$$ \text{accept\_prob} = \min\!\left(1,\, \frac{\nu_t^\theta(\tilde{x}_t)}{q_t(\tilde{x}_t)}\right) $$</div>
<div class="math-block">$$ P_{\nu_t^\theta}(x) \propto \big[ \nu_t^\theta(x) - q_t(x) \big]_{+} $$</div>
<p class="note">说明：交叉熵见第 3 章；INT4 量化位宽见第 5 章；温度采样见第 5 章；DIVERSED 动态 ensemble 见第 7、11 章。</p>'''),
        block("# 精确率 / 召回率",
            r'''<div class="math-block">$$ \text{Precision} = \frac{TP}{TP + FP} \qquad \text{Recall} = \frac{TP}{TP + FN} $$</div>
<div class="math-block">$$ F_1 = \frac{2 \cdot \text{Precision} \cdot \text{Recall}}{\text{Precision} + \text{Recall}} $$</div>
<div class="math-block">$$ \text{DCG}@k = \sum_{i=1}^{k} \frac{2^{\text{rel}_i} - 1}{\log_2(i + 1)} \qquad \text{NDCG}@k = \frac{\text{DCG}@k}{\text{IDCG}@k} $$</div>
<div class="math-block">$$ \text{PPL} = \exp\!\left( -\frac{1}{N} \sum_{t} \log P_\theta(x_t \mid x_{<t}) \right) $$</div>
<p class="note">说明：精确率/召回率/F1/NDCG 见第 8 章；困惑度（PPL）由第 3 章交叉熵直接导出。</p>'''),
    ],
}

for fn, items in REPL.items():
    p = os.path.join(CH, fn)
    s = open(p, encoding="utf-8").read()
    for frag, new in items:
        pat = re.compile(r'<pre><code>' + re.escape(frag) + r'.*?</code></pre>', re.S)
        s2, n = pat.subn(lambda m, _n=new: _n, s, count=1)
        if n == 0:
            print(f"[MISS] {fn}: start fragment not matched -> {frag!r}")
        else:
            print(f"[ OK ] {fn}: replaced 1 block ({frag[:30]!r})")
            s = s2
    open(p, "w", encoding="utf-8").write(s)

print("done.")
