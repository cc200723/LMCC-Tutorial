# -*- coding: utf-8 -*-
"""为 LMCC 青少年组教材-增强版 注入 12 幅代码绘制的矢量图（SVG）。
风格对齐已有图表：白底、圆角卡片、统一配色、Noto Sans CJK SC 字体。
同时补全 CCF 提纲里缺失的两节：1.4.3 大模型现状、3.1.1 预训练数据准备。
"""
import os, re, math

BASE = os.path.dirname(os.path.abspath(__file__))
HTML = os.path.join(BASE, "..", "LMCC青少年组教材-增强版.html")
FIGDIR = os.path.join(BASE, "figs")
os.makedirs(FIGDIR, exist_ok=True)

# ---- 配色（与教材 CSS 变量一致）----
BLUE   = "#2c5f8a"
ORANGE = "#c1572f"
GREEN  = "#3a7d44"
PURPLE = "#6b4e9e"
TEAL   = "#2a7d8c"
PANEL  = "#f4f7fa"
BORDER = "#cfd6dd"
INK    = "#1a1a1a"
SUB    = "#555555"
LIGHT  = "#eef3f8"
FF = "Noto Sans CJK SC,Microsoft YaHei,sans-serif"

def svg_open(w, h, bg="white"):
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w} {h}" '
            f'width="{w}" font-family="{FF}" font-size="15" fill="{INK}">'
            f'<rect x="0" y="0" width="{w}" height="{h}" fill="{bg}"/>')

def box(x, y, w, h, fill=PANEL, stroke=BORDER, rx=10,
        header=None, hfill=BLUE, hcolor="white", hsize=14):
    s = (f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{rx}" '
         f'fill="{fill}" stroke="{stroke}" stroke-width="1.5"/>')
    if header:
        s = (f'<path d="M{x},{y+rx} a{rx},{rx} 0 0 1 {rx},-{rx} h{w-2*rx} '
              f'a{rx},{rx} 0 0 1 {rx},{rx} v{30-rx} h-{w} Z" fill="{hfill}"/>'
              f'<text x="{x+w/2}" y="{y+20}" text-anchor="middle" fill="{hcolor}" '
              f'font-size="{hsize}" font-weight="600">{header}</text>' + s)
    return s

def t(x, y, text, size=15, color=INK, anchor="middle", weight=400):
    return (f'<text x="{x}" y="{y}" text-anchor="{anchor}" fill="{color}" '
            f'font-size="{size}" font-weight="{weight}">{text}</text>')

def lines(x, y, items, size=14, color=INK, lh=22, anchor="start", weight=400):
    out = ""
    for i, it in enumerate(items):
        out += t(x, y + i * lh, it, size=size, color=color, anchor=anchor, weight=weight)
    return out

def arrow(x1, y1, x2, y2, color=BLUE, head=9):
    dx, dy = x2 - x1, y2 - y1
    L = math.hypot(dx, dy) or 1
    ux, uy = dx / L, dy / L
    bx, by = x2 - ux * head, y2 - uy * head
    px, py = -uy, ux
    p1 = (bx + px * head * 0.5, by + py * head * 0.5)
    p2 = (bx - px * head * 0.5, by - py * head * 0.5)
    return (f'<line x1="{x1}" y1="{y1}" x2="{bx:.1f}" y2="{by:.1f}" '
            f'stroke="{color}" stroke-width="2.4"/>'
            f'<polygon points="{x2:.1f},{y2:.1f} {p1[0]:.1f},{p1[1]:.1f} {p2[0]:.1f},{p2[1]:.1f}" fill="{color}"/>')

# ============================================================
# 图 1-5  人工智能能完成的任务（按信息类型分）
# ============================================================
def fig_1_5():
    W, H = 840, 440
    s = svg_open(W, H)
    s += t(W/2, 28, "人工智能能完成的任务（按信息类型分）", size=16, weight=600)
    cards = [
        (20, 50, BLUE,   "计算机视觉（CV）", ["图像分类、目标检测", "人脸识别、医学影像", "自动驾驶感知"]),
        (430, 50, ORANGE, "自然语言处理（NLP）", ["机器翻译、智能问答", "文本摘要、写作助手", "情感分析与检索"]),
        (20, 250, GREEN,  "决策与控制", ["博弈与规划", "机器人控制", "智能体（Agent）"]),
        (430, 250, PURPLE, "语音技术", ["语音识别（ASR）", "语音合成（TTS）", "声纹与多模态"]),
    ]
    for (x, y, c, head, items) in cards:
        s += box(x, y, 390, 175, header=head, hfill=c)
        s += lines(x + 22, y + 58, items, size=14.5, color=INK, lh=26)
    return s

# ============================================================
# 图 1-6  规则驱动 vs 数据驱动
# ============================================================
def fig_1_6():
    W, H = 840, 360
    s = svg_open(W, H)
    s += t(W/2, 28, "人工智能的两种实现思路", size=16, weight=600)
    # 左：规则驱动
    s += box(40, 55, 360, 270, header="规则驱动（专家系统）", hfill=ORANGE)
    s += lines(62, 120, [
        "做法：人把经验写成",
        "          if … then … 规则",
        "优点：可控、可解释",
        "缺点：规则难写全，",
        "         遇到新情况易失效",
    ], size=14, lh=26)
    s += t(220, 250, "人来写规则 → 机器照做", size=13, color=SUB)
    # 右：数据驱动
    s += box(440, 55, 360, 270, header="数据驱动（机器学习）", hfill=BLUE)
    s += lines(462, 120, [
        "做法：用大量数据 +",
        "          损失函数自动学规律",
        "优点：能适应复杂、",
        "          难写规则的问题",
        "缺点：需要数据与算力",
    ], size=14, lh=26)
    s += t(620, 250, "数据 + 模型 → 自己学规律", size=13, color=SUB)
    s += arrow(400, 190, 440, 190, color=BORDER)
    s += t(420, 175, "更常用", size=12, color=SUB)
    return s

# ============================================================
# 图 1-7  神经网络基础（前馈网络）
# ============================================================
def fig_1_7():
    W, H = 840, 380
    s = svg_open(W, H)
    s += t(W/2, 28, "神经网络基础：一层层“加权求和 + 激活”", size=16, weight=600)
    # 三层节点
    layers = [
        (120, ["x₁", "x₂", "x₃"], "输入", BLUE),
        (420, ["h₁", "h₂", "h₃", "h₄"], "隐藏层", ORANGE),
        (720, ["y₁", "y₂"], "输出", GREEN),
    ]
    coords = []
    for (cx, labels, name, c) in layers:
        col = []
        n = len(labels)
        y0 = 110
        gap = 200 / max(n - 1, 1)
        for i, lab in enumerate(labels):
            cy = y0 + i * gap
            col.append((cx, cy))
            s += (f'<circle cx="{cx}" cy="{cy}" r="22" fill="{c}" '
                   f'stroke="white" stroke-width="2"/>'
                   f'<text x="{cx}" y="{cy+5}" text-anchor="middle" fill="white" '
                   f'font-size="13" font-weight="600">{lab}</text>')
        coords.append(col)
        s += t(cx, 345, name, size=13, color=SUB)
    # 连线（输入->隐藏 全连接；隐藏->输出 全连接），加少量权重标注
    for a in coords[0]:
        for b in coords[1]:
            s += (f'<line x1="{a[0]+22}" y1="{a[1]}" x2="{b[0]-22}" y2="{b[1]}" '
                   f'stroke="{BORDER}" stroke-width="1.2"/>')
    for a in coords[1]:
        for b in coords[2]:
            s += (f'<line x1="{a[0]+22}" y1="{a[1]}" x2="{b[0]-22}" y2="{b[1]}" '
                   f'stroke="{BORDER}" stroke-width="1.2"/>')
    s += t(270, 85, "权重 w", size=12, color=SUB)
    s += t(570, 85, "权重 w", size=12, color=SUB)
    s += t(W/2, 370, "每个节点：把上游信号按权重相加，再经激活函数输出", size=12.5, color=SUB)
    return s

# ============================================================
# 图 1-8  机器学习基本过程（流水线）
# ============================================================
def fig_1_8():
    W, H = 840, 320
    s = svg_open(W, H)
    s += t(W/2, 28, "机器学习基本过程：从数据到可用模型", size=16, weight=600)
    steps = [
        (30, "数据采集", "网页 / 拍照 /\n传感器", BLUE),
        (200, "预处理与标注", "清洗、去噪、\n打标签", ORANGE),
        (370, "特征提取", "把原始信息\n变成数值", PURPLE),
        (540, "模型训练", "按批次反复\n更新参数", GREEN),
        (710, "评测与部署", "验证效果\n上线使用", TEAL),
    ]
    bw = 130
    for (x, name, desc, c) in steps:
        s += box(x, 80, bw, 110, header=name, hfill=c, hsize=13)
        dy = 80 + 50
        for i, line in enumerate(desc.split("\n")):
            s += t(x + bw/2, dy + i * 20, line, size=12.5, color=INK)
    for i in range(len(steps) - 1):
        s += arrow(steps[i][0] + bw, 135, steps[i+1][0], 135, color=BLUE)
    s += t(W/2, 250, "训练不是一次完成：把数据分成很多“小批次（batch）”，每看一批就微调一次参数，反复多轮。",
            size=13, color=SUB)
    s += box(150, 270, 540, 38, fill=LIGHT, stroke=BORDER, rx=8)
    s += t(W/2, 294, "案例：植物识别 = 大量带标签的叶子照片 → 训练 → 识别新叶子的品种", size=13, color=INK, weight=600)
    return s

# ============================================================
# 图 1-9  ROC 曲线与 AUC
# ============================================================
def fig_1_9():
    W, H = 840, 470
    s = svg_open(W, H)
    s += t(W/2, 28, "ROC 曲线与 AUC：扫遍所有阈值后的整体区分力", size=16, weight=600)
    ox, oy, pw, ph = 90, 400, 660, 300
    # 轴
    s += f'<line x1="{ox}" y1="{oy}" x2="{ox+pw}" y2="{oy}" stroke="{INK}" stroke-width="1.5"/>'
    s += f'<line x1="{ox}" y1="{oy}" x2="{ox}" y2="{oy-ph}" stroke="{INK}" stroke-width="1.5"/>'
    # 随机对角线
    s += (f'<line x1="{ox}" y1="{oy}" x2="{ox+pw}" y2="{oy-ph}" '
           f'stroke="{SUB}" stroke-width="1.5" stroke-dasharray="6 5"/>')
    # AUC 填充
    curve = "M90,400 C320,398 380,150 750,108"
    s += (f'<path d="{curve} L{ox+pw},{oy} Z" fill="{BLUE}" fill-opacity="0.14"/>')
    # 曲线描边
    s += f'<path d="{curve}" fill="none" stroke="{BLUE}" stroke-width="3"/>'
    # 标注
    s += t(ox + pw/2, oy + 28, "假正率 FPR（误报比例）", size=13, color=INK)
    s += t(ox - 64, oy - ph/2, "真正率 TPR（命中比例）", size=13, color=INK, anchor="middle")
    s += f'<text x="{ox+pw}" y="{oy+28}" text-anchor="end" fill="{SUB}" font-size="12">1.0</text>'
    s += f'<text x="{ox-10}" y="{oy-ph+4}" text-anchor="end" fill="{SUB}" font-size="12">1.0</text>'
    s += t(ox + pw - 150, oy - ph + 40, "AUC ≈ 0.93（越靠左上越好）", size=13, color=BLUE, weight=600)
    s += t(W/2, 450, "每换一个判定阈值，就得到 ROC 上的一个点；曲线下面积 AUC 越大，模型整体区分能力越强。",
            size=12.5, color=SUB)
    return s

# ============================================================
# 图 1-10  k 折交叉验证
# ============================================================
def fig_1_10():
    W, H = 840, 340
    s = svg_open(W, H)
    s += t(W/2, 28, "k 折交叉验证：把数据切 k 份，轮流当测试集", size=16, weight=600)
    k = 5
    fw = 130
    gap = 14
    x0 = (W - (k * fw + (k - 1) * gap)) / 2
    y = 90
    # 数据总条
    s += box(x0 - 20, y - 38, k * fw + (k - 1) * gap + 40, 28, fill=LIGHT, stroke=BORDER, rx=6)
    s += t(W/2, y - 19, "全部训练数据", size=13, color=INK)
    folds = []
    for i in range(k):
        fx = x0 + i * (fw + gap)
        s += box(fx, y, fw, 90, fill=PANEL, stroke=BORDER, rx=8)
        s += t(fx + fw/2, y + 50, f"第 {i+1} 折", size=14, color=INK, weight=600)
        folds.append((fx, fw))
    # 5 轮说明
    ry = 210
    s += t(x0, ry - 14, "训练 / 验证划分（每轮换一个折当验证集）：", size=13, color=INK, anchor="start")
    for r in range(k):
        fx, fw = folds[r]
        s += box(fx, ry, fw, 60, fill="#fdecec", stroke=ORANGE, rx=8)
        s += t(fx + fw/2, ry + 36, "验证集", size=13, color=ORANGE, weight=600)
        # 其余折画训练标记
        for i in range(k):
            if i != r:
                ix, iw = folds[i]
                s += t(ix + iw/2, ry + 36, "训练", size=12, color=GREEN)
    s += t(W/2, ry + 92, "最后取 k 次成绩的平均，减少“一次切分太偶然”的影响。", size=12.5, color=SUB)
    return s

# ============================================================
# 图 1-11  大模型现状：国际与国内代表
# ============================================================
def fig_1_11():
    W, H = 840, 430
    s = svg_open(W, H)
    s += t(W/2, 28, "大模型现状：国际持续迭代，国内快速发展", size=16, weight=600)
    s += box(40, 55, 360, 250, header="国际主流代表", hfill=BLUE)
    s += lines(62, 118, [
        "GPT-4 / GPT-4o（OpenAI）",
        "Claude（Anthropic）",
        "Gemini（Google）",
        "Llama（Meta，开源）",
        "Mixtral、Grok 等",
    ], size=14.5, lh=30)
    s += box(440, 55, 360, 250, header="国内代表模型", hfill=ORANGE)
    s += lines(462, 118, [
        "文心一言（百度）",
        "通义千问 Qwen（阿里）",
        "智谱 GLM（清华/智谱）",
        "豆包（字节）、DeepSeek",
        "阶跃、Kimi 等",
    ], size=14.5, lh=30)
    # 底部三块
    for i, (name, c) in enumerate([("趋势：开源化、多模态、推理增强", GREEN),
                                     ("正确使用：核实信息、保护隐私", TEAL),
                                     ("关键决策仍由人把关", PURPLE)]):
        x = 40 + i * 270
        s += box(x, 325, 255, 80, fill=LIGHT, stroke=BORDER, rx=8)
        s += t(x + 127, 370, name, size=13.5, color=INK, weight=600)
    return s

# ============================================================
# 图 3-3  预训练数据准备流程（含词元化）
# ============================================================
def fig_3_3():
    W, H = 840, 360
    s = svg_open(W, H)
    s += t(W/2, 28, "预训练数据准备：从原始文本到训练样本", size=16, weight=600)
    steps = [
        (25, "多源收集", "网页 / 书籍 /\n代码 / 论文", BLUE),
        (195, "清洗去重", "去噪、去隐私、\n去除重复", ORANGE),
        (365, "词元化", "文字切成分词\n片段（token）", PURPLE),
        (535, "配比与课程", "按领域比例混、\n由易到难排", TEAL),
        (705, "进入训练", "分批喂给\n模型学规律", GREEN),
    ]
    bw = 125
    for (x, name, desc, c) in steps:
        s += box(x, 70, bw, 110, header=name, hfill=c, hsize=13)
        for i, line in enumerate(desc.split("\n")):
            s += t(x + bw/2, 122 + i * 20, line, size=12, color=INK)
    for i in range(len(steps) - 1):
        s += arrow(steps[i][0] + bw, 125, steps[i+1][0], 125, color=BLUE)
    # 词元化示例
    s += box(195, 230, 460, 100, fill=LIGHT, stroke=BORDER, rx=8)
    s += t(425, 256, "词元化示例：同一句话，不同模型切法不同", size=13, color=INK, weight=600)
    s += t(235, 288, "“人工智能很厉害”", size=13, color=INK, anchor="start")
    s += t(235, 318, "→ 字级：[人][工][智][能][很][厉][害]", size=12.5, color=PURPLE, anchor="start")
    s += t(235, 340, "→ 子词级：[人工][智能][很][厉害]（也可能更碎）", size=12.5, color=ORANGE, anchor="start")
    return s

# ============================================================
# 图 4-2  后训练流程：预训练 → SFT → 对齐
# ============================================================
def fig_4_2():
    W, H = 840, 300
    s = svg_open(W, H)
    s += t(W/2, 28, "后训练流程：让“会接话”的模型变成“能干活”的助手", size=16, weight=600)
    blocks = [
        (40, "预训练模型", "海量文本中学到\n语言与知识（基础能力）", BLUE),
        (245, "监督微调 SFT", "用“指令—回答”\n数据教它按指令做", ORANGE),
        (450, "人类对齐", "RLHF / DPO 按\n3H 校准价值观", PURPLE),
        (655, "对齐后模型", "更可靠、更有用、\n更安全的助手", GREEN),
    ]
    bw = 175
    for (x, name, desc, c) in blocks:
        s += box(x, 80, bw, 130, header=name, hfill=c, hsize=14)
        for i, line in enumerate(desc.split("\n")):
            s += t(x + bw/2, 140 + i * 22, line, size=12.5, color=INK)
    for i in range(len(blocks) - 1):
        s += arrow(blocks[i][0] + bw, 145, blocks[i+1][0], 145, color=BLUE)
    s += t(W/2, 270, "3H = 有用性（Helpful）· 诚实性（Honest）· 无害性（Harmless）", size=13, color=SUB)
    return s

# ============================================================
# 图 6-3  一条好提示的结构
# ============================================================
def fig_6_3():
    W, H = 840, 430
    s = svg_open(W, H)
    s += t(W/2, 28, "一条好提示的四种组成（以“失物招领”为例）", size=16, weight=600)
    # 大框：提示
    s += box(60, 60, 720, 300, header="完整提示 Prompt", hfill=BLUE, hsize=15)
    parts = [
        (90, 110, "① 目标", "要做什么：写一则失物招领公告", ORANGE),
        (90, 165, "② 背景", "给什么信息：捡到物品、时间地点、联系方式", TEAL),
        (90, 220, "③ 约束", "限制条件：别编造、语气礼貌、不超过 80 字", PURPLE),
        (90, 275, "④ 格式", "输出样式：先标题后正文，最后留联系电话", GREEN),
    ]
    for (x, y, name, desc, c) in parts:
        s += (f'<rect x="{x}" y="{y}" width="14" height="40" rx="4" fill="{c}"/>')
        s += t(x + 28, y + 16, name, size=14.5, color=c, anchor="start", weight=600)
        s += t(x + 28, y + 38, desc, size=13.5, color=INK, anchor="start")
    s += t(W/2, 400, "四件套越清楚，模型输出越稳定、越贴近你的需要。", size=13, color=SUB)
    return s

# ============================================================
# 图 8-2  评测指标分类树
# ============================================================
def fig_8_2():
    W, H = 840, 480
    s = svg_open(W, H)
    s += t(W/2, 28, "评测指标怎么选：先看任务类型，再挑指标", size=16, weight=600)
    # 根
    s += box(300, 48, 240, 46, fill=BLUE, stroke=BLUE, rx=8)
    s += t(420, 77, "评测指标", size=15, color="white", weight=600)
    # 两个分支 + 连接
    s += arrow(420, 94, 227, 112, color=INK)
    s += arrow(420, 94, 632, 112, color=INK)
    # 左：客观
    s += box(40, 112, 375, 44, header="客观评测（可计算）", hfill=ORANGE, hsize=14)
    obj = [("分类问题", "精确率 / 召回率 / F1"),
           ("语言建模", "困惑度 PPL"),
           ("翻译 / 摘要", "BLEU / ROUGE"),
           ("代码生成", "pass@k")]
    for i, (a, b) in enumerate(obj):
        y = 172 + i * 70
        s += box(40, y, 375, 58, fill=PANEL, stroke=BORDER, rx=8)
        s += t(60, y + 24, a, size=14, color=ORANGE, anchor="start", weight=600)
        s += t(60, y + 46, b, size=13, color=INK, anchor="start")
    # 右：主观
    s += box(435, 112, 375, 44, header="主观评测（人/模型判）", hfill=GREEN, hsize=14)
    subj = [("人工评测", "专家打分、用户反馈"),
            ("LLM-as-a-judge", "用强模型当裁判"),
            ("一致性度量", "Cohen's Kappa")]
    for i, (a, b) in enumerate(subj):
        y = 172 + i * 92
        s += box(435, y, 375, 70, fill=PANEL, stroke=BORDER, rx=8)
        s += t(455, y + 28, a, size=14, color=GREEN, anchor="start", weight=600)
        s += t(455, y + 52, b, size=13, color=INK, anchor="start")
    return s

# ============================================================
# 图 9-2  智能体标准工作流循环
# ============================================================
def fig_9_2():
    W, H = 840, 440
    s = svg_open(W, H)
    s += t(W/2, 28, "智能体标准工作流：感知—规划—行动—观察 的循环", size=16, weight=600)
    cx, cy = 420, 230
    R = 120
    steps = [("感知 Perceive", "读取任务与\n环境信息", 225),
             ("规划 Plan", "把目标拆成\n可执行的步骤", 315),
             ("行动 Act", "调用工具\n执行一步", 45),
             ("观察 Observe", "看结果，\n决定下一步", 135)]
    import math as _m
    for (name, desc, ang) in steps:
        a = _m.radians(ang)
        nx, ny = cx + R * _m.cos(a), cy + R * _m.sin(a)
        s += (f'<circle cx="{nx:.0f}" cy="{ny:.0f}" r="46" fill="{BLUE}" stroke="white" stroke-width="2"/>')
        s += t(nx, ny - 4, name, size=12.5, color="white", weight=600)
        for i, line in enumerate(desc.split("\n")):
            s += t(nx, ny + 14 + i * 16, line, size=11, color="white")
    # 循环箭头（顺时针）
    s += (f'<path d="M {cx+R}, {cy} A {R},{R} 0 1 1 {cx}, {cy+R}" fill="none" '
           f'stroke="{ORANGE}" stroke-width="2.5" stroke-dasharray="7 5"/>')
    # 中心记忆
    s += box(cx - 70, cy - 28, 140, 56, fill=LIGHT, stroke=PURPLE, rx=10)
    s += t(cx, cy - 4, "记忆模块", size=13, color=PURPLE, weight=600)
    s += t(cx, cy + 16, "记录历史与状态", size=11.5, color=SUB)
    s += t(W/2, 410, "每完成一轮，就把观察结果写回记忆，再进入下一轮，直到任务结束。", size=12.5, color=SUB)
    return s

# ============================================================
# 汇总 + 注入
# ============================================================
FIGURES = [
    dict(no="1-5", anchor='<h3>人工智能的常见应用领域</h3>', pos="after",
         caption="人工智能能完成的任务（按信息类型分）", svg=fig_1_5()),
    dict(no="1-6", anchor='<h2>1.2 人工智能系统的三种典型范式</h2>', pos="after",
         caption="规则驱动与数据驱动两种实现思路", svg=fig_1_6()),
    dict(no="1-7", anchor='<h3>神经网络与深度学习（极简版）</h3>', pos="after",
         caption="前馈神经网络：层层加权求和得到输出", svg=fig_1_7()),
    dict(no="1-8", anchor='<h3>1.3.1 机器学习的基本过程（案例：一个植物识别模型是怎样训练的）</h3>', pos="after",
         caption="机器学习基本过程：数据 → 特征 → 训练 → 评测", svg=fig_1_8()),
    dict(no="1-9", anchor='<h3>1.6.1 更多评测工具：交叉验证与 ROC/AUC</h3>', pos="after",
         caption="ROC 曲线与 AUC：整体区分能力的体检单", svg=fig_1_9()),
    dict(no="1-10", anchor='<h3>1.6.1 更多评测工具：交叉验证与 ROC/AUC</h3>', pos="after",
         caption="k 折交叉验证：轮流把一份数据当测试集", svg=fig_1_10()),
    dict(no="1-11", anchor='<h2>1.5 大模型到底在预测什么</h2>', pos="before",
         caption="大模型现状：国际持续迭代，国内快速发展",
         heading='<h3>1.4.3 大模型现状：国际主流与国内发展</h3>',
         lead='<p>大模型已经走进日常。国际上 GPT-4、Claude、Gemini、Llama 等持续迭代；国内也涌现出文心一言、通义千问、智谱 GLM、豆包、DeepSeek 等。使用时要记住三点：核实关键信息、保护个人隐私、不把关键决策完全交给模型。</p>',
         svg=fig_1_11()),
    dict(no="3-3", anchor='<h2>3.1 预训练到底在学什么</h2>', pos="after",
         caption="预训练数据准备：从网页文本到训练样本",
         heading='<h3>3.1.1 预训练数据准备：从网页文本到训练样本</h3>',
         lead='<p>预训练不是直接把原始网页喂给模型。典型流程是：多来源收集 → 清洗与去重 → 词元化 → 按配比与课程组织 → 进入训练。词元化把文字切成模型能处理的编号片段，同一句话在不同模型里切法不同。</p>',
         svg=fig_3_3()),
    dict(no="4-2", anchor='<h2>4.1 一条合格的指令数据</h2>', pos="after",
         caption="后训练流程：预训练 → 监督微调 → 人类对齐", svg=fig_4_2()),
    dict(no="6-3", anchor='<h2>6.0 什么是“提示”，为什么它这么重要</h2>', pos="after",
         caption="一条好提示的四种组成", svg=fig_6_3()),
    dict(no="8-2", anchor='<h2>8.1 评测的根本问题：用对指标，回答对问题</h2>', pos="after",
         caption="评测指标分类：先看任务类型，再挑指标", svg=fig_8_2()),
    dict(no="9-2", anchor='<h2>9.0 先搞懂：什么是“智能体”，为什么需要工具</h2>', pos="after",
         caption="智能体标准工作流：感知—规划—行动—观察", svg=fig_9_2()),
]

def build_block(item):
    inner = item["svg"] + "</svg>"
    cap = f'图 {item["no"]} {item["caption"]}'
    blk = f'\n<figure class="textbook-fig">{inner}\n<figcaption>{cap}</figcaption></figure>\n'
    if "heading" in item:
        blk = item["heading"] + "\n" + item.get("lead", "") + blk
    return blk

def main():
    html = open(HTML, encoding="utf-8").read()
    for item in FIGURES:
        a = item["anchor"]
        if a not in html:
            raise SystemExit(f"[锚点未找到] {a}")
        blk = build_block(item)
        if item["pos"] == "after":
            html = html.replace(a, a + blk, 1)
        else:
            html = html.replace(a, blk + a, 1)
        # 同时把 svg 存一份到 figs/ 便于检查
        fn = os.path.join(FIGDIR, f'fig_{item["no"].replace("-","_")}.svg')
        open(fn, "w", encoding="utf-8").write(item["svg"] + "</svg>")
    open(HTML, "w", encoding="utf-8").write(html)
    print("已注入 %d 幅图，写入 HTML。" % len(FIGURES))

if __name__ == "__main__":
    main()
