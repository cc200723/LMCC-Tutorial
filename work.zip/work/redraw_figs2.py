# -*- coding: utf-8 -*-
"""Redraw 图1-9 (ROC), fix 图2-1 black fills, relabel 图3-2, redraw 图6-2 (radian θ)."""
import re, xml.dom.minidom as M

PATH = "LMCC青少年组教材-增强版.html"
html = open(PATH, encoding="utf-8").read()

# ---------- canonical palette ----------
BLUE="#2c5f8a"; ORANGE="#c1572f"; GREEN="#3a7d44"; PURPLE="#6a4c93"
RED="#d13c3c"; INK="#1a1a1a"; MUTE="#5b6770"; PANEL="#f4f7fa"; BORDER="#cfd6dd"
FONT="Noto Sans CJK SC,Microsoft YaHei,PingFang SC,sans-serif"
WHITE="#ffffff"
GRID="#e3e8ed"
# light tints for 图2-1 boxes
TINT_BLUE="#eaf1f7"; TINT_ORANGE="#fbeee8"; TINT_GREEN="#eaf3ec"

# =====================================================================
# 图 2-1 : fix invalid _P fills -> light tints (removes black boxes)
# =====================================================================
html = html.replace("#2c5f8a_P", TINT_BLUE)\
            .replace("#c1572f_P", TINT_ORANGE)\
            .replace("#3a7d44_P", TINT_GREEN)

# =====================================================================
# 图 1-9 : ROC, clean integer coordinates
# =====================================================================
def X(f): return int(round(80 + 720*f))
def Y(t): return int(round(460 - 390*t))
# model A curve: TPR = 1 - (1-fpr)^2.5
fs = [0.0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0]
tprs = [0.0,0.2316,0.4276,0.6014,0.7211,0.8232,0.8988,0.9507,0.9821,0.9968,1.0]
pts = [(X(f),Y(t)) for f,t in zip(fs,tprs)]
d_curve = "M " + " L ".join(f"{x},{y}" for x,y in pts)

FIG_1_9 = f'''<figure class="textbook-fig">
<svg xmlns="http://www.w3.org/2000/svg" width="840" height="560" viewBox="0 0 840 560" font-family="{FONT}">
<rect x="0" y="0" width="840" height="560" fill="{WHITE}"/>
<text x="420" y="40" text-anchor="middle" font-size="18" font-weight="700" fill="{INK}">ROC 曲线：整体区分能力的体检单</text>
<text x="420" y="66" text-anchor="middle" font-size="13" fill="{MUTE}">曲线越靠近左上角，模型区分正负样本的能力越强（AUC 越大）</text>
<!-- 坐标轴 -->
<line x1="80" y1="460" x2="800" y2="460" stroke="{INK}" stroke-width="1.5"/>
<line x1="80" y1="460" x2="80" y2="70" stroke="{INK}" stroke-width="1.5"/>
<!-- 网格 -->
<line x1="440" y1="70" x2="440" y2="460" stroke="{GRID}" stroke-width="1"/>
<line x1="800" y1="70" x2="800" y2="460" stroke="{GRID}" stroke-width="1"/>
<line x1="80" y1="265" x2="800" y2="265" stroke="{GRID}" stroke-width="1"/>
<line x1="80" y1="70" x2="800" y2="70" stroke="{GRID}" stroke-width="1"/>
<!-- 刻度 -->
<text x="80" y="482" text-anchor="middle" font-size="14" fill="{INK}">0.0</text>
<text x="440" y="482" text-anchor="middle" font-size="14" fill="{INK}">0.5</text>
<text x="800" y="482" text-anchor="middle" font-size="14" fill="{INK}">1.0</text>
<text x="440" y="508" text-anchor="middle" font-size="15" fill="{INK}">假阳性率 FPR（False Positive Rate）</text>
<text x="68" y="465" text-anchor="end" font-size="14" fill="{INK}">0.0</text>
<text x="68" y="270" text-anchor="end" font-size="14" fill="{INK}">0.5</text>
<text x="68" y="75" text-anchor="end" font-size="14" fill="{INK}">1.0</text>
<text x="26" y="265" text-anchor="middle" font-size="15" fill="{INK}" transform="rotate(-90 26,265)">真阳性率 TPR（True Positive Rate）</text>
<!-- 随机分类器（对角线） -->
<line x1="80" y1="460" x2="800" y2="70" stroke="{RED}" stroke-width="2.5" stroke-dasharray="10,7"/>
<text x="250" y="400" font-size="14" font-weight="600" fill="{RED}" transform="rotate(-28 250,400)">随机分类器（AUC = 0.5）</text>
<!-- 理想分类器（左上角 L 形） -->
<path d="M 80,460 L 80,70 L 800,70" fill="none" stroke="{GREEN}" stroke-width="1.6" stroke-dasharray="6,4"/>
<text x="92" y="88" font-size="13" font-weight="600" fill="{GREEN}">理想分类器（AUC = 1.0）</text>
<!-- 模型 A 曲线 -->
<path d="{d_curve}" fill="none" stroke="{BLUE}" stroke-width="3"/>
<text x="250" y="205" font-size="14" font-weight="700" fill="{BLUE}">模型 A（AUC ≈ 0.90）</text>
<!-- 更好/更差 示意 -->
<line x1="640" y1="150" x2="470" y2="95" stroke="{INK}" stroke-width="1.8" marker-end="url(#ah9)"/>
<text x="500" y="118" font-size="13" font-weight="600" fill="{INK}">更好</text>
<line x1="690" y1="190" x2="770" y2="250" stroke="{INK}" stroke-width="1.8" marker-end="url(#ah9)"/>
<text x="740" y="240" font-size="13" font-weight="600" fill="{INK}">更差</text>
<defs>
<marker id="ah9" markerWidth="10" markerHeight="10" refX="8" refY="3" orient="auto">
<path d="M0,0 L8,3 L0,6 z" fill="{INK}"/>
</marker>
</defs>
</svg>
<figcaption>图 1-9 ROC 曲线与 AUC：整体区分能力的体检单</figcaption>
</figure>'''

# =====================================================================
# 图 3-2 : prominent FP16 / BF16 / FP32 labels, proportional bits
# =====================================================================
FIG_3_2 = f'''<figure class="textbook-fig">
<svg xmlns="http://www.w3.org/2000/svg" width="840" height="340" viewBox="0 0 840 340" font-family="{FONT}">
<rect x="0" y="0" width="840" height="340" fill="{WHITE}"/>
<text x="420" y="28" text-anchor="middle" font-size="16" font-weight="700" fill="{INK}">三种浮点精度的 bit 分配（宽度按比例，每 bit 20px）</text>
<!-- FP32 行 -->
<text x="24" y="100" font-size="16" font-weight="800" fill="{BLUE}">FP32</text>
<text x="24" y="118" font-size="11" fill="{MUTE}">32 位 · 全精度</text>
<rect x="150" y="64" width="20" height="54" fill="{RED}"/>
<text x="160" y="96" text-anchor="middle" font-size="11" fill="{WHITE}">S</text>
<rect x="170" y="64" width="160" height="54" fill="{BLUE}"/>
<text x="250" y="96" text-anchor="middle" font-size="12" fill="{WHITE}">指数 8 bit</text>
<rect x="330" y="64" width="460" height="54" fill="{GREEN}"/>
<text x="560" y="96" text-anchor="middle" font-size="12" fill="{WHITE}">尾数 23 bit</text>
<!-- FP16 行 -->
<text x="24" y="180" font-size="16" font-weight="800" fill="{ORANGE}">FP16</text>
<text x="24" y="198" font-size="11" fill="{MUTE}">16 位</text>
<rect x="150" y="144" width="20" height="54" fill="{RED}"/>
<text x="160" y="176" text-anchor="middle" font-size="11" fill="{WHITE}">S</text>
<rect x="170" y="144" width="100" height="54" fill="{BLUE}"/>
<text x="220" y="176" text-anchor="middle" font-size="12" fill="{WHITE}">指数 5 bit</text>
<rect x="270" y="144" width="200" height="54" fill="{GREEN}"/>
<text x="370" y="176" text-anchor="middle" font-size="12" fill="{WHITE}">尾数 10 bit</text>
<text x="500" y="176" font-size="12" fill="{RED}">范围窄（最大 65504），训练易溢出</text>
<!-- BF16 行 -->
<text x="24" y="260" font-size="16" font-weight="800" fill="{GREEN}">BF16</text>
<text x="24" y="278" font-size="11" fill="{MUTE}">16 位</text>
<rect x="150" y="224" width="20" height="54" fill="{RED}"/>
<text x="160" y="256" text-anchor="middle" font-size="11" fill="{WHITE}">S</text>
<rect x="170" y="224" width="160" height="54" fill="{BLUE}"/>
<text x="250" y="256" text-anchor="middle" font-size="12" fill="{WHITE}">指数 8 bit</text>
<rect x="330" y="224" width="140" height="54" fill="{GREEN}"/>
<text x="400" y="256" text-anchor="middle" font-size="12" fill="{WHITE}">尾数 7 bit</text>
<text x="500" y="256" font-size="12" fill="{GREEN}">范围同 FP32，训练更稳定</text>
<!-- 要点 -->
<text x="24" y="318" font-size="12.5" fill="{INK}">要点：FP16 与 BF16 都是 16 位，但 BF16 把 8 位分给指数（与 FP32 相同），故范围大、训练稳定，尾数精度较低。</text>
</svg>
<figcaption>图 3-2 三种浮点精度的 bit 分配：FP16、BF16、FP32 的指数位与尾数位拆分（宽度按每 bit 20px）</figcaption>
</figure>'''

# =====================================================================
# 图 6-2 : clean vectors, clearly marked angle θ in radians
# =====================================================================
# O=(70,290); q along +x; d at 52° (≈0.91 rad); radius 50 arc sampled
arc_pts = [(120,290),(119.5,283),(118,276),(115.7,270),(112.4,264),(108.3,258),(100.8,251)]
d_arc = "M " + " L ".join(f"{x},{y}" for x,y in arc_pts)
FIG_6_2 = f'''<figure class="textbook-fig">
<svg xmlns="http://www.w3.org/2000/svg" width="360" height="360" viewBox="0 0 360 360" font-family="{FONT}">
<rect x="0" y="0" width="360" height="360" fill="{WHITE}"/>
<defs>
<marker id="ahq" markerWidth="10" markerHeight="10" refX="7" refY="3" orient="auto">
<path d="M0,0 L7,3 L0,6 z" fill="{BLUE}"/>
</marker>
<marker id="ahd" markerWidth="10" markerHeight="10" refX="7" refY="3" orient="auto">
<path d="M0,0 L7,3 L0,6 z" fill="{ORANGE}"/>
</marker>
</defs>
<!-- 向量 q -->
<line x1="70" y1="290" x2="245" y2="290" stroke="{BLUE}" stroke-width="2.6" marker-end="url(#ahq)"/>
<text x="250" y="296" font-size="14" font-weight="700" fill="{BLUE}">q̂</text>
<!-- 向量 d -->
<line x1="70" y1="290" x2="178" y2="152" stroke="{ORANGE}" stroke-width="2.6" marker-end="url(#ahd)"/>
<text x="184" y="150" font-size="14" font-weight="700" fill="{ORANGE}">d̂</text>
<!-- 夹角 θ 的弧 -->
<path d="{d_arc}" fill="none" stroke="{PURPLE}" stroke-width="2.2"/>
<!-- 原点 -->
<circle cx="70" cy="290" r="4" fill="{INK}"/>
<!-- θ 标注（弧度） -->
<text x="132" y="258" font-size="17" font-weight="800" fill="{PURPLE}">θ</text>
<text x="140" y="277" font-size="11" fill="{MUTE}">≈ 0.91 rad</text>
<!-- 公式 -->
<text x="24" y="322" font-size="13" fill="{INK}">sim = cos θ = q̂ · d̂　（‖q̂‖ = ‖d̂‖ = 1）</text>
<text x="24" y="344" font-size="11" fill="{MUTE}">θ 以弧度（rad）度量：1 rad ≈ 57.3°，本图 θ ≈ 0.91 rad，cos θ ≈ 0.62</text>
</svg>
<figcaption>图 6-2 余弦相似度：先 L2 归一化得到单位向量，夹角 θ 的余弦即相似度（θ 用弧度标记）</figcaption>
</figure>'''

# ---------- replacement helper (anchor on the figcaption, not a bare prefix) ----------
def swap_prefix(html, prefix, new):
    pat = re.compile(r"<figure[^>]*>.*?<figcaption>" + re.escape(prefix) + r".*?</figure>", re.S)
    m = pat.search(html)
    if not m:
        raise SystemExit("NOT FOUND: " + prefix)
    return html[:m.start()] + new + html[m.end():]

html = swap_prefix(html, "图 1-9 ", FIG_1_9)
html = swap_prefix(html, "图 3-2 ", FIG_3_2)
html = swap_prefix(html, "图 6-2 ", FIG_6_2)

open(PATH, "w", encoding="utf-8").write(html)

# ---------- self validation ----------
def _try(s):
    try: M.parseString(s.encode("utf-8")); return True
    except Exception: return False
svgs = re.findall(r"<svg\b", html); svge = re.findall(r"</svg>", html)
figs = re.findall(r"<figure\b", html); fige = re.findall(r"</figure>", html)
bad = sum(1 for m in re.finditer(r"<svg.*?</svg>", html, re.S) if not _try(m.group(0)))
print("svg", len(svgs), len(svge), "| figure", len(figs), len(fige), "| xml_fail", bad)
print("leftover _P fills (figures):", html.count("_P"))  # 1 expected = python const in code block
for cap in ["图 1-9 ROC", "图 2-1", "图 3-2 三种浮点", "图 6-2 余弦相似度"]:
    print(f"  present x{html.count(cap)}: {cap}")
# confirm old artifacts gone / new content present
f19 = next(f for f in re.findall(r"<figure[^>]*>.*?</figure>", html, re.S) if "图 1-9" in f)
f62 = next(f for f in re.findall(r"<figure[^>]*>.*?</figure>", html, re.S) if "图 6-2" in f)
old_floats = re.findall(r"\d+\.\d{4,}", f19)
print("图1-9 old float artifacts:", len(old_floats), old_floats[:3])
print("图6-2 has '0.91 rad':", "0.91 rad" in f62, "| has '弧度':", "弧度" in f62, "| has dark navy #1f2a37:", "#1f2a37" in f62)
print("图2-1 has invalid _P fills:", html.count("#2c5f8a_P")+html.count("#c1572f_P")+html.count("#3a7d44_P"))
