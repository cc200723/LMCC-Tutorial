# -*- coding: utf-8 -*-
"""
T1 考生提交文件

你只需要修改两个函数：
1) build_system_prompt
2) build_generation_parameters

当前文件只提供占位骨架，默认实现不会通过评测。
"""


def build_system_prompt() -> str:
    """
    返回系统提示词。

    要求模型输出：
    任务：...
    执行时间：YYYY-MM-DD HH:MM
    泊位：...
    """
    return """这是未完成模板。
submission.py 目前没有实现题目要求。
无论输入是什么，你都只能输出单个词：TODO"""


def build_generation_parameters() -> dict:
    """
    返回生成参数。
    注意：评测会强制 do_sample=False。
    """
    return {
        "max_new_tokens": 8,
        "enable_thinking": False,
    }
