# -*- coding: utf-8 -*-
"""
T1 评测脚本：星港口令整理员

评分口径（总分 30）：
1) 可见集 20 分：字段 16 + 格式 4
2) 隐藏集 10 分：字段 8 + 格式 2
"""

from __future__ import annotations

import warnings

warnings.filterwarnings(
    "ignore",
    message=r"Warning: The /usr/local/Ascend/ascend-toolkit/.* owner does not match the current owner\.",
    category=UserWarning,
)

from datetime import datetime
import json
import os
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Tuple

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

import submission

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from result_store import update_results

VISIBLE_DATA_PATH = ROOT / "data" / "T1_visible_test_data.jsonl"
HIDDEN_DATA_PATH = ROOT / "data" / "T1_visible_test_data.final.jsonl"


def resolve_qwen_model_path(env_var: str, model_name: str) -> str:
    explicit = os.environ.get(env_var, "").strip()
    if explicit:
        return explicit
    qwen_root = os.environ.get("QWEN_ROOT", "").strip()
    roots = [Path(qwen_root).expanduser()] if qwen_root else []
    roots.extend([ROOT.parent.parent / "Qwen", ROOT.parent / "Qwen", ROOT / "Qwen"])
    for root in roots:
        candidate = root / model_name
        if candidate.exists():
            return str(candidate)
    return model_name


DEFAULT_MODEL_PATH = resolve_qwen_model_path("MODEL_PATH", "Qwen3-8B")

VISIBLE_FIELDS_FULL = 16.0
VISIBLE_FORMAT_FULL = 4.0
HIDDEN_FIELDS_FULL = 8.0
HIDDEN_FORMAT_FULL = 2.0
TOTAL_FULL = VISIBLE_FIELDS_FULL + VISIBLE_FORMAT_FULL + HIDDEN_FIELDS_FULL + HIDDEN_FORMAT_FULL


def pick_device() -> str:
    # 评测环境可能是 CUDA、昇腾 NPU 或纯 CPU，优先选择可用加速设备。
    if torch.cuda.is_available():
        return "cuda"
    if hasattr(torch, "npu"):
        try:
            if torch.npu.is_available():
                return "npu"
        except Exception:
            pass
    return "cpu"


def load_jsonl(path: Path) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    if not path.exists():
        return rows
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def empty_split_stat() -> Dict[str, int]:
    return {
        "field_correct": 0,
        "total_fields": 0,
        "format_correct": 0,
        "total_cases": 0,
    }


def clean_model_text(text: str) -> str:
    # Qwen 系列模型可能输出 thinking 标记或 chat template 特殊标记。
    # 这些标记不属于考生答案，解析三行字段前先统一清理。
    text = re.sub(r"<think>.*?</think>", "", text, flags=re.DOTALL | re.IGNORECASE)
    text = re.sub(r"<\|[^>]*think[^>]*\|>", "", text, flags=re.IGNORECASE)
    text = text.replace("<|im_start|>", "").replace("<|im_end|>", "")
    text = text.replace("<think>", "").replace("</think>", "")
    return text.strip()


def extract_fields(text: str) -> Tuple[str, str, str, bool]:
    """
    抽取并校验三行：任务/执行时间/泊位。
    """
    lines = [x.strip() for x in text.splitlines() if x.strip()]
    # 格式分要求比字段分更严格：必须恰好三行、前缀正确、时间可被真实解析。
    # 字段分则在后续逐字段精确匹配，即使格式不满分也仍可能拿到部分字段分。
    format_ok = (
        len(lines) == 3
        and lines[0].startswith("任务：")
        and lines[1].startswith("执行时间：")
        and lines[2].startswith("泊位：")
    )

    task = ""
    time_s = ""
    berth = ""
    if len(lines) >= 1 and lines[0].startswith("任务："):
        task = lines[0][len("任务：") :].strip()
    if len(lines) >= 2 and lines[1].startswith("执行时间："):
        time_s = lines[1][len("执行时间：") :].strip()
    if len(lines) >= 3 and lines[2].startswith("泊位："):
        berth = lines[2][len("泊位：") :].strip()

    time_pattern_ok = re.fullmatch(r"\d{4}-\d{2}-\d{2} \d{2}:\d{2}", time_s) is not None
    time_value_ok = False
    if time_pattern_ok:
        try:
            datetime.strptime(time_s, "%Y-%m-%d %H:%M")
            time_value_ok = True
        except ValueError:
            time_value_ok = False

    format_ok = format_ok and time_pattern_ok and time_value_ok
    return task, time_s, berth, format_ok


def load_model_and_tokenizer(model_path: str) -> tuple[AutoModelForCausalLM, AutoTokenizer]:
    tokenizer = AutoTokenizer.from_pretrained(model_path, trust_remote_code=True)
    model = AutoModelForCausalLM.from_pretrained(
        model_path,
        torch_dtype=torch.float16,
        trust_remote_code=True,
    )
    model = model.to(pick_device())
    model.eval()
    return model, tokenizer


def get_generation_parameters() -> Dict[str, Any]:
    # 先给出保守默认值，再允许考生在 submission.py 中覆盖。
    # 评测阶段仍会在 run_single 中强制 do_sample=False，保证结果可复现。
    params: Dict[str, Any] = {
        "max_new_tokens": 128,
        "enable_thinking": False,
    }
    user_params = submission.build_generation_parameters()
    if isinstance(user_params, dict):
        params.update(user_params)
    return params


def run_single(
    model: AutoModelForCausalLM,
    tokenizer: AutoTokenizer,
    system_prompt: str,
    query: str,
    generation_params: Dict[str, Any],
) -> str:
    enable_thinking = bool(generation_params.get("enable_thinking", False))
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": query},
    ]
    rendered = tokenizer.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True,
        enable_thinking=enable_thinking,
    )

    inputs = tokenizer(rendered, return_tensors="pt").to(model.device)

    gen_kwargs = dict(generation_params)
    gen_kwargs.pop("enable_thinking", None)
    # 统一使用贪心解码，避免同一份 prompt 因随机采样产生不同分数。
    gen_kwargs["do_sample"] = False
    gen_kwargs.setdefault("max_new_tokens", 128)
    gen_kwargs["pad_token_id"] = tokenizer.pad_token_id
    gen_kwargs["eos_token_id"] = tokenizer.eos_token_id

    # do_sample=False 时移除采样参数，避免警告影响可读性。
    gen_kwargs.pop("temperature", None)
    gen_kwargs.pop("top_p", None)
    gen_kwargs.pop("top_k", None)

    with torch.no_grad():
        outputs = model.generate(**inputs, **gen_kwargs)

    text = tokenizer.decode(outputs[0][inputs["input_ids"].shape[1] :], skip_special_tokens=False)
    return clean_model_text(text)


def eval_split(
    split_name: str,
    data: List[Dict[str, Any]],
    model: AutoModelForCausalLM,
    tokenizer: AutoTokenizer,
    system_prompt: str,
    generation_params: Dict[str, Any],
) -> Dict[str, Any]:
    field_correct = 0
    format_correct = 0

    for i, item in enumerate(data, start=1):
        out = run_single(model, tokenizer, system_prompt, item["text"], generation_params)
        task, tm, berth, fmt_ok = extract_fields(out)

        # 三个字段均采用严格字符串匹配，避免把题目变成主观语义评分。
        hit_task = task == item["expected_task"]
        hit_time = tm == item["expected_time"]
        hit_berth = berth == item["expected_berth"]

        field_correct += int(hit_task) + int(hit_time) + int(hit_berth)
        format_correct += int(fmt_ok)

        print(f"\n[{split_name} {i}/{len(data)}] {item['id']}")
        print(f"输出:\n{out}")
        print(
            f"命中: 任务={hit_task} 时间={hit_time} 泊位={hit_berth} 格式={fmt_ok}"
        )

    return {
        "field_correct": field_correct,
        "total_fields": len(data) * 3,
        "format_correct": format_correct,
        "total_cases": len(data),
    }


def main() -> None:
    visible_data = load_jsonl(VISIBLE_DATA_PATH)
    hidden_data = load_jsonl(HIDDEN_DATA_PATH)
    # 考生包里的 hidden 文件可以为空；出题方在正式评测时会覆盖为真实隐藏数据。
    hidden_missing = len(hidden_data) == 0

    system_prompt = submission.build_system_prompt()
    generation_params = get_generation_parameters()

    print("=" * 64)
    print("T1 评测开始：星港口令整理员")
    print("=" * 64)
    print(f"模型路径: {DEFAULT_MODEL_PATH}")

    model, tokenizer = load_model_and_tokenizer(DEFAULT_MODEL_PATH)

    visible_stat = eval_split(
        "VISIBLE",
        visible_data,
        model,
        tokenizer,
        system_prompt,
        generation_params,
    )
    if hidden_missing:
        print("\n⚠️ 隐藏数据未给出，当前仅进行可见数据自测。")
        hidden_stat = empty_split_stat()
    else:
        hidden_stat = eval_split(
            "HIDDEN",
            hidden_data,
            model,
            tokenizer,
            system_prompt,
            generation_params,
        )

    # 字段分按命中的字段数线性折算，格式分按格式完全正确的样例数线性折算。
    score_visible_fields = VISIBLE_FIELDS_FULL * visible_stat["field_correct"] / max(1, visible_stat["total_fields"])
    score_visible_format = VISIBLE_FORMAT_FULL * visible_stat["format_correct"] / max(1, visible_stat["total_cases"])

    if hidden_missing:
        score_hidden_fields = 0.0
        score_hidden_format = 0.0
    else:
        score_hidden_fields = HIDDEN_FIELDS_FULL * hidden_stat["field_correct"] / max(1, hidden_stat["total_fields"])
        score_hidden_format = HIDDEN_FORMAT_FULL * hidden_stat["format_correct"] / max(1, hidden_stat["total_cases"])

    total_score = score_visible_fields + score_visible_format + score_hidden_fields + score_hidden_format

    print("\n" + "-" * 64)
    print(
        f"可见字段: {visible_stat['field_correct']}/{visible_stat['total_fields']} "
        f"-> {score_visible_fields:.2f}/{VISIBLE_FIELDS_FULL:g}"
    )
    print(
        f"可见格式: {visible_stat['format_correct']}/{visible_stat['total_cases']} "
        f"-> {score_visible_format:.2f}/{VISIBLE_FORMAT_FULL:g}"
    )
    if hidden_missing:
        print(f"隐藏字段: 未提供 -> {score_hidden_fields:.2f}/{HIDDEN_FIELDS_FULL:g}")
        print(f"隐藏格式: 未提供 -> {score_hidden_format:.2f}/{HIDDEN_FORMAT_FULL:g}")
        visible_full = VISIBLE_FIELDS_FULL + VISIBLE_FORMAT_FULL
        print(f"当前公开自测分: {total_score:.2f}/{visible_full:g}")
        print(f"最终满分仍为: {TOTAL_FULL:g}")
    else:
        print(
            f"隐藏字段: {hidden_stat['field_correct']}/{hidden_stat['total_fields']} "
            f"-> {score_hidden_fields:.2f}/{HIDDEN_FIELDS_FULL:g}"
        )
        print(
            f"隐藏格式: {hidden_stat['format_correct']}/{hidden_stat['total_cases']} "
            f"-> {score_hidden_format:.2f}/{HIDDEN_FORMAT_FULL:g}"
        )
        print(f"总分: {total_score:.2f}/{TOTAL_FULL:g}")

    result_path = update_results(
        ROOT,
        "T1",
        total_score,
        TOTAL_FULL,
        detail={
            "hidden_provided": not hidden_missing,
            "visible": {
                **visible_stat,
                "score_fields": round(score_visible_fields, 2),
                "score_format": round(score_visible_format, 2),
            },
            "hidden": {
                **hidden_stat,
                "score_fields": round(score_hidden_fields, 2),
                "score_format": round(score_hidden_format, 2),
            },
        },
    )
    print(f"结果已更新: {result_path}")


if __name__ == "__main__":
    main()
