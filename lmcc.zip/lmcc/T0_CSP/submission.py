# -*- coding: utf-8 -*-
"""
T0（CSP）考生实现文件

你只需要实现一个函数：
- normalize_gate_report_csp

当前文件只提供占位骨架，默认实现不会通过评测。
"""

from __future__ import annotations

import json


def normalize_gate_report_csp(text: str) -> str:
    """
    输入：自然语言舱门报码
    输出：一行 JSON 字符串，例如：
    {"gate_id":"E-07","status":"fault"}
    """
    # ======== 考生实现区域（可修改） ========
    _ = str(text).strip()
    placeholder = {
        "todo": "implement normalize_gate_report_csp",
    }
    return json.dumps(placeholder, ensure_ascii=False, separators=(",", ":"))
    # ======== 考生实现区域（可修改） ========
