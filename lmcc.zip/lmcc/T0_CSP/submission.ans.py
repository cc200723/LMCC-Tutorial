# -*- coding: utf-8 -*-
"""
T0（CSP）考生实现文件

你只需要实现一个函数：
- normalize_gate_report_csp

当前文件是赛后参考答案实现，用于对照考生实现区域中的关键逻辑。
"""

from __future__ import annotations

import json


def normalize_gate_report_csp(text: str) -> str:
    """
    输入：自然语言舱门报码
    输出：一行 JSON 字符串，例如：
    {"gate_id":"E-07","status":"fault"}
    """
    # ======== 考生实现区域（可修改） ========
    import re

    text = str(text).strip()

    # 第 1 步：准备区域映射、状态关键词和中文数字表
    zone_rules = [
        ("E", ["东环", "东区", "东侧"]),
        ("W", ["西环", "西区", "西侧"]),
        ("N", ["北环", "北区", "北侧"]),
        ("S", ["南环", "南区", "南侧"]),
        ("I", ["主环", "内环", "内侧"]),
        ("O", ["外环", "外侧"]),
    ]
    fault_keys = ["故障", "打不开", "拉不开", "失灵", "卡住", "异常", "坏了"]
    closed_keys = ["关闭", "封闭", "锁住", "关着", "暂停通行"]
    open_keys = ["开启", "打开", "恢复通行", "放行", "通了", "重新打开"]
    cn_num = {
        "零": 0,
        "一": 1,
        "二": 2,
        "三": 3,
        "四": 4,
        "五": 5,
        "六": 6,
        "七": 7,
        "八": 8,
        "九": 9,
    }

    # 第 2 步：根据区域关键词确定 gate_id 的字母前缀
    def contains_any(source: str, keywords: list[str]) -> bool:
        return any(k in source for k in keywords)

    zone_code = None
    for code, keywords in zone_rules:
        if contains_any(text, keywords):
            zone_code = code
            break
    if zone_code is None:
        raise ValueError(f"未识别的区域关键词：{text!r}")

    # 第 3 步：提取“几号门”，并把数字统一转成两位编号
    match = re.search(
        r"([0-9]{1,2}|十[一二]?|[一二三四五六七八九])号门",
        text,
    )
    if not match:
        raise ValueError(f"未识别的门号：{text!r}")
    token = match.group(1)
    if token.isdigit():
        gate_number = int(token)
    elif token == "十":
        gate_number = 10
    elif "十" in token:
        left, right = token.split("十", 1)
        tens = 1 if left == "" else cn_num[left]
        ones = 0 if right == "" else cn_num[right]
        gate_number = tens * 10 + ones
    else:
        gate_number = cn_num[token]

    # 第 4 步：按 fault > closed > open 的优先级判定状态
    if contains_any(text, fault_keys):
        status = "fault"
    elif contains_any(text, closed_keys):
        status = "closed"
    elif contains_any(text, open_keys):
        status = "open"
    else:
        status = "open"

    # 第 5 步：组装标准输出，保证键名、顺序和格式都稳定
    result = {
        "gate_id": f"{zone_code}-{gate_number:02d}",
        "status": status,
    }
    return json.dumps(result, ensure_ascii=False, separators=(",", ":"))
    # ======== 考生实现区域（可修改） ========
