# -*- coding: utf-8 -*-
"""
T0-CSP 评测脚本：手动编程路线（舱门报码归一化）

评分（总分 10）：
- 在可见集 + 隐藏集上联合统计字段准确率
"""

from __future__ import annotations

import warnings

warnings.filterwarnings(
    "ignore",
    message=r"Warning: The /usr/local/Ascend/ascend-toolkit/.* owner does not match the current owner\.",
    category=UserWarning,
)

import json
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Tuple

from submission import normalize_gate_report_csp

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from result_store import update_results

VISIBLE_DATA_PATH = ROOT / "data" / "T0_test_data.jsonl"
HIDDEN_DATA_PATH = ROOT / "data" / "T0_test_data.final.jsonl"
FULL_SCORE = 10.0
ALLOWED_STATUS = {"open", "closed", "fault"}

# gate_id 的结构由题面固定为区域字母 + 两位编号。编号范围也在这里校验，
# 这样即使考生输出了形如 E-99 的 JSON，也不会被认为是合法格式。
GATE_PATTERN = re.compile(r"^(E|W|N|S|I|O)-(\d{2})$")


def load_jsonl(path: Path) -> List[Dict[str, Any]]:
    """读取公开集或隐藏集；隐藏集缺失时返回空列表，便于本地自测。"""
    rows: List[Dict[str, Any]] = []
    if not path.exists():
        return rows
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def gate_id_valid(gate_id: str) -> bool:
    """校验 gate_id 是否满足 X-YY 格式，且 YY 位于题目规定的 01-12。"""
    match = GATE_PATTERN.fullmatch(str(gate_id))
    if not match:
        return False
    return 1 <= int(match.group(2)) <= 12


def parse_prediction(pred: Any) -> Tuple[Dict[str, Any] | None, bool]:
    """兼容考生返回 dict 或 JSON 字符串，并单独返回格式是否合法。"""
    if isinstance(pred, dict):
        obj = pred
    elif isinstance(pred, str):
        try:
            obj = json.loads(pred)
        except Exception:
            return None, False
    else:
        return None, False

    if not isinstance(obj, dict):
        return None, False

    # 题目要求输出只能包含 gate_id/status 两个键。这里保留 obj，
    # 是为了后续仍能统计字段命中情况，方便定位是格式错还是字段值错。
    if set(obj.keys()) != {"gate_id", "status"}:
        return obj, False

    fmt_ok = gate_id_valid(obj.get("gate_id", "")) and obj.get("status") in ALLOWED_STATUS
    return obj, fmt_ok


def eval_split(split_name: str, data: List[Dict[str, Any]]) -> Dict[str, Any]:
    """评测一个 split，并返回字段命中数与格式命中数。"""
    field_correct = 0
    format_correct = 0

    for i, item in enumerate(data, start=1):
        raw_pred = normalize_gate_report_csp(item["text"])
        pred, fmt_ok = parse_prediction(raw_pred)

        # CSP 子题只按字段级准确率给分：每条样例有 gate_id/status 两个字段。
        # format_correct 不参与最终得分，但会打印并写入 detail，便于赛后诊断。
        hit_gate = bool(pred and pred.get("gate_id") == item["expected_gate_id"])
        hit_status = bool(pred and pred.get("status") == item["expected_status"])

        field_correct += int(hit_gate) + int(hit_status)
        format_correct += int(fmt_ok)

        print(f"[{split_name} {i}/{len(data)}] {item['id']}")
        print(f"  输入: {item['text']}")
        print(f"  输出: {raw_pred}")
        print(f"  命中: gate_id={hit_gate} status={hit_status} format={fmt_ok}")

    return {
        "field_correct": field_correct,
        "total_fields": len(data) * 2,
        "format_correct": format_correct,
        "total_cases": len(data),
    }


def main() -> None:
    visible_data = load_jsonl(VISIBLE_DATA_PATH)
    hidden_data = load_jsonl(HIDDEN_DATA_PATH)
    hidden_missing = len(hidden_data) == 0

    print("=" * 64)
    print("T0-CSP 评测开始（星港舱门报码归一化）")
    print("=" * 64)

    visible_stat = eval_split("VISIBLE", visible_data)
    if hidden_missing:
        # 允许考生在没有 final data 的环境中做公开自测。正式评测时隐藏集存在，
        # 可见集与隐藏集会被合并统计同一个字段准确率。
        print("\n⚠️ 隐藏数据未给出，当前仅进行公开部分自测。")
        hidden_stat = {
            "field_correct": 0,
            "total_fields": 0,
            "format_correct": 0,
            "total_cases": 0,
        }
    else:
        hidden_stat = eval_split("HIDDEN", hidden_data)

    field_correct = visible_stat["field_correct"] + hidden_stat["field_correct"]
    total_fields = visible_stat["total_fields"] + hidden_stat["total_fields"]
    format_correct = visible_stat["format_correct"] + hidden_stat["format_correct"]
    total_cases = visible_stat["total_cases"] + hidden_stat["total_cases"]

    # T0-CSP 的 10 分全部来自字段级准确率；每条数据贡献两个字段。
    score = FULL_SCORE * field_correct / max(1, total_fields)

    print("\n" + "-" * 64)
    print(f"可见字段: {visible_stat['field_correct']}/{visible_stat['total_fields']}")
    print(f"隐藏字段: {hidden_stat['field_correct']}/{hidden_stat['total_fields']}")
    print(f"总字段命中: {field_correct}/{total_fields}")
    print(f"总格式命中: {format_correct}/{total_cases}")
    print(f"得分: {score:.2f}/{FULL_SCORE:g}")
    if hidden_missing:
        print("说明: 当前分数仅基于公开自测数据折算。")

    # update_results 会同时更新根目录 results.json、用户目录结果和 Markdown 报告。
    result_path = update_results(
        ROOT,
        "T0_CSP",
        score,
        FULL_SCORE,
        detail={
            "hidden_provided": not hidden_missing,
            "visible": visible_stat,
            "hidden": hidden_stat,
            "field_correct": field_correct,
            "total_fields": total_fields,
            "format_correct": format_correct,
            "total_cases": total_cases,
        },
    )
    print(f"结果已更新: {result_path}")


if __name__ == "__main__":
    main()
