# -*- coding: utf-8 -*-
"""
T3 考生实现文件：纯 Python 动态验证核

这份模板不要求你复现完整的双模型推理系统，而是要求你补全
论文验证阶段最核心的一小段逻辑：

1. 用一个训练好的 verifier head 预测动态权重 `w_t`
2. 用 `w_t` 形成动态 ensemble 分布 `ν_t^θ`
3. 用 relaxed accept rule 判断是否接受 draft token
4. 若拒绝，则走 fallback distribution
5. 把上述单步验证按时间步串起来

特别注意：
- 论文原文在 rejection 后会从 fallback distribution 中随机采样
- 本题为了保证评测完全确定，不做随机采样
- 你必须先算出 `residual_distribution`，再固定取 `_argmax_index(residual_probs)`

为了把工作量控制在“验证核”本身，模板已经提供了这些基础函数：

- `normalize_probs`
- `acceptance_probability`
- `residual_distribution`
- `_dense_forward`

你真正需要完成的只有 4 个函数：

- `dynamic_ensemble_weight`
- `ensemble_distribution`
- `verify_single_step`
- `run_dynamic_verification`
"""

from __future__ import annotations

import math
from typing import Any, Dict, List


EPS = 1e-12


def _sigmoid(x: float) -> float:
    if x >= 0:
        z = math.exp(-x)
        return 1.0 / (1.0 + z)
    z = math.exp(x)
    return z / (1.0 + z)


def _relu(x: float) -> float:
    return x if x > 0.0 else 0.0


def _argmax_index(values: List[float]) -> int:
    return int(max(range(len(values)), key=lambda i: values[i]))


def normalize_probs(probs: List[float]) -> List[float]:
    """
    概率归一化。

    规则：
    1) 负数按 0 处理
    2) 归一化后总和为 1
    3) 若全为 0，则返回均匀分布
    """
    cleaned = [max(0.0, float(x)) for x in probs]
    total = sum(cleaned)
    if total <= EPS:
        n = max(1, len(cleaned))
        return [1.0 / n] * n
    return [x / total for x in cleaned]


def _dense_forward(x: List[float], weight: List[List[float]], bias: List[float]) -> List[float]:
    """
    简单的全连接层前向：
    `y = x @ W + b`

    这里约定：
    - `weight[i][j]` 表示输入维度 `i` 到输出维度 `j` 的参数
    - `bias[j]` 表示输出维度 `j` 的偏置
    """
    out = [float(v) for v in bias]
    for i, xi in enumerate(x):
        row = weight[i]
        for j, wij in enumerate(row):
            out[j] += float(xi) * float(wij)
    return out


def dynamic_ensemble_weight(h_q: List[float], h_p: List[float], ensemble_head: Dict[str, Any]) -> float:
    """
    TODO-1: 计算论文 Equation (3) 中的动态权重 `w_t = f_θ(h_t^q, h_t^p)`。

    这里：
    - `h_q` 对应本题导出的低维 `h_t^q`
    - `h_p` 对应本题导出的低维 `h_t^p`
    - `ensemble_head` 对应已经训练好的 verifier head 参数

    返回：
    - `w_t`，表示当前步给 target 分布 `p_t` 的权重
    """
    logit = float(ensemble_head["b2"])
    # TODO-1:
    # 1. 拼接 `h_q` 与 `h_p` 得到输入向量 `x`
    # 2. 用 `_dense_forward(x, W1, b1)` 做第一层前向
    # 3. 对第一层输出逐元素做 `ReLU`
    # 4. 用第二层参数 `W2 / b2` 再做一次线性映射；
    #    这一层的输出维度是 1，所以最终得到的是标量 `logit`
    #    注意：`W2` 在 ensemble_head.json 中是形状 `[hidden, 1]` 的紧凑写法，
    #    即一个长度等于 hidden 维的一维向量，`logit = sum(W2[i] * hidden[i]) + b2`；
    #    不要把它当作二维矩阵传入 `_dense_forward` 复用第一层逻辑。
    # 5. 再把 `logit` 映射到 `[0, 1]` 内，返回最终的 `w_t`
    raise NotImplementedError("TODO-1: dynamic_ensemble_weight")


def ensemble_distribution(target_probs: List[float], draft_probs: List[float], w_t: float) -> List[float]:
    """
    TODO-2: 计算论文 Equation (4) 的动态 ensemble 分布：
    `ν_t^θ(x) = w_t p_t(x) + (1 - w_t) q_t(x)`。

    这里：
    - `target_probs` 对应 `p_t`
    - `draft_probs` 对应 `q_t`
    - `w_t` 是上一步得到的动态 target 权重
    """
    t = normalize_probs(target_probs)
    d = normalize_probs(draft_probs)
    w = float(w_t)

    # TODO-2:
    # 按 Equation (4) 构造混合后的 `mixed`，
    # 然后返回归一化后的动态验证分布。
    raise NotImplementedError("TODO-2: ensemble_distribution")


def acceptance_probability(drafted_token: int, verify_probs: List[float], draft_probs: List[float]) -> float:
    """
    计算论文 Equation (6) 的 relaxed accept rule：
    `b_{ν_t^θ}(x̃_t) = min(1, ν_t^θ(x̃_t) / q_t(x̃_t))`
    """
    v = normalize_probs(verify_probs)
    d = normalize_probs(draft_probs)
    idx = int(drafted_token)
    if idx < 0 or idx >= len(v):
        return 0.0
    return min(1.0, v[idx] / max(d[idx], EPS))


def residual_distribution(verify_probs: List[float], draft_probs: List[float]) -> List[float]:
    """
    计算论文 Equation (6) 的 fallback distribution：
    `P_{ν_t^θ}(x) ∝ [ν_t^θ(x) - q_t(x)]_+`

    为了让评测可复现，本题后续不会从这个分布随机采样，而是取其 argmax。
    """
    v = normalize_probs(verify_probs)
    d = normalize_probs(draft_probs)
    residual = [max(vi - di, 0.0) for vi, di in zip(v, d)]
    if sum(residual) <= EPS:
        return v
    return normalize_probs(residual)


def verify_single_step(
    target_probs: List[float],
    draft_probs: List[float],
    h_q: List[float],
    h_p: List[float],
    drafted_token: int,
    uniform_u: float,
    ensemble_head: Dict[str, Any],
) -> Dict[str, Any]:
    """
    TODO-3: 完成单步验证。

    这一步对应一次 token-level verification，需要把：
    1. `w_t = f_θ(h_t^q, h_t^p)`
    2. `ν_t^θ`
    3. `b_{ν_t^θ}(x̃_t)`
    4. `P_{ν_t^θ}`
    组织到同一步里。

    返回字典至少包含：
    - `token`
    - `accepted`
    - `w_t`
    - `accept_prob`
    - `verify_probs`
    - `residual_probs`
    """
    # TODO-3:
    # 1. 先计算 `w_t`
    # 2. 再计算 `verify_probs`
    # 3. 计算 `accept_prob`
    # 4. 计算 `residual_probs`
    # 5. 根据 `uniform_u` 与 `accept_prob` 判断本步是否接受草稿 token
    #    - 若接受：输出 `drafted_token`
    #    - 若拒绝：注意不要按论文原文做随机采样，本题必须输出 `_argmax_index(residual_probs)`
    # 6. 按题面要求返回完整字典
    raise NotImplementedError("TODO-3: verify_single_step")


def run_dynamic_verification(
    target_probs_seq: List[List[float]],
    draft_probs_seq: List[List[float]],
    h_q_seq: List[List[float]],
    h_p_seq: List[List[float]],
    draft_tokens: List[int],
    uniforms: List[float],
    ensemble_head: Dict[str, Any],
) -> Dict[str, Any]:
    """
    TODO-4: 按时间步执行动态验证。

    论文真实系统会按 block 运行 speculative decoding；
    本题为了便于函数式评测，把这部分改写成按时间步串联。

    返回字典至少包含：
    - `tokens`
    - `accepted_mask`
    - `weights`
    - `accept_probs`

    其中 `weights` 存的是每一步的 `w_t`。
    """
    n = min(
        len(target_probs_seq),
        len(draft_probs_seq),
        len(h_q_seq),
        len(h_p_seq),
        len(draft_tokens),
        len(uniforms),
    )

    tokens: List[int] = []
    accepted_mask: List[int] = []
    weights: List[float] = []
    accept_probs: List[float] = []

    # TODO-4:
    # 按时间步循环调用 `verify_single_step(...)`，
    # 并把每一步的：
    # - token
    # - accepted
    # - w_t
    # - accept_prob
    # 收集到上面 4 个结果列表中，最后返回汇总字典。
    raise NotImplementedError("TODO-4: run_dynamic_verification")
