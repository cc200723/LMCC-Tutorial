﻿# -*- coding: utf-8 -*-
"""
T3 评测：DIVERSED（简化）动态验证推测解码

总分 20：
- A 四个核心函数单测：16
- B 公开评测集：4
"""

from __future__ import annotations

import warnings

warnings.filterwarnings(
    "ignore",
    message=r"Warning: The /usr/local/Ascend/ascend-toolkit/.* owner does not match the current owner\.",
    category=UserWarning,
)

import json
import sys
from pathlib import Path
from statistics import mean
from typing import Any, Dict, List, Tuple

import submission

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from result_store import update_results

DATA_DIR = ROOT / "data"
PUBLIC_CASE_PATH = DATA_DIR / "T3_public_cases.jsonl"
ENSEMBLE_HEAD_PATH = Path(__file__).resolve().with_name("ensemble_head.json")

A_FULL = 16.0
B_FULL = 4.0
TOTAL_FULL = A_FULL + B_FULL

# 数值比较容差：官方实现与考生实现同属确定性子图，允许极小浮点差异。
# 若需在本地自测中放宽对单测分数的判定，可临时调大该常量（如 1e-5），
# 正式评测环境保持 1e-6 与官方口径一致。
NUMERIC_TOLERANCE = 1e-6

UNIT_EXPECTED = {
    "dynamic_weight_hi": 0.540620088775794,
    "dynamic_weight_lo": 0.22356749101307738,
    "ensemble_distribution": [
        0.17702918105734872,
        0.2632209545145711,
        0.12306930702810862,
        0.30787015392525957,
        0.12881040347471204,
    ],
    "verify_single_step": {
        "token": 0,
        "accepted": False,
        "w_t": 0.5707159669484329,
        "accept_prob": 0.6883774445582935,
        "verify_probs": [
            0.24767655376248832,
            0.05527789021337603,
            0.1188876752460446,
            0.09140713191554437,
            0.15307939665542092,
            0.14826699140231214,
            0.1854043608048137,
        ],
        "residual_probs": [
            0.5354696650561109,
            0.1602777467639752,
            0.0,
            0.30425258817991385,
            0.0,
            0.0,
            0.0,
        ],
    },
    "run_dynamic_verification": {
        "tokens": [3, 0],
        "accepted_mask": [1, 0],
        "weights": [0.44624848826365104, 0.5707159669484329],
        "accept_probs": [0.9137807101458468, 0.6883774445582935],
    },
}

UNIT_INPUTS = {
    "dynamic_weight_hi": {
        "h_q": [0.98852954, 0.24781233, 0.21888716, 0.02892517, 0.75, 0.4995102],
        "h_p": [0.89758609, 0.35890295, 0.31411302, 0.04478993, 0.75, 0.4764676],
    },
    "dynamic_weight_lo": {
        "h_q": [0.94699726, 0.30982423, 0.2550372, 0.05478703, 0.0, 0.46329131],
        "h_p": [0.93184344, 0.32948875, 0.23547369, 0.09401506, 0.0, 0.46591248],
    },
    "ensemble_distribution": {
        "target_probs": [0.14146129, 0.31411302, 0.1135212, 0.35890295, 0.07200153],
        "draft_probs": [0.21888716, 0.20332875, 0.13430597, 0.24781233, 0.19566578],
        "w_t": 0.540620088775794,
    },
    "verify_single_step": {
        "target_probs": [0.29078671, 0.0681817, 0.11572419, 0.11590222, 0.10095468, 0.14480821, 0.16364229],
        "draft_probs": [0.19036332, 0.03812279, 0.1230934, 0.05884189, 0.22237712, 0.1528653, 0.21433616],
        "h_q": [0.93345821, 0.22237712, 0.21433616, 0.00804096, 0.66666667, 0.56678121],
        "h_p": [0.95026642, 0.29078671, 0.16364229, 0.12714442, 0.0, 0.45950838],
        "drafted_token": 4,
        "uniform_u": 0.71563129,
    },
    "run_dynamic_verification": {
        "target_probs_seq": [
            [0.06704573, 0.13515031, 0.04974343, 0.17823654, 0.28255892, 0.04860543, 0.23865964],
            [0.29078671, 0.0681817, 0.11572419, 0.11590222, 0.10095468, 0.14480821, 0.16364229],
        ],
        "draft_probs_seq": [
            [0.08198483, 0.14908803, 0.06882808, 0.22092038, 0.21743584, 0.09050639, 0.17123646],
            [0.19036332, 0.03812279, 0.1230934, 0.05884189, 0.22237712, 0.1528653, 0.21433616],
        ],
        "h_q_seq": [
            [0.95480593, 0.22092038, 0.21743584, 0.00348454, 0.5, 0.54986656],
            [0.93345821, 0.22237712, 0.21433616, 0.00804096, 0.66666667, 0.56678121],
        ],
        "h_p_seq": [
            [0.90156767, 0.28255892, 0.23865964, 0.04389928, 0.66666667, 0.59576124],
            [0.95026642, 0.29078671, 0.16364229, 0.12714442, 0.0, 0.45950838],
        ],
        "draft_tokens": [3, 4],
        "uniforms": [0.09750454, 0.71563129],
    },
}


def load_json(path: Path) -> Dict[str, Any]:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def load_jsonl(path: Path) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    if not path.exists():
        return rows
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def _safe_call(fn, *args, **kwargs):
    try:
        return True, fn(*args, **kwargs)
    except Exception:
        return False, None


def _vector_close(a: List[float], b: List[float], tol: float = NUMERIC_TOLERANCE) -> bool:
    if len(a) != len(b):
        return False
    return all(abs(float(x) - float(y)) <= tol for x, y in zip(a, b))


def score_unit_tests(ensemble_head: Dict[str, Any]) -> Tuple[float, Dict[str, Any]]:
    score = 0.0
    detail: Dict[str, Any] = {}

    s1 = 0.0
    ok1, w_hi = _safe_call(
        submission.dynamic_ensemble_weight,
        UNIT_INPUTS["dynamic_weight_hi"]["h_q"],
        UNIT_INPUTS["dynamic_weight_hi"]["h_p"],
        ensemble_head,
    )
    ok2, w_lo = _safe_call(
        submission.dynamic_ensemble_weight,
        UNIT_INPUTS["dynamic_weight_lo"]["h_q"],
        UNIT_INPUTS["dynamic_weight_lo"]["h_p"],
        ensemble_head,
    )
    if ok1 and ok2:
        if (
            abs(float(w_hi) - UNIT_EXPECTED["dynamic_weight_hi"]) <= NUMERIC_TOLERANCE
            and abs(float(w_lo) - UNIT_EXPECTED["dynamic_weight_lo"]) <= NUMERIC_TOLERANCE
        ):
            s1 = 4.0
    score += s1
    detail["dynamic_ensemble_weight"] = s1

    s2 = 0.0
    ok, pred_mix = _safe_call(
        submission.ensemble_distribution,
        UNIT_INPUTS["ensemble_distribution"]["target_probs"],
        UNIT_INPUTS["ensemble_distribution"]["draft_probs"],
        UNIT_INPUTS["ensemble_distribution"]["w_t"],
    )
    if ok and isinstance(pred_mix, list) and _vector_close(pred_mix, UNIT_EXPECTED["ensemble_distribution"], tol=NUMERIC_TOLERANCE):
        s2 = 4.0
    score += s2
    detail["ensemble_distribution"] = s2

    s3 = 0.0
    ok, pred_step = _safe_call(
        submission.verify_single_step,
        UNIT_INPUTS["verify_single_step"]["target_probs"],
        UNIT_INPUTS["verify_single_step"]["draft_probs"],
        UNIT_INPUTS["verify_single_step"]["h_q"],
        UNIT_INPUTS["verify_single_step"]["h_p"],
        UNIT_INPUTS["verify_single_step"]["drafted_token"],
        UNIT_INPUTS["verify_single_step"]["uniform_u"],
        ensemble_head,
    )
    ref_step = UNIT_EXPECTED["verify_single_step"]
    if ok and isinstance(pred_step, dict):
        cond = (
            int(pred_step.get("token", -1)) == int(ref_step["token"])
            and bool(pred_step.get("accepted", True)) == bool(ref_step["accepted"])
            and abs(float(pred_step.get("w_t", -1.0)) - float(ref_step["w_t"])) <= NUMERIC_TOLERANCE
            and abs(float(pred_step.get("accept_prob", -1.0)) - float(ref_step["accept_prob"])) <= NUMERIC_TOLERANCE
            and isinstance(pred_step.get("verify_probs"), list)
            and isinstance(pred_step.get("residual_probs"), list)
            and _vector_close(pred_step["verify_probs"], ref_step["verify_probs"], tol=NUMERIC_TOLERANCE)
            and _vector_close(pred_step["residual_probs"], ref_step["residual_probs"], tol=NUMERIC_TOLERANCE)
        )
        if cond:
            s3 = 4.0
    score += s3
    detail["verify_single_step"] = s3

    s4 = 0.0
    ok, pred_seq = _safe_call(
        submission.run_dynamic_verification,
        UNIT_INPUTS["run_dynamic_verification"]["target_probs_seq"],
        UNIT_INPUTS["run_dynamic_verification"]["draft_probs_seq"],
        UNIT_INPUTS["run_dynamic_verification"]["h_q_seq"],
        UNIT_INPUTS["run_dynamic_verification"]["h_p_seq"],
        UNIT_INPUTS["run_dynamic_verification"]["draft_tokens"],
        UNIT_INPUTS["run_dynamic_verification"]["uniforms"],
        ensemble_head,
    )
    ref_seq = UNIT_EXPECTED["run_dynamic_verification"]
    if ok and isinstance(pred_seq, dict):
        cond = (
            pred_seq.get("tokens") == ref_seq["tokens"]
            and pred_seq.get("accepted_mask") == ref_seq["accepted_mask"]
            and isinstance(pred_seq.get("weights"), list)
            and isinstance(pred_seq.get("accept_probs"), list)
            and _vector_close(pred_seq["weights"], ref_seq["weights"], tol=NUMERIC_TOLERANCE)
            and _vector_close(pred_seq["accept_probs"], ref_seq["accept_probs"], tol=NUMERIC_TOLERANCE)
        )
        if cond:
            s4 = 4.0
    score += s4
    detail["run_dynamic_verification"] = s4

    detail["score"] = round(score, 3)
    return round(score, 2), detail


def _validate_pred_output(pred: Dict[str, Any]) -> bool:
    if not isinstance(pred, dict):
        return False
    keys = {"tokens", "accepted_mask", "weights", "accept_probs"}
    if not keys.issubset(pred.keys()):
        return False
    if not all(isinstance(pred[k], list) for k in keys):
        return False
    n = len(pred["tokens"])
    return n > 0 and all(len(pred[k]) == n for k in keys)


def _case_similarity_score(ref: Dict[str, Any], pred: Dict[str, Any]) -> float:
    n = min(len(ref["tokens"]), len(pred["tokens"]))
    if n <= 0:
        return 0.0

    ref_tokens = [int(x) for x in ref["tokens"][:n]]
    ref_accept = [int(x) for x in ref["accepted_mask"][:n]]
    ref_w = [float(x) for x in ref["weights"][:n]]
    ref_ap = [float(x) for x in ref["accept_probs"][:n]]

    pred_tokens = [int(x) for x in pred["tokens"][:n]]
    pred_accept = [int(x) for x in pred["accepted_mask"][:n]]
    pred_w = [float(x) for x in pred["weights"][:n]]
    pred_ap = [float(x) for x in pred["accept_probs"][:n]]

    token_acc = sum(int(a == b) for a, b in zip(ref_tokens, pred_tokens)) / n
    accept_acc = sum(int(a == b) for a, b in zip(ref_accept, pred_accept)) / n

    w_mae = mean(abs(a - b) for a, b in zip(ref_w, pred_w))
    ap_mae = mean(abs(a - b) for a, b in zip(ref_ap, pred_ap))

    w_score = max(0.0, 1.0 - w_mae / 0.08)
    ap_score = max(0.0, 1.0 - ap_mae / 0.08)

    total = 0.50 * token_acc + 0.20 * accept_acc + 0.15 * w_score + 0.15 * ap_score
    return float(total)


def score_case_split(cases: List[Dict[str, Any]], full_score: float, ensemble_head: Dict[str, Any]) -> Tuple[float, Dict[str, Any]]:
    if not cases:
        return 0.0, {"n_cases": 0, "avg_case": 0.0}

    case_scores: List[float] = []
    for case in cases:
        ref = case.get("expected")
        if not _validate_pred_output(ref):
            raise RuntimeError(f"case `{case.get('id', '<unknown>')}` missing valid `expected` result")
        ok, pred = _safe_call(
            submission.run_dynamic_verification,
            case["target_probs"],
            case["draft_probs"],
            case["h_q_seq"],
            case["h_p_seq"],
            case["draft_tokens"],
            case["uniforms"],
            ensemble_head,
        )
        if not ok or not _validate_pred_output(pred):
            case_scores.append(0.0)
            continue
        case_scores.append(_case_similarity_score(ref, pred))

    avg_case = mean(case_scores)
    split_score = round(full_score * avg_case, 2)
    detail = {
        "n_cases": len(cases),
        "avg_case": round(avg_case, 4),
        "min_case": round(min(case_scores), 4),
        "max_case": round(max(case_scores), 4),
    }
    return split_score, detail


def main() -> None:
    print("=" * 64)
    print("T3 正式评测开始：星港急速译码局")
    print("=" * 64)

    ensemble_head = load_json(ENSEMBLE_HEAD_PATH)
    public_cases = load_jsonl(PUBLIC_CASE_PATH)
    s_a, d_a = score_unit_tests(ensemble_head)
    s_b, d_b = score_case_split(public_cases, B_FULL, ensemble_head)
    total = round(s_a + s_b, 2)

    print(f"\n[A] 四个核心函数单测: {s_a:.2f}/{A_FULL:g}")
    print(f"    详情: {d_a}")
    print(f"[B] 公开评测集: {s_b:.2f}/{B_FULL:g}")
    print(f"    详情: {d_b}")
    print("-" * 64)
    print(f"总分: {total:.2f}/{TOTAL_FULL:g}")

    result_path = update_results(
        ROOT,
        "T3",
        total,
        TOTAL_FULL,
        detail={
            "unit": d_a,
            "public": d_b,
            "score_breakdown": {
                "unit": round(s_a, 2),
                "public": round(s_b, 2),
            },
        },
    )
    print(f"结果已更新: {result_path}")


if __name__ == "__main__":
    main()
