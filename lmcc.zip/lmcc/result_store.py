# -*- coding: utf-8 -*-
"""统一维护考试结果，并同步生成 JSON 与 Markdown 报告。"""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Any, Dict


TASK_FULL_SCORES: Dict[str, float] = {
    "T0_CSP": 10.0,
    "T0_LMCC": 10.0,
    "T1": 30.0,
    "T2": 30.0,
    "T3": 20.0,
}

HOME_RESULTS_FILENAME = "lmcc_exam_results.json"
MARKDOWN_FILENAME = "考生得分情况.md"
LMCC_ROOT = Path(__file__).resolve().parent
CURRENT_CWD = Path.cwd().resolve()

if CURRENT_CWD != LMCC_ROOT:
    raise ImportError(
        "请在 lmcc 根目录下运行 Python。"
        f"当前运行目录：{CURRENT_CWD}；"
        f"lmcc 根目录：{LMCC_ROOT}。"
        f"请先 `cd {LMCC_ROOT}` 后再运行评测脚本，"
        "例如：`cd lmcc && python T0_CSP/evaluate.py`。"
        "lmcc 目录可以放在任意位置，但 Python 必须从 lmcc 根目录启动。"
    )

SCORE_LABEL_TRANSLATIONS: Dict[str, Dict[str, str]] = {
    "T0_LMCC": {
        "content": "内容正确",
        "format": "输出格式",
    },
    "T1": {
        "visible.fields": "可见集字段",
        "visible.format": "可见集格式",
        "hidden.fields": "隐藏集字段",
        "hidden.format": "隐藏集格式",
    },
    "T2": {
        "a_distribution_diversity": "数据分布和多样性",
        "public": "公开集模型性能",
        "hidden": "隐藏集模型性能",
    },
    "T3": {
        "unit.dynamic_ensemble_weight": "动态权重函数",
        "unit.ensemble_distribution": "集成分布函数",
        "unit.verify_single_step": "单步校验函数",
        "unit.run_dynamic_verification": "动态校验主流程",
        "public": "公开评测集",
    },
}


def _root_results_path(root: Path) -> Path:
    return root / "results.json"


def _home_results_path() -> Path:
    return Path.home() / HOME_RESULTS_FILENAME


def _markdown_path() -> Path:
    return Path.cwd() / MARKDOWN_FILENAME


def _base_results() -> Dict[str, Any]:
    total_full = round(sum(TASK_FULL_SCORES.values()), 2)
    return {
        "updated_at": None,
        "tasks": {
            task_id: {
                "score": None,
                "full_score": full_score,
                "detail": None,
            }
            for task_id, full_score in TASK_FULL_SCORES.items()
        },
        "total": {
            "score": 0.0,
            "full_score": total_full,
            "percent": 0.0,
        },
    }


def _load_results(path: Path) -> Dict[str, Any]:
    base = _base_results()
    if not path.exists():
        return base

    try:
        with path.open("r", encoding="utf-8") as f:
            loaded = json.load(f)
    except Exception:
        return base

    if not isinstance(loaded, dict):
        return base

    tasks_payload = loaded.get("tasks") if isinstance(loaded.get("tasks"), dict) else loaded
    for task_id, full_score in TASK_FULL_SCORES.items():
        if not isinstance(tasks_payload, dict):
            break

        task_payload = tasks_payload.get(task_id)
        if isinstance(task_payload, dict):
            score = task_payload.get("score")
            detail = task_payload.get("detail")
            full = task_payload.get("full_score", full_score)
        else:
            score = tasks_payload.get(task_id)
            detail = None
            full = full_score

        if isinstance(score, (int, float)):
            base["tasks"][task_id]["score"] = round(float(score), 2)
        if isinstance(full, (int, float)):
            base["tasks"][task_id]["full_score"] = round(float(full), 2)
        if detail is not None:
            base["tasks"][task_id]["detail"] = detail

    _recompute_total(base)
    return base


def _recompute_total(results: Dict[str, Any]) -> None:
    total_score = 0.0
    total_full = 0.0
    for task_info in results["tasks"].values():
        full_score = task_info.get("full_score")
        score = task_info.get("score")
        if isinstance(full_score, (int, float)):
            total_full += float(full_score)
        if isinstance(score, (int, float)):
            total_score += float(score)

    total_full = round(total_full, 2)
    total_score = round(total_score, 2)
    percent = 0.0 if total_full <= 0 else round(100.0 * total_score / total_full, 2)
    results["total"] = {
        "score": total_score,
        "full_score": total_full,
        "percent": percent,
    }
    results["updated_at"] = datetime.now().isoformat(timespec="seconds")


def _write_json(path: Path, payload: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
        f.write("\n")


def _scalar_text(value: Any) -> str:
    if isinstance(value, float):
        return f"{value:.2f}".rstrip("0").rstrip(".")
    return str(value)


def _is_scalar_number(value: Any) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def _format_score_item_label(prefix: str, key: str) -> str:
    suffix = str(key)
    if suffix.startswith("score_"):
        suffix = suffix[len("score_") :]
    return f"{prefix}.{suffix}" if prefix else suffix


def _humanize_score_label(task_id: str, label: str) -> str:
    task_map = SCORE_LABEL_TRANSLATIONS.get(task_id, {})
    if label in task_map:
        return task_map[label]
    return str(label).replace("_", " ")


def _extract_score_items_from_container(container: Dict[str, Any], prefix: str) -> list[tuple[str, float]]:
    score_prefixed = [
        (_format_score_item_label(prefix, key), float(value))
        for key, value in container.items()
        if str(key).startswith("score_") and _is_scalar_number(value)
    ]
    if len(score_prefixed) >= 2:
        return score_prefixed

    numeric_items = [
        (_format_score_item_label(prefix, key), float(value))
        for key, value in container.items()
        if key != "score" and _is_scalar_number(value)
    ]
    total_score = container.get("score")
    if len(numeric_items) >= 2 and _is_scalar_number(total_score):
        subtotal = sum(value for _, value in numeric_items)
        if abs(subtotal - float(total_score)) <= 1e-6:
            return numeric_items

    return score_prefixed


def _extract_score_rows(task_id: str, detail: Any) -> list[tuple[str, str]]:
    if not isinstance(detail, dict):
        return []

    rows: list[tuple[str, float]] = []
    seen_labels: set[str] = set()

    score_breakdown = detail.get("score_breakdown")
    if isinstance(score_breakdown, dict):
        for key, value in score_breakdown.items():
            if not _is_scalar_number(value):
                continue
            expanded: list[tuple[str, float]] = []
            child = detail.get(key)
            if isinstance(child, dict):
                expanded = _extract_score_items_from_container(child, str(key))
            if len(expanded) >= 2:
                for label, score in expanded:
                    if label not in seen_labels:
                        rows.append((label, score))
                        seen_labels.add(label)
                continue

            label = _format_score_item_label("", str(key))
            if label not in seen_labels:
                rows.append((label, float(value)))
                seen_labels.add(label)

    direct_scores = _extract_score_items_from_container(detail, "")
    for label, score in direct_scores:
        if label not in seen_labels:
            rows.append((label, score))
            seen_labels.add(label)

    for key, child in detail.items():
        if key == "score_breakdown" or not isinstance(child, dict):
            continue
        nested_rows = _extract_score_items_from_container(child, str(key))
        if len(nested_rows) < 2:
            continue
        for label, score in nested_rows:
            if label not in seen_labels:
                rows.append((label, score))
                seen_labels.add(label)

    if len(rows) <= 1:
        return []
    return [(_humanize_score_label(task_id, label), _scalar_text(score)) for label, score in rows]


def _render_detail_lines(value: Any, indent: int = 0) -> list[str]:
    pad = "  " * indent
    if isinstance(value, dict):
        lines: list[str] = []
        for key, child in value.items():
            if isinstance(child, (dict, list)):
                lines.append(f"{pad}- {key}:")
                lines.extend(_render_detail_lines(child, indent + 1))
            else:
                lines.append(f"{pad}- {key}: {_scalar_text(child)}")
        return lines or [f"{pad}- {{}}"]
    if isinstance(value, list):
        lines = []
        for idx, child in enumerate(value, start=1):
            if isinstance(child, (dict, list)):
                lines.append(f"{pad}- [{idx}]")
                lines.extend(_render_detail_lines(child, indent + 1))
            else:
                lines.append(f"{pad}- [{idx}] {_scalar_text(child)}")
        return lines or [f"{pad}- []"]
    return [f"{pad}- {_scalar_text(value)}"]


def _write_markdown(
    path: Path,
    root_results: Path,
    home_results: Path,
    payload: Dict[str, Any],
) -> None:
    lines = [
        "# 考生得分情况",
        "",
        f"- 更新时间：{payload['updated_at']}",
        f"- 当前目录：{Path.cwd()}",
        f"- 根目录结果：{root_results}",
        f"- 用户目录结果：{home_results}",
    ]
    lines.extend(
        [
            "",
            "| 题目 | 得分 | 满分 | 分项得分 |",
            "| --- | ---: | ---: | ---: |",
        ]
    )

    for task_id, task_info in payload["tasks"].items():
        score = task_info.get("score")
        score_text = "-" if score is None else f"{float(score):.2f}"
        full_text = f"{float(task_info['full_score']):.2f}"
        lines.append(f"| {task_id} | {score_text} | {full_text} | - |")
        for label, part_score in _extract_score_rows(task_id, task_info.get("detail")):
            lines.append(f"| - {label} |  |  | {part_score} |")

    total = payload["total"]
    lines.extend(
        [
            "",
            f"**总分**：{total['score']:.2f} / {total['full_score']:.2f}（{total['percent']:.2f}%）",
            "",
        ]
    )

    for task_id, task_info in payload["tasks"].items():
        score = task_info.get("score")
        score_text = "-" if score is None else f"{float(score):.2f}"
        lines.append(f"## {task_id}")
        lines.append(f"- 得分：{score_text} / {float(task_info['full_score']):.2f}")
        detail = task_info.get("detail")
        if detail is None:
            lines.append("- 详情：暂无")
        else:
            lines.append("- 详情：")
            lines.extend(_render_detail_lines(detail, indent=1))
        lines.append("")

    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines).rstrip() + "\n", encoding="utf-8")


def update_results(
    root: Path,
    task_id: str,
    score: float,
    full_score: float,
    detail: Dict[str, Any] | None = None,
) -> Path:
    """更新单题结果，并同步写入根目录 JSON、用户目录 JSON 与当前目录 Markdown。"""
    if task_id not in TASK_FULL_SCORES:
        raise ValueError(f"未知 task_id: {task_id}")

    root_results = _root_results_path(root)
    results = _load_results(root_results)
    results["tasks"][task_id] = {
        "score": round(float(score), 2),
        "full_score": round(float(full_score), 2),
        "detail": detail,
    }
    _recompute_total(results)

    home_results = _home_results_path()
    markdown_path = _markdown_path()

    _write_json(root_results, results)
    _write_json(home_results, results)
    _write_markdown(markdown_path, root_results, home_results, results)
    return root_results
