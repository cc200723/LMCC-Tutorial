#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
真实双模型版 DIVERSED 复现实验脚本。

这份脚本不再使用离线写死的 `target_probs / draft_probs`，而是直接加载：

1. `Qwen3-8B` 作为 `target model`
2. `Qwen3-0.6B` 作为 `draft model`

并提供三类能力：

1. `generate`：真实运行 `auto / sd / static / diversed`
2. `benchmark`：比较不同方法的时延、acceptance rate 和质量
3. `train`：冻结两套基础模型，仅训练 dynamic ensemble head

训练目标参考论文 DIVERSED 的核心思路：

1. 用当前 dynamic verifier 真实生成文本
2. 用参考答案计算任务奖励
3. 用 REINFORCE 风格的策略梯度更新 ensemble head
4. 追加 acceptance regularization，鼓励 ensemble 分布更接近 draft 分布

注意：

1. 这是单文件、batch size = 1 的研究复现实验脚本，强调正确性与可读性
2. 推理与训练都是真实双模型前向，但没有做论文仓库里的底层 kernels/transformers 深度魔改
3. 因此它更适合做“机制验证 + 小型 Demo”，不能把这里的速度结果直接理解成论文级或生产级真实加速
"""

from __future__ import annotations

import argparse
import gc
import json
import math
import os
import random
import time
import warnings
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
os.environ.setdefault("TRANSFORMERS_NO_ADVISORY_WARNINGS", "1")

warnings.filterwarnings(
    "ignore",
    message=r"Warning: The /usr/local/Ascend/ascend-toolkit/.* owner does not match the current owner\.",
    category=UserWarning,
)
warnings.filterwarnings(
    "ignore",
    message=r"The current process just got forked, after parallelism has already been used\..*",
    category=UserWarning,
)

import torch
import torch.nn as nn
import torch.nn.functional as F
from transformers import AutoModelForCausalLM, AutoTokenizer, PreTrainedModel, PreTrainedTokenizerBase


try:
    import torch_npu  # noqa: F401
except Exception:
    torch_npu = None


EPS = 1e-12
DEFAULT_TARGET_MODEL_NAME = "Qwen3-8B"
DEFAULT_DRAFT_MODEL_NAME = "Qwen3-0.6B"
DEFAULT_SYSTEM_PROMPT = (
    "你是星港总调度台的摘要助手。"
    "请将输入压缩成一句正式中文摘要，只输出正文，不要标签或解释。"
    "保留结果、状态变化和关键时间/数量，删除次要细节，句子必须完整。"
)


def candidate_qwen_roots() -> List[Path]:
    script_dir = Path(__file__).resolve().parent
    candidates: List[Path] = []
    env_root = os.environ.get("QWEN_ROOT")
    if env_root:
        candidates.append(Path(env_root).expanduser())
    candidates.extend(
        [
            script_dir / "../../../Qwen",
            script_dir / "../../Qwen",
            script_dir / "../Qwen",
        ]
    )
    return [path.resolve() for path in candidates]


def discover_qwen_root() -> Optional[Path]:
    for root in candidate_qwen_roots():
        if (root / DEFAULT_TARGET_MODEL_NAME).exists() and (root / DEFAULT_DRAFT_MODEL_NAME).exists():
            return root
    return None


def resolve_model_path_args(args: argparse.Namespace) -> None:
    target_model = args.target_model or os.environ.get("TARGET_MODEL")
    draft_model = args.draft_model or os.environ.get("DRAFT_MODEL")

    if not target_model or not draft_model:
        qwen_root = discover_qwen_root()
        if qwen_root is not None:
            target_model = target_model or str(qwen_root / DEFAULT_TARGET_MODEL_NAME)
            draft_model = draft_model or str(qwen_root / DEFAULT_DRAFT_MODEL_NAME)

    missing = []
    if not target_model:
        missing.append("target model")
    if not draft_model:
        missing.append("draft model")
    if missing:
        attempted = "\n".join(f"  - {root}" for root in candidate_qwen_roots())
        raise FileNotFoundError(
            "未能解析模型路径。请设置 TARGET_MODEL / DRAFT_MODEL，"
            "或设置 QWEN_ROOT 指向同时包含 Qwen3-8B 和 Qwen3-0.6B 的目录。\n"
            f"已尝试的 QWEN_ROOT 候选：\n{attempted}"
        )

    for label, value in (("target_model", target_model), ("draft_model", draft_model)):
        path = Path(value).expanduser()
        if not path.exists():
            raise FileNotFoundError(
                f"{label} 路径不存在：{path}\n"
                "请通过命令行参数、TARGET_MODEL / DRAFT_MODEL，或 QWEN_ROOT 修正模型位置。"
            )
        setattr(args, label, str(path))


@dataclass
class SampleConfig:
    max_new_tokens: int = 128
    draft_steps: int = 4
    temperature: float = 0.7
    do_sample: bool = False


@dataclass
class GenerationTrace:
    method: str
    text: str
    new_token_ids: List[int]
    elapsed_s: float
    acceptance_rate: float
    accepted_tokens: int
    drafted_tokens: int
    mean_w_t: float
    trace: List[Dict[str, Any]] = field(default_factory=list)


@dataclass
class PromptItem:
    prompt: str
    reference: Optional[str] = None
    meta: Dict[str, Any] = field(default_factory=dict)


class RunningMean:
    def __init__(self, momentum: float = 0.9) -> None:
        self.momentum = momentum
        self.value: Optional[float] = None

    def advantage(self, reward: float) -> float:
        if self.value is None:
            return reward
        return reward - self.value

    def update(self, reward: float) -> None:
        if self.value is None:
            self.value = reward
            return
        self.value = self.momentum * self.value + (1.0 - self.momentum) * reward


class EnsembleHead(nn.Module):
    """
    论文官方实现里使用的是一个很轻的线性头：

    - 输入：draft hidden + target hidden
    - 输出：2 维 logits
    - softmax 后可得到 draft 侧补量与论文风格的 `w_t`
    """

    def __init__(self, draft_hidden_size: int, target_hidden_size: int) -> None:
        super().__init__()
        self.draft_hidden_size = int(draft_hidden_size)
        self.target_hidden_size = int(target_hidden_size)
        self.input_size = self.draft_hidden_size + self.target_hidden_size
        self.summary = nn.Linear(self.input_size, 2)
        self.reset_parameters()

    def reset_parameters(self) -> None:
        with torch.no_grad():
            weight = torch.randn(self.input_size, dtype=torch.float32) * 0.01
            self.summary.weight.copy_(weight.repeat(2, 1))
            self.summary.bias.zero_()

    def forward(self, draft_hidden: torch.Tensor, target_hidden: torch.Tensor) -> torch.Tensor:
        if draft_hidden.dim() == 1:
            draft_hidden = draft_hidden.unsqueeze(0)
        if target_hidden.dim() == 1:
            target_hidden = target_hidden.unsqueeze(0)
        x = torch.cat([draft_hidden, target_hidden], dim=-1).float()
        return self.summary(x)

    def save_pretrained(self, output_dir: str | Path, extra: Optional[Dict[str, Any]] = None) -> None:
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        torch.save(self.state_dict(), output_path / "ensemble_head.bin")
        config = {
            "draft_hidden_size": self.draft_hidden_size,
            "target_hidden_size": self.target_hidden_size,
        }
        if extra:
            config.update(extra)
        with (output_path / "ensemble_config.json").open("w", encoding="utf-8") as f:
            json.dump(config, f, ensure_ascii=False, indent=2)

    @classmethod
    def from_pretrained(cls, model_dir: str | Path, device: torch.device) -> "EnsembleHead":
        model_path = Path(model_dir)
        with (model_path / "ensemble_config.json").open("r", encoding="utf-8") as f:
            config = json.load(f)
        head = cls(
            draft_hidden_size=int(config["draft_hidden_size"]),
            target_hidden_size=int(config["target_hidden_size"]),
        )
        state = torch.load(model_path / "ensemble_head.bin", map_location="cpu")
        head.load_state_dict(state)
        head.to(device)
        return head


@dataclass
class ModelBundle:
    tokenizer: PreTrainedTokenizerBase
    target_model: PreTrainedModel
    draft_model: PreTrainedModel
    device: torch.device
    dtype: torch.dtype
    target_model_path: str
    draft_model_path: str
    system_prompt: str

    @property
    def eos_token_id(self) -> int:
        eos = self.tokenizer.eos_token_id
        if eos is None:
            raise ValueError("Tokenizer 没有 eos_token_id，无法安全结束生成")
        return int(eos)

    @property
    def pad_token_id(self) -> int:
        if self.tokenizer.pad_token_id is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
        return int(self.tokenizer.pad_token_id)

    def build_messages(self, prompt: str) -> List[Dict[str, str]]:
        return [
            {"role": "system", "content": self.system_prompt},
            {"role": "user", "content": prompt},
        ]

    def encode_messages(self, messages: List[Dict[str, str]]) -> torch.Tensor:
        if not hasattr(self.tokenizer, "apply_chat_template"):
            raise RuntimeError("当前 tokenizer 不支持 apply_chat_template，无法使用 Qwen 官方聊天模板。")
        try:
            rendered = self.tokenizer.apply_chat_template(
                messages,
                tokenize=False,
                add_generation_prompt=True,
                enable_thinking=False,
            )
        except TypeError:
            rendered = self.tokenizer.apply_chat_template(
                messages,
                tokenize=False,
                add_generation_prompt=True,
            )
        encoded = self.tokenizer(rendered, return_tensors="pt")
        return encoded.input_ids.to(self.device)

    def encode_prompt(self, prompt: str) -> torch.Tensor:
        return self.encode_messages(self.build_messages(prompt))

    def decode_new_tokens(self, token_ids: Sequence[int]) -> str:
        return self.tokenizer.decode(list(token_ids), skip_special_tokens=True)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Real Qwen-based DIVERSED reproduction script")
    parser.add_argument("--target-model", help="Target model path; defaults to TARGET_MODEL or QWEN_ROOT/Qwen3-8B")
    parser.add_argument("--draft-model", help="Draft model path; defaults to DRAFT_MODEL or QWEN_ROOT/Qwen3-0.6B")
    parser.add_argument("--device", default="auto", help="`auto` / `npu:0` / `cuda:0` / `cpu`")
    parser.add_argument("--dtype", default="bfloat16", choices=["bfloat16", "float16", "float32"])
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--system-prompt", default=DEFAULT_SYSTEM_PROMPT, help="System prompt used with Qwen chat template")

    subparsers = parser.add_subparsers(dest="command", required=True)

    common_generate = argparse.ArgumentParser(add_help=False)
    common_generate.add_argument("--method", default="diversed", choices=["auto", "sd", "static", "diversed"])
    common_generate.add_argument("--prompt", help="Single prompt")
    common_generate.add_argument("--prompt-file", help="Plain text file or jsonl file with `prompt` field")
    common_generate.add_argument("--max-new-tokens", type=int, default=128)
    common_generate.add_argument("--draft-steps", type=int, default=4)
    common_generate.add_argument("--temperature", type=float, default=0.7)
    common_generate.add_argument("--do-sample", action="store_true")
    common_generate.add_argument("--static-target-weight", type=float, default=0.65)
    common_generate.add_argument("--ensemble-dir", default="T3_artifacts/diversed_qwen_head")
    common_generate.add_argument("--output-file", help="Optional jsonl output path")
    common_generate.add_argument("--print-trace", action="store_true")

    generate_parser = subparsers.add_parser("generate", parents=[common_generate], help="Run one generation job")

    benchmark_parser = subparsers.add_parser("benchmark", parents=[common_generate], help="Benchmark multiple methods")
    benchmark_parser.add_argument("--num-runs", type=int, default=3)
    benchmark_parser.add_argument(
        "--warmup-runs",
        type=int,
        default=1,
        help="每种方法在正式计时前先跑多少轮预热，用于减少首次加载/编译/缓存建立带来的抖动",
    )
    benchmark_parser.add_argument(
        "--methods",
        nargs="+",
        default=["sd", "diversed"],
        choices=["auto", "sd", "static", "diversed"],
    )
    benchmark_parser.add_argument(
        "--reward-metric",
        default="rouge_l",
        choices=["rouge_l", "token_f1", "exact_match"],
        help="仅用于训练阶段或显式启用 reference_metric 质量评估时",
    )
    benchmark_parser.add_argument(
        "--quality-eval",
        default="reference_metric",
        choices=["reference_metric", "none"],
        help="benchmark 阶段的质量评估方式；默认基于参考答案计算奖励指标，不启用大模型逐条评审",
    )
    benchmark_parser.add_argument("--report-json", help="Optional JSON report output path")
    benchmark_parser.add_argument("--report-md", help="Optional Markdown report output path")
    benchmark_parser.add_argument("--sample-jsonl", help="Optional jsonl path used to save per-sample generation outputs")
    benchmark_parser.add_argument("--measure-memory", action="store_true", help="Measure generation peak allocator memory")

    train_parser = subparsers.add_parser("train", help="Train a dynamic ensemble head")
    train_parser.add_argument("--train-file", required=True, help="JSONL file with `prompt` + `reference`")
    train_parser.add_argument("--ensemble-dir", default="T3_artifacts/diversed_qwen_head")
    train_parser.add_argument("--epochs", type=int, default=1)
    train_parser.add_argument("--learning-rate", type=float, default=1e-4)
    train_parser.add_argument("--weight-decay", type=float, default=1e-2)
    train_parser.add_argument("--max-new-tokens", type=int, default=96)
    train_parser.add_argument("--draft-steps", type=int, default=4)
    train_parser.add_argument("--temperature", type=float, default=0.8)
    train_parser.add_argument("--do-sample", action="store_true")
    train_parser.add_argument("--reward-metric", default="rouge_l", choices=["rouge_l", "token_f1", "exact_match"])
    train_parser.add_argument("--accept-reg", type=float, default=0.10)
    train_parser.add_argument("--entropy-reg", type=float, default=0.01)
    train_parser.add_argument("--log-interval", type=int, default=1)
    train_parser.add_argument("--resume", action="store_true")
    train_parser.add_argument("--save-every-epoch", action="store_true")

    _ = generate_parser
    return parser.parse_args()


def seed_everything(seed: int) -> None:
    random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    if hasattr(torch, "npu") and torch.npu.is_available():
        torch.npu.manual_seed(seed)


def resolve_device(device_name: str) -> torch.device:
    if device_name != "auto":
        return torch.device(device_name)
    if hasattr(torch, "npu") and torch.npu.is_available():
        return torch.device("npu:0")
    if torch.cuda.is_available():
        return torch.device("cuda:0")
    return torch.device("cpu")


def resolve_dtype(dtype_name: str, device: torch.device) -> torch.dtype:
    mapping = {
        "float16": torch.float16,
        "bfloat16": torch.bfloat16,
        "float32": torch.float32,
    }
    dtype = mapping[dtype_name]
    if device.type == "cpu" and dtype != torch.float32:
        return torch.float32
    return dtype


def synchronize_device(device: torch.device) -> None:
    if device.type == "cuda":
        torch.cuda.synchronize(device)
    elif device.type == "npu" and hasattr(torch, "npu"):
        torch.npu.synchronize()


def reset_peak_memory(device: torch.device) -> None:
    try:
        if device.type == "cuda":
            torch.cuda.reset_peak_memory_stats(device)
        elif device.type == "npu" and hasattr(torch, "npu"):
            torch.npu.reset_peak_memory_stats()
    except Exception:
        pass


def get_peak_memory_mb(device: torch.device) -> Optional[float]:
    try:
        if device.type == "cuda":
            return float(torch.cuda.max_memory_allocated(device) / (1024 ** 2))
        if device.type == "npu" and hasattr(torch, "npu"):
            return float(torch.npu.max_memory_allocated() / (1024 ** 2))
    except Exception:
        return None
    return None


def load_models(args: argparse.Namespace) -> ModelBundle:
    device = resolve_device(args.device)
    dtype = resolve_dtype(args.dtype, device)
    tokenizer = AutoTokenizer.from_pretrained(args.target_model, trust_remote_code=True)
    if tokenizer.pad_token_id is None:
        tokenizer.pad_token = tokenizer.eos_token

    target_model = AutoModelForCausalLM.from_pretrained(
        args.target_model,
        torch_dtype=dtype,
        trust_remote_code=True,
        low_cpu_mem_usage=True,
    )
    draft_model = AutoModelForCausalLM.from_pretrained(
        args.draft_model,
        torch_dtype=dtype,
        trust_remote_code=True,
        low_cpu_mem_usage=True,
    )

    target_model.to(device).eval()
    draft_model.to(device).eval()

    for model in (target_model, draft_model):
        for param in model.parameters():
            param.requires_grad_(False)

    return ModelBundle(
        tokenizer=tokenizer,
        target_model=target_model,
        draft_model=draft_model,
        device=device,
        dtype=dtype,
        target_model_path=args.target_model,
        draft_model_path=args.draft_model,
        system_prompt=args.system_prompt,
    )


def get_hidden_size(model: PreTrainedModel) -> int:
    config = model.config
    if hasattr(config, "text_config") and hasattr(config.text_config, "hidden_size"):
        return int(config.text_config.hidden_size)
    if hasattr(config, "hidden_size"):
        return int(config.hidden_size)
    raise ValueError("无法从模型 config 中解析 hidden_size")


def load_or_init_head(bundle: ModelBundle, ensemble_dir: str, resume: bool = False) -> EnsembleHead:
    ensemble_path = Path(ensemble_dir)
    if ensemble_path.exists() and (ensemble_path / "ensemble_head.bin").exists():
        head = EnsembleHead.from_pretrained(ensemble_path, bundle.device)
        print(f"[head] loaded existing head from {ensemble_path}")
        return head
    if resume:
        raise FileNotFoundError(f"resume=True, 但没有找到 {ensemble_path}/ensemble_head.bin")
    head = EnsembleHead(
        draft_hidden_size=get_hidden_size(bundle.draft_model),
        target_hidden_size=get_hidden_size(bundle.target_model),
    ).to(bundle.device)
    print(f"[head] initialized a fresh ensemble head at {ensemble_path}")
    return head


def temperature_scale(logits: torch.Tensor, temperature: float) -> torch.Tensor:
    temp = max(float(temperature), 1e-5)
    return logits.float() / temp


def probs_from_logits(logits: torch.Tensor, temperature: float) -> torch.Tensor:
    return F.softmax(temperature_scale(logits, temperature), dim=-1)


def sample_token_from_probs(probs: torch.Tensor, do_sample: bool, generator: torch.Generator) -> int:
    cpu_probs = probs.detach().float().cpu().clamp_min(0.0)
    total = float(cpu_probs.sum().item())
    if total <= EPS:
        cpu_probs = torch.ones_like(cpu_probs) / cpu_probs.numel()
    else:
        cpu_probs = cpu_probs / total
    if do_sample:
        return int(torch.multinomial(cpu_probs, num_samples=1, generator=generator).item())
    return int(torch.argmax(cpu_probs).item())


def sample_uniform(generator: torch.Generator) -> float:
    return float(torch.rand(1, generator=generator).item())


def residual_distribution(verify_probs: torch.Tensor, draft_probs: torch.Tensor) -> torch.Tensor:
    residual = torch.clamp(verify_probs - draft_probs, min=0.0)
    total = float(residual.sum().item())
    if total <= EPS:
        return verify_probs / verify_probs.sum().clamp_min(EPS)
    return residual / residual.sum().clamp_min(EPS)


def build_verify_distribution(
    method: str,
    target_logits: torch.Tensor,
    draft_logits: torch.Tensor,
    temperature: float,
    head: Optional[EnsembleHead],
    draft_hidden: Optional[torch.Tensor],
    target_hidden: Optional[torch.Tensor],
    static_target_weight: float,
) -> Tuple[torch.Tensor, float]:
    if method == "sd":
        verify_probs = probs_from_logits(target_logits, temperature)
        return verify_probs, 1.0

    if method == "static":
        w_t = float(min(1.0, max(0.0, static_target_weight)))
        draft_share = 1.0 - w_t
        mixed_logits = draft_logits.float() * draft_share + target_logits.float() * w_t
        verify_probs = probs_from_logits(mixed_logits, temperature)
        return verify_probs, w_t

    if method == "diversed":
        if head is None or draft_hidden is None or target_hidden is None:
            raise ValueError("DIVERSED 模式需要 ensemble head 以及 target/draft hidden states")
        with torch.set_grad_enabled(head.training and torch.is_grad_enabled()):
            weight_logits = head(draft_hidden, target_hidden)
            weights = F.softmax(weight_logits, dim=-1)
        w_t = float(weights[..., 1].squeeze().detach().item())
        draft_share = 1.0 - w_t
        mixed_logits = draft_logits.float() * draft_share + target_logits.float() * w_t
        verify_probs = probs_from_logits(mixed_logits, temperature)
        return verify_probs, w_t

    raise ValueError(f"unknown verification method: {method}")


def decode_with_target_only(
    bundle: ModelBundle,
    prefix_ids: torch.Tensor,
    config: SampleConfig,
    generator: torch.Generator,
) -> GenerationTrace:
    current = prefix_ids.clone()
    start = time.time()
    new_token_ids: List[int] = []
    trace: List[Dict[str, Any]] = []

    for step in range(config.max_new_tokens):
        with torch.no_grad():
            outputs = bundle.target_model(current, use_cache=False)
            next_logits = outputs.logits[:, -1, :]
            next_probs = probs_from_logits(next_logits, config.temperature).squeeze(0)
        next_token = sample_token_from_probs(next_probs, config.do_sample, generator)
        current = torch.cat(
            [current, torch.tensor([[next_token]], dtype=current.dtype, device=bundle.device)],
            dim=1,
        )
        new_token_ids.append(next_token)
        trace.append(
            {
                "step": step,
                "mode": "auto",
                "token": next_token,
            }
        )
        if next_token == bundle.eos_token_id:
            break

    synchronize_device(bundle.device)
    elapsed = time.time() - start
    return GenerationTrace(
        method="auto",
        text=bundle.decode_new_tokens(new_token_ids),
        new_token_ids=new_token_ids,
        elapsed_s=elapsed,
        acceptance_rate=1.0,
        accepted_tokens=len(new_token_ids),
        drafted_tokens=len(new_token_ids),
        mean_w_t=1.0,
        trace=trace,
    )


def speculate_once(
    bundle: ModelBundle,
    prefix_ids: torch.Tensor,
    method: str,
    config: SampleConfig,
    head: Optional[EnsembleHead],
    static_target_weight: float,
    generator: torch.Generator,
) -> Tuple[List[int], List[Dict[str, Any]], int, int, List[float], bool]:
    if method == "auto":
        raise ValueError("speculate_once 不处理 auto 模式")

    draft_tokens: List[int] = []
    working = prefix_ids.clone()
    stop_after_block = False
    block_steps = max(1, min(config.draft_steps, config.max_new_tokens))

    with torch.no_grad():
        for _ in range(block_steps):
            draft_outputs = bundle.draft_model(working, use_cache=False)
            next_probs = probs_from_logits(draft_outputs.logits[:, -1, :], config.temperature).squeeze(0)
            token = sample_token_from_probs(next_probs, config.do_sample, generator)
            draft_tokens.append(token)
            working = torch.cat(
                [working, torch.tensor([[token]], dtype=working.dtype, device=bundle.device)],
                dim=1,
            )
            if token == bundle.eos_token_id:
                break

    candidate_ids = working
    need_hidden = method == "diversed"
    with torch.no_grad():
        target_outputs = bundle.target_model(candidate_ids, use_cache=False, output_hidden_states=need_hidden)
        draft_outputs = bundle.draft_model(candidate_ids, use_cache=False, output_hidden_states=need_hidden)

    prefix_len = prefix_ids.size(1)
    start_index = prefix_len - 1
    emitted: List[int] = []
    block_trace: List[Dict[str, Any]] = []
    accepted = 0
    drafted = len(draft_tokens)
    target_weights: List[float] = []

    for i, drafted_token in enumerate(draft_tokens):
        target_logits = target_outputs.logits[:, start_index + i, :]
        draft_logits = draft_outputs.logits[:, start_index + i, :]
        draft_probs = probs_from_logits(draft_logits, config.temperature).squeeze(0)

        draft_hidden = None
        target_hidden = None
        if need_hidden:
            draft_hidden = draft_outputs.hidden_states[-1][:, start_index + i, :]
            target_hidden = target_outputs.hidden_states[-1][:, start_index + i, :]

        verify_probs, w_t = build_verify_distribution(
            method=method,
            target_logits=target_logits,
            draft_logits=draft_logits,
            temperature=config.temperature,
            head=head,
            draft_hidden=draft_hidden,
            target_hidden=target_hidden,
            static_target_weight=static_target_weight,
        )
        verify_probs = verify_probs.squeeze(0)
        accept_prob = min(
            1.0,
            float(verify_probs[drafted_token].item())
            / max(float(draft_probs[drafted_token].item()), EPS),
        )
        u = sample_uniform(generator)
        if u <= accept_prob:
            final_token = int(drafted_token)
            accepted += 1
            accepted_flag = True
        else:
            fallback_probs = residual_distribution(verify_probs, draft_probs)
            final_token = sample_token_from_probs(fallback_probs, config.do_sample, generator)
            accepted_flag = False

        emitted.append(final_token)
        target_weights.append(w_t)
        block_trace.append(
            {
                "kind": "verify",
                "draft_token": int(drafted_token),
                "final_token": int(final_token),
                "accepted": accepted_flag,
                "accept_prob": float(accept_prob),
                "u": float(u),
                "w_t": float(w_t),
            }
        )
        if not accepted_flag or final_token == bundle.eos_token_id:
            stop_after_block = final_token == bundle.eos_token_id
            return emitted, block_trace, accepted, drafted, target_weights, stop_after_block

    next_target_logits = target_outputs.logits[:, start_index + drafted, :]
    next_draft_logits = draft_outputs.logits[:, start_index + drafted, :]
    next_draft_hidden = None
    next_target_hidden = None
    if need_hidden:
        next_draft_hidden = draft_outputs.hidden_states[-1][:, start_index + drafted, :]
        next_target_hidden = target_outputs.hidden_states[-1][:, start_index + drafted, :]

    verify_next_probs, w_t = build_verify_distribution(
        method=method,
        target_logits=next_target_logits,
        draft_logits=next_draft_logits,
        temperature=config.temperature,
        head=head,
        draft_hidden=next_draft_hidden,
        target_hidden=next_target_hidden,
        static_target_weight=static_target_weight,
    )
    verify_next_probs = verify_next_probs.squeeze(0)
    bonus_token = sample_token_from_probs(verify_next_probs, config.do_sample, generator)
    emitted.append(bonus_token)
    target_weights.append(w_t)
    block_trace.append(
        {
            "kind": "bonus",
            "final_token": int(bonus_token),
            "accepted": True,
            "accept_prob": 1.0,
            "u": 0.0,
            "w_t": float(w_t),
        }
    )
    stop_after_block = bonus_token == bundle.eos_token_id
    return emitted, block_trace, accepted, drafted, target_weights, stop_after_block


def decode_with_speculation(
    bundle: ModelBundle,
    prefix_ids: torch.Tensor,
    method: str,
    config: SampleConfig,
    generator: torch.Generator,
    head: Optional[EnsembleHead],
    static_target_weight: float,
) -> GenerationTrace:
    current = prefix_ids.clone()
    new_token_ids: List[int] = []
    accepted_tokens = 0
    drafted_tokens = 0
    target_weights: List[float] = []
    trace: List[Dict[str, Any]] = []
    start = time.time()

    while len(new_token_ids) < config.max_new_tokens:
        emitted, block_trace, accepted, drafted, block_weights, stop_after_block = speculate_once(
            bundle=bundle,
            prefix_ids=current,
            method=method,
            config=config,
            head=head,
            static_target_weight=static_target_weight,
            generator=generator,
        )
        remaining = config.max_new_tokens - len(new_token_ids)
        emitted = emitted[:remaining]
        for token in emitted:
            current = torch.cat(
                [current, torch.tensor([[token]], dtype=current.dtype, device=bundle.device)],
                dim=1,
            )
        new_token_ids.extend(emitted)
        accepted_tokens += accepted
        drafted_tokens += drafted
        target_weights.extend(block_weights[: len(emitted)])
        trace.extend(block_trace[: len(emitted)])

        if not emitted:
            break
        if emitted[-1] == bundle.eos_token_id or stop_after_block:
            break

    synchronize_device(bundle.device)
    elapsed = time.time() - start
    acceptance_rate = float(accepted_tokens / max(drafted_tokens, 1))
    mean_w_t = float(sum(target_weights) / max(len(target_weights), 1))
    return GenerationTrace(
        method=method,
        text=bundle.decode_new_tokens(new_token_ids),
        new_token_ids=new_token_ids,
        elapsed_s=elapsed,
        acceptance_rate=acceptance_rate,
        accepted_tokens=accepted_tokens,
        drafted_tokens=drafted_tokens,
        mean_w_t=mean_w_t,
        trace=trace,
    )


def run_generation(
    bundle: ModelBundle,
    prompt: str,
    method: str,
    config: SampleConfig,
    generator: torch.Generator,
    head: Optional[EnsembleHead],
    static_target_weight: float,
) -> GenerationTrace:
    prefix_ids = bundle.encode_prompt(prompt)
    if method == "auto":
        return decode_with_target_only(bundle, prefix_ids, config, generator)
    return decode_with_speculation(
        bundle=bundle,
        prefix_ids=prefix_ids,
        method=method,
        config=config,
        generator=generator,
        head=head,
        static_target_weight=static_target_weight,
    )


def profiled_generation(
    bundle: ModelBundle,
    prompt: str,
    method: str,
    config: SampleConfig,
    generator: torch.Generator,
    head: Optional[EnsembleHead],
    static_target_weight: float,
    measure_memory: bool,
) -> Tuple[GenerationTrace, Optional[float]]:
    if measure_memory:
        reset_peak_memory(bundle.device)
    trace = run_generation(
        bundle=bundle,
        prompt=prompt,
        method=method,
        config=config,
        generator=generator,
        head=head,
        static_target_weight=static_target_weight,
    )
    peak_memory_mb = get_peak_memory_mb(bundle.device) if measure_memory else None
    return trace, peak_memory_mb


def normalize_text(text: str) -> str:
    return " ".join(text.strip().lower().split())


def tokenize_metric_text(text: str) -> List[str]:
    norm = normalize_text(text)
    if not norm:
        return []
    if " " in norm:
        return norm.split()
    return list(norm)


def lcs_length(a: Sequence[str], b: Sequence[str]) -> int:
    if not a or not b:
        return 0
    dp = [0] * (len(b) + 1)
    for x in a:
        prev = 0
        for j, y in enumerate(b, start=1):
            tmp = dp[j]
            if x == y:
                dp[j] = prev + 1
            else:
                dp[j] = max(dp[j], dp[j - 1])
            prev = tmp
    return dp[-1]


def rouge_l_f1(pred: str, ref: str) -> float:
    pred_tokens = tokenize_metric_text(pred)
    ref_tokens = tokenize_metric_text(ref)
    if not pred_tokens or not ref_tokens:
        return 0.0
    lcs = lcs_length(pred_tokens, ref_tokens)
    prec = lcs / max(len(pred_tokens), 1)
    rec = lcs / max(len(ref_tokens), 1)
    if prec + rec <= EPS:
        return 0.0
    return 2.0 * prec * rec / (prec + rec)


def token_f1(pred: str, ref: str) -> float:
    pred_tokens = tokenize_metric_text(pred)
    ref_tokens = tokenize_metric_text(ref)
    if not pred_tokens or not ref_tokens:
        return 0.0
    pred_count: Dict[str, int] = {}
    ref_count: Dict[str, int] = {}
    for tok in pred_tokens:
        pred_count[tok] = pred_count.get(tok, 0) + 1
    for tok in ref_tokens:
        ref_count[tok] = ref_count.get(tok, 0) + 1
    overlap = 0
    for tok, count in pred_count.items():
        overlap += min(count, ref_count.get(tok, 0))
    if overlap <= 0:
        return 0.0
    prec = overlap / max(len(pred_tokens), 1)
    rec = overlap / max(len(ref_tokens), 1)
    return 2.0 * prec * rec / max(prec + rec, EPS)


def exact_match(pred: str, ref: str) -> float:
    return 1.0 if normalize_text(pred) == normalize_text(ref) else 0.0


def compute_reward(metric: str, pred: str, ref: str) -> float:
    if metric == "rouge_l":
        return rouge_l_f1(pred, ref)
    if metric == "token_f1":
        return token_f1(pred, ref)
    if metric == "exact_match":
        return exact_match(pred, ref)
    raise ValueError(f"unknown reward metric: {metric}")


def extract_prompt_item(row: Dict[str, Any]) -> PromptItem:
    prompt = None
    reference = None
    for key in ("prompt", "input", "question", "instruction"):
        if isinstance(row.get(key), str) and row[key].strip():
            prompt = row[key]
            break
    for key in ("reference", "answer", "target", "output", "completion"):
        if isinstance(row.get(key), str) and row[key].strip():
            reference = row[key]
            break
    if prompt is None:
        raise ValueError(f"无法从样本里解析 prompt: {row}")
    meta = {k: v for k, v in row.items() if k not in {"prompt", "input", "question", "instruction", "reference", "answer", "target", "output", "completion"}}
    return PromptItem(prompt=prompt, reference=reference, meta=meta)


def load_prompt_items(prompt: Optional[str], prompt_file: Optional[str]) -> List[PromptItem]:
    if prompt:
        return [PromptItem(prompt=prompt)]
    if not prompt_file:
        raise ValueError("请提供 `--prompt` 或 `--prompt-file`")
    path = Path(prompt_file)
    if path.suffix == ".jsonl":
        items: List[PromptItem] = []
        with path.open("r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                items.append(extract_prompt_item(json.loads(line)))
        return items
    lines = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.rstrip("\n")
            if line.strip():
                lines.append(PromptItem(prompt=line))
    return lines


def generate_chat_response(
    bundle: ModelBundle,
    model: PreTrainedModel,
    messages: List[Dict[str, str]],
    max_new_tokens: int,
) -> str:
    input_ids = bundle.encode_messages(messages)
    attention_mask = torch.ones_like(input_ids, device=input_ids.device)
    with torch.no_grad():
        outputs = model.generate(
            input_ids=input_ids,
            attention_mask=attention_mask,
            max_new_tokens=max_new_tokens,
            do_sample=False,
            pad_token_id=bundle.pad_token_id,
            eos_token_id=bundle.eos_token_id,
            use_cache=True,
        )
    new_token_ids = outputs[0, input_ids.size(1) :].tolist()
    return bundle.decode_new_tokens(new_token_ids).strip()


def compute_policy_gradient_loss(
    bundle: ModelBundle,
    head: EnsembleHead,
    prompt_ids: torch.Tensor,
    generated_token_ids: Sequence[int],
    reward: float,
    advantage: float,
    temperature: float,
    accept_reg: float,
    entropy_reg: float,
) -> Tuple[torch.Tensor, Dict[str, float]]:
    if not generated_token_ids:
        raise ValueError("generated_token_ids 不能为空")

    generated = torch.tensor([list(generated_token_ids)], dtype=prompt_ids.dtype, device=bundle.device)
    full_ids = torch.cat([prompt_ids, generated], dim=1)
    prompt_len = prompt_ids.size(1)

    with torch.no_grad():
        target_outputs = bundle.target_model(full_ids, use_cache=False, output_hidden_states=True)
        draft_outputs = bundle.draft_model(full_ids, use_cache=False, output_hidden_states=True)

    target_logits = target_outputs.logits[:, prompt_len - 1 : -1, :].detach().float()
    draft_logits = draft_outputs.logits[:, prompt_len - 1 : -1, :].detach().float()
    target_hidden = target_outputs.hidden_states[-1][:, prompt_len - 1 : -1, :].detach()
    draft_hidden = draft_outputs.hidden_states[-1][:, prompt_len - 1 : -1, :].detach()

    weight_logits = head(draft_hidden, target_hidden)
    weights = F.softmax(weight_logits, dim=-1)
    w_t = weights[..., 1:2]
    draft_share = 1.0 - w_t

    mixed_logits = draft_logits * draft_share + target_logits * w_t
    mixed_log_probs = F.log_softmax(temperature_scale(mixed_logits, temperature), dim=-1)
    mixed_probs = mixed_log_probs.exp()
    draft_probs = F.softmax(temperature_scale(draft_logits, temperature), dim=-1)

    target_tokens = full_ids[:, prompt_len:]
    token_log_probs = torch.gather(mixed_log_probs, 2, target_tokens.unsqueeze(-1)).squeeze(-1)
    seq_log_prob = token_log_probs.mean()

    acceptance_proxy = 1.0 - 0.5 * torch.abs(mixed_probs - draft_probs).sum(dim=-1)
    weight_entropy = -(weights.clamp_min(EPS).log() * weights).sum(dim=-1)

    adv_tensor = torch.tensor(float(advantage), device=bundle.device, dtype=torch.float32)
    policy_loss = -(adv_tensor.detach() * seq_log_prob)
    acceptance_loss = -float(accept_reg) * acceptance_proxy.mean()
    entropy_loss = -float(entropy_reg) * weight_entropy.mean()
    loss = policy_loss + acceptance_loss + entropy_loss

    metrics = {
        "reward": float(reward),
        "advantage": float(advantage),
        "policy_loss": float(policy_loss.detach().item()),
        "acceptance_proxy": float(acceptance_proxy.mean().detach().item()),
        "weight_entropy": float(weight_entropy.mean().detach().item()),
        "mean_w_t": float(w_t.mean().detach().item()),
        "seq_log_prob": float(seq_log_prob.detach().item()),
        "loss": float(loss.detach().item()),
    }
    return loss, metrics


def train_head(args: argparse.Namespace) -> None:
    bundle = load_models(args)
    head = load_or_init_head(bundle, args.ensemble_dir, resume=args.resume)
    head.train()

    optimizer = torch.optim.AdamW(head.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay)
    baseline = RunningMean(momentum=0.9)
    generator = torch.Generator(device="cpu")
    generator.manual_seed(args.seed)

    train_items = load_prompt_items(prompt=None, prompt_file=args.train_file)
    if not all(item.reference for item in train_items):
        raise ValueError("训练数据必须是 jsonl，并且每条样本都提供 `reference`")

    config = SampleConfig(
        max_new_tokens=args.max_new_tokens,
        draft_steps=args.draft_steps,
        temperature=args.temperature,
        do_sample=args.do_sample,
    )

    history: List[Dict[str, Any]] = []
    output_dir = Path(args.ensemble_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    for epoch in range(1, args.epochs + 1):
        random.shuffle(train_items)
        print(f"[train] epoch {epoch}/{args.epochs}, examples={len(train_items)}")
        for step, item in enumerate(train_items, start=1):
            optimizer.zero_grad(set_to_none=True)
            with torch.no_grad():
                trace = run_generation(
                    bundle=bundle,
                    prompt=item.prompt,
                    method="diversed",
                    config=config,
                    generator=generator,
                    head=head,
                    static_target_weight=1.0,
                )
            reward = compute_reward(args.reward_metric, trace.text, item.reference or "")
            advantage = baseline.advantage(reward)
            prompt_ids = bundle.encode_prompt(item.prompt)
            loss, metrics = compute_policy_gradient_loss(
                bundle=bundle,
                head=head,
                prompt_ids=prompt_ids,
                generated_token_ids=trace.new_token_ids,
                reward=reward,
                advantage=advantage,
                temperature=args.temperature,
                accept_reg=args.accept_reg,
                entropy_reg=args.entropy_reg,
            )
            loss.backward()
            optimizer.step()
            baseline.update(reward)

            record = {
                "epoch": epoch,
                "step": step,
                "reward": reward,
                "acceptance_rate": trace.acceptance_rate,
                "mean_w_t": trace.mean_w_t,
                **metrics,
            }
            history.append(record)
            if step % args.log_interval == 0:
                print(
                    "[train] "
                    f"epoch={epoch} step={step} reward={reward:.4f} "
                    f"loss={metrics['loss']:.4f} accept={trace.acceptance_rate:.4f} "
                    f"w_t={metrics['mean_w_t']:.4f}"
                )

        if args.save_every_epoch:
            head.save_pretrained(
                output_dir,
                extra={
                    "target_model": bundle.target_model_path,
                    "draft_model": bundle.draft_model_path,
                    "epoch": epoch,
                },
            )

    head.save_pretrained(
        output_dir,
        extra={
            "target_model": bundle.target_model_path,
            "draft_model": bundle.draft_model_path,
            "epochs": args.epochs,
            "reward_metric": args.reward_metric,
        },
    )
    with (output_dir / "training_history.json").open("w", encoding="utf-8") as f:
        json.dump(history, f, ensure_ascii=False, indent=2)
    print(f"[train] saved ensemble head to {output_dir}")


def print_generation_result(item: PromptItem, trace: GenerationTrace, show_trace: bool) -> None:
    print("=" * 80)
    print(f"[prompt]\n{item.prompt}")
    print(f"[method] {trace.method}")
    print(
        f"[stats] time={trace.elapsed_s:.2f}s "
        f"accept={trace.acceptance_rate:.4f} "
        f"drafted={trace.drafted_tokens} "
        f"accepted={trace.accepted_tokens} "
        f"mean_w_t={trace.mean_w_t:.4f}"
    )
    if item.reference:
        print(f"[reference]\n{item.reference}")
    print(f"[output]\n{trace.text}")
    if show_trace:
        print("[trace]")
        for row in trace.trace:
            print(json.dumps(row, ensure_ascii=False))


def maybe_write_outputs(path: Optional[str], rows: Iterable[Dict[str, Any]]) -> None:
    if not path:
        return
    output_path = Path(path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
    print(f"[写入] 已保存逐样本输出到 {output_path}")


def write_json_report(path: Optional[str], payload: Dict[str, Any]) -> None:
    if not path:
        return
    output_path = Path(path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
    print(f"[写入] 已保存基准测试 JSON 报告到 {output_path}")


def build_diversed_analysis(
    summary: Dict[str, Dict[str, float]],
    quality_eval: str,
) -> Dict[str, Any]:
    if "sd" not in summary or "diversed" not in summary:
        return {
            "status": "unavailable",
            "title": "无法自动判断",
            "conclusion": "当前结果缺少 `sd` 或 `diversed`，因此无法自动判断论文方法是否优于传统投机采样。",
            "details": [],
        }

    baseline = summary["sd"]
    candidate = summary["diversed"]

    time_delta_s = candidate["avg_time_s"] - baseline["avg_time_s"]
    time_delta_ratio = time_delta_s / max(baseline["avg_time_s"], EPS)
    throughput_delta = candidate["avg_tokens_per_s"] - baseline["avg_tokens_per_s"]
    throughput_delta_ratio = throughput_delta / max(baseline["avg_tokens_per_s"], EPS)
    acceptance_delta = candidate["avg_acceptance_rate"] - baseline["avg_acceptance_rate"]
    memory_delta = candidate["avg_peak_memory_mb"] - baseline["avg_peak_memory_mb"]

    faster = candidate["avg_time_s"] + EPS < baseline["avg_time_s"]
    higher_throughput = candidate["avg_tokens_per_s"] > baseline["avg_tokens_per_s"] + EPS
    details = [
        f"平均耗时变化：{time_delta_s:+.4f} 秒（{time_delta_ratio:+.2%}）",
        f"平均吞吐变化：{throughput_delta:+.4f} tok/s（{throughput_delta_ratio:+.2%}）",
        f"平均接受率变化：{acceptance_delta:+.4f}",
        f"平均峰值显存变化：{memory_delta:+.2f} MB",
    ]

    comparison: Dict[str, Any] = {
        "baseline_method": "sd",
        "candidate_method": "diversed",
        "time_delta_s": time_delta_s,
        "time_delta_ratio": time_delta_ratio,
        "throughput_delta": throughput_delta,
        "throughput_delta_ratio": throughput_delta_ratio,
        "acceptance_delta": acceptance_delta,
        "peak_memory_delta_mb": memory_delta,
    }

    if quality_eval == "reference_metric":
        reward_delta = candidate["avg_reward"] - baseline["avg_reward"]
        better_reward = candidate["avg_reward"] > baseline["avg_reward"] + EPS
        reward_not_worse = candidate["avg_reward"] + EPS >= baseline["avg_reward"]
        details.append(f"平均奖励变化：{reward_delta:+.4f}")
        comparison.update({"quality_eval": quality_eval, "reward_delta": reward_delta})

        if faster and reward_not_worse:
            status = "better"
            title = "整体优于传统投机采样"
            conclusion = (
                "本次实验中，DIVERSED 在平均耗时上更快，且奖励没有下降，"
                "可以认为论文方法整体优于传统 speculative decoding。"
            )
        elif faster and not reward_not_worse:
            status = "tradeoff_speed"
            title = "速度更好，但质量下降"
            conclusion = (
                "本次实验中，DIVERSED 的平均耗时更短，但奖励低于传统 speculative decoding，"
                "说明它带来了速度收益，但存在质量退化，属于取舍而不是整体更优。"
            )
        elif not faster and better_reward:
            status = "tradeoff_quality"
            title = "质量更好，但速度没有占优"
            conclusion = (
                "本次实验中，DIVERSED 的奖励更高，但平均耗时没有快于传统 speculative decoding，"
                "因此不能认为它在当前实现下整体更优。"
            )
        elif higher_throughput and reward_not_worse:
            status = "mixed"
            title = "吞吐更高，但端到端耗时未占优"
            conclusion = (
                "本次实验中，DIVERSED 的吞吐和奖励不差于传统 speculative decoding，"
                "但平均耗时没有更快，因此更像是局部收益，而不是端到端整体更优。"
            )
        else:
            status = "not_better"
            title = "当前结果不支持论文方法更优"
            conclusion = (
                "本次实验中，DIVERSED 在速度主指标上没有优于传统 speculative decoding，"
                "且质量收益也不足以抵消这一点，当前结果不支持它整体更优。"
            )
    else:
        comparison.update({"quality_eval": quality_eval})
        if faster and higher_throughput and acceptance_delta >= -EPS:
            status = "better"
            title = "速度侧整体优于传统投机采样"
            conclusion = (
                "本次实验未启用参考答案奖励指标，因此这里只比较速度侧结果。"
                "DIVERSED 的平均耗时更短、吞吐更高，且接受率没有下降，可以认为它在当前 Demo 中的速度侧整体优于传统 speculative decoding。"
            )
        elif faster:
            status = "tradeoff_speed"
            title = "耗时更短，但仍需结合质量指标理解"
            conclusion = (
                "本次实验未启用参考答案奖励指标。DIVERSED 的平均耗时更短，"
                "但由于缺少质量代理指标，当前只能确认它带来了速度收益，不能直接下整体更优的结论。"
            )
        elif higher_throughput or acceptance_delta > EPS:
            status = "mixed"
            title = "存在局部收益，但主耗时未占优"
            conclusion = (
                "本次实验未启用参考答案奖励指标。DIVERSED 在吞吐或接受率上有局部优势，"
                "但平均耗时没有更快，因此当前只能认为它存在局部收益。"
            )
        else:
            status = "not_better"
            title = "当前结果不支持论文方法更优"
            conclusion = (
                "本次实验未启用参考答案奖励指标，且 DIVERSED 在速度主指标上也没有占优，"
                "因此当前结果不支持它优于传统 speculative decoding。"
            )
    return {
        "status": status,
        "title": title,
        "conclusion": conclusion,
        "details": details,
        "comparison": comparison,
    }


def write_markdown_report(path: Optional[str], payload: Dict[str, Any]) -> None:
    if not path:
        return
    output_path = Path(path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    speedup_label = "相对普通 sd 加速比" if payload["baseline_method"] == "sd" else f"相对 {payload['baseline_method']} 加速比"
    quality_eval = payload.get("quality_eval", "reference_metric")
    lines = [
        "# Qwen DIVERSED 基准测试报告",
        "",
        f"- 目标模型：`{payload['target_model']}`",
        f"- 草稿模型：`{payload['draft_model']}`",
        f"- 基准数据：`{payload['prompt_file']}`",
        f"- 质量评估方式：`{quality_eval}`",
        "",
    ]
    if quality_eval == "reference_metric":
        lines.extend(
            [
                f"- 奖励指标：`{payload['reward_metric']}`",
                "",
                f"| 方法 | 平均耗时(秒) | 平均吞吐(tok/s) | 平均接受率 | 平均奖励 | 平均峰值显存(MB) | {speedup_label} |",
                "| --- | ---: | ---: | ---: | ---: | ---: | ---: |",
            ]
        )
    else:
        lines.extend(
            [
                "",
                f"| 方法 | 平均耗时(秒) | 平均吞吐(tok/s) | 平均接受率 | 平均峰值显存(MB) | {speedup_label} |",
                "| --- | ---: | ---: | ---: | ---: | ---: |",
            ]
        )
    for method, stats in payload["summary"].items():
        if quality_eval == "reference_metric":
            lines.append(
                "| "
                f"{method} | "
                f"{stats.get('avg_time_s', 0.0):.4f} | "
                f"{stats.get('avg_tokens_per_s', 0.0):.4f} | "
                f"{stats.get('avg_acceptance_rate', 0.0):.4f} | "
                f"{stats.get('avg_reward', 0.0):.4f} | "
                f"{stats.get('avg_peak_memory_mb', 0.0):.2f} | "
                f"{stats.get('speedup_vs_sd', 0.0):.4f} |"
            )
        else:
            lines.append(
                "| "
                f"{method} | "
                f"{stats.get('avg_time_s', 0.0):.4f} | "
                f"{stats.get('avg_tokens_per_s', 0.0):.4f} | "
                f"{stats.get('avg_acceptance_rate', 0.0):.4f} | "
                f"{stats.get('avg_peak_memory_mb', 0.0):.2f} | "
                f"{stats.get('speedup_vs_sd', 0.0):.4f} |"
            )
    analysis = payload.get("analysis")
    if analysis:
        lines.extend(
            [
                "",
                "## 自动分析",
                "",
                f"- 结论：{analysis.get('title', '无')}",
                f"- 说明：{analysis.get('conclusion', '无')}",
            ]
        )
        for detail in analysis.get("details", []):
            lines.append(f"- {detail}")
    output_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"[写入] 已保存基准测试 Markdown 报告到 {output_path}")


def run_generate_command(args: argparse.Namespace) -> None:
    bundle = load_models(args)
    head = None
    if args.method == "diversed":
        head = load_or_init_head(bundle, args.ensemble_dir, resume=False)
        head.eval()

    items = load_prompt_items(args.prompt, args.prompt_file)
    config = SampleConfig(
        max_new_tokens=args.max_new_tokens,
        draft_steps=args.draft_steps,
        temperature=args.temperature,
        do_sample=args.do_sample,
    )
    generator = torch.Generator(device="cpu")
    generator.manual_seed(args.seed)

    output_rows: List[Dict[str, Any]] = []
    for item in items:
        trace = run_generation(
            bundle=bundle,
            prompt=item.prompt,
            method=args.method,
            config=config,
            generator=generator,
            head=head,
            static_target_weight=args.static_target_weight,
        )
        print_generation_result(item, trace, args.print_trace)
        output_rows.append(
            {
                "prompt": item.prompt,
                "reference": item.reference,
                "method": trace.method,
                "output": trace.text,
                "elapsed_s": trace.elapsed_s,
                "acceptance_rate": trace.acceptance_rate,
                "accepted_tokens": trace.accepted_tokens,
                "drafted_tokens": trace.drafted_tokens,
                "mean_w_t": trace.mean_w_t,
            }
        )

    maybe_write_outputs(args.output_file, output_rows)


def summarize_metric(values: List[float]) -> str:
    if not values:
        return "n/a"
    return f"{sum(values) / len(values):.4f}"


def short_prompt_preview(text: str, limit: int = 28) -> str:
    normalized = " ".join(text.strip().split())
    if len(normalized) <= limit:
        return normalized
    return normalized[: limit - 3] + "..."


def run_benchmark_command(args: argparse.Namespace) -> None:
    bundle = load_models(args)
    items = load_prompt_items(args.prompt, args.prompt_file)
    config = SampleConfig(
        max_new_tokens=args.max_new_tokens,
        draft_steps=args.draft_steps,
        temperature=args.temperature,
        do_sample=args.do_sample,
    )

    head: Optional[EnsembleHead] = None
    if "diversed" in args.methods:
        head = load_or_init_head(bundle, args.ensemble_dir, resume=False)
        head.eval()

    generator = torch.Generator(device="cpu")
    generator.manual_seed(args.seed)

    print(
        "[评测] "
        f"方法={args.methods} "
        f"样本数={len(items)} "
        f"预热轮数={args.warmup_runs} "
        f"正式轮数={args.num_runs} "
        f"最大生成 token={args.max_new_tokens} "
        f"质量评估方式={args.quality_eval}",
        flush=True,
    )

    results: Dict[str, Dict[str, List[float]]] = {}
    sample_rows: List[Dict[str, Any]] = []
    for method in args.methods:
        results[method] = {
            "elapsed_s": [],
            "acceptance_rate": [],
            "reward": [],
            "output_tokens": [],
            "tokens_per_s": [],
            "peak_memory_mb": [],
        }
        total_warmup_jobs = args.warmup_runs * len(items)
        total_eval_jobs = args.num_runs * len(items)
        print(
            "[评测] "
            f"方法={method} 开始 "
            f"预热任务数={total_warmup_jobs} "
            f"正式任务数={total_eval_jobs}",
            flush=True,
        )
        for warmup_idx in range(args.warmup_runs):
            for item_idx, item in enumerate(items, start=1):
                print(
                    "[评测] "
                    f"方法={method} "
                    f"阶段=预热 "
                    f"轮次={warmup_idx + 1}/{args.warmup_runs} "
                    f"样本={item_idx}/{len(items)} "
                    f"提示词='{short_prompt_preview(item.prompt)}'",
                    flush=True,
                )
                profiled_generation(
                    bundle=bundle,
                    prompt=item.prompt,
                    method=method,
                    config=config,
                    generator=generator,
                    head=head if method == "diversed" else None,
                    static_target_weight=args.static_target_weight,
                    measure_memory=False,
                )
        for run_idx in range(args.num_runs):
            for item_idx, item in enumerate(items, start=1):
                print(
                    "[评测] "
                    f"方法={method} "
                    f"阶段=正式 "
                    f"轮次={run_idx + 1}/{args.num_runs} "
                    f"样本={item_idx}/{len(items)} "
                    f"提示词='{short_prompt_preview(item.prompt)}' "
                    "开始",
                    flush=True,
                )
                trace, peak_memory_mb = profiled_generation(
                    bundle=bundle,
                    prompt=item.prompt,
                    method=method,
                    config=config,
                    generator=generator,
                    head=head if method == "diversed" else None,
                    static_target_weight=args.static_target_weight,
                    measure_memory=args.measure_memory,
                )
                results[method]["elapsed_s"].append(trace.elapsed_s)
                results[method]["acceptance_rate"].append(trace.acceptance_rate)
                results[method]["output_tokens"].append(float(len(trace.new_token_ids)))
                results[method]["tokens_per_s"].append(float(len(trace.new_token_ids) / max(trace.elapsed_s, EPS)))
                if peak_memory_mb is not None:
                    results[method]["peak_memory_mb"].append(float(peak_memory_mb))

                reward = None
                if args.quality_eval == "reference_metric" and item.reference:
                    reward = compute_reward(args.reward_metric, trace.text, item.reference)
                    results[method]["reward"].append(reward)

                sample_rows.append(
                    {
                        "run_idx": run_idx,
                        "sample_idx": item_idx - 1,
                        "method": method,
                        "prompt": item.prompt,
                        "reference": item.reference,
                        "output": trace.text,
                        "elapsed_s": trace.elapsed_s,
                        "acceptance_rate": trace.acceptance_rate,
                        "accepted_tokens": trace.accepted_tokens,
                        "drafted_tokens": trace.drafted_tokens,
                        "output_tokens": len(trace.new_token_ids),
                        "tokens_per_s": float(len(trace.new_token_ids) / max(trace.elapsed_s, EPS)),
                        "peak_memory_mb": peak_memory_mb,
                    }
                )

                metric_note = (
                    f"奖励={reward:.4f}"
                    if reward is not None
                    else "奖励=n/a"
                )
                print(
                    "[评测] "
                    f"方法={method} "
                    f"阶段=正式 "
                    f"轮次={run_idx + 1}/{args.num_runs} "
                    f"样本={item_idx}/{len(items)} "
                    f"结束 耗时={trace.elapsed_s:.2f}秒 "
                    f"生成token={len(trace.new_token_ids)} "
                    f"接受率={trace.acceptance_rate:.4f} "
                    f"{metric_note}",
                    flush=True,
                )

        method_time = sum(results[method]["elapsed_s"]) / max(len(results[method]["elapsed_s"]), 1)
        method_tps = sum(results[method]["tokens_per_s"]) / max(len(results[method]["tokens_per_s"]), 1)
        if args.quality_eval == "reference_metric":
            method_reward = (
                sum(results[method]["reward"]) / max(len(results[method]["reward"]), 1)
                if results[method]["reward"]
                else 0.0
            )
            print(
                "[评测] "
                f"方法={method} 完成 "
                f"平均耗时={method_time:.2f}秒 "
                f"平均吞吐={method_tps:.4f}tok/s "
                f"平均奖励={method_reward:.4f}",
                flush=True,
            )
        else:
            print(
                "[评测] "
                f"方法={method} 完成 "
                f"平均耗时={method_time:.2f}秒 "
                f"平均吞吐={method_tps:.4f}tok/s "
                "奖励指标未启用",
                flush=True,
            )

    maybe_write_outputs(args.sample_jsonl, sample_rows)
    print("=" * 80)
    baseline_method = "sd" if "sd" in args.methods else args.methods[0]
    if args.quality_eval == "reference_metric":
        print("| 方法 | 耗时(秒) | 吞吐(tok/s) | 接受率 | 奖励 | 显存(MB) | 相对普通sd |")
        print("| --- | ---: | ---: | ---: | ---: | ---: | ---: |")
    else:
        print("| 方法 | 耗时(秒) | 吞吐(tok/s) | 接受率 | 显存(MB) | 相对普通sd |")
        print("| --- | ---: | ---: | ---: | ---: | ---: |")
    baseline_time = sum(results.get(baseline_method, {}).get("elapsed_s", [1.0])) / max(
        len(results.get(baseline_method, {}).get("elapsed_s", [1.0])),
        1,
    )
    summary: Dict[str, Dict[str, float]] = {}
    for method in args.methods:
        times = results[method]["elapsed_s"]
        mean_time = sum(times) / max(len(times), 1)
        speedup = baseline_time / max(mean_time, EPS)
        avg_tokens_per_s = sum(results[method]["tokens_per_s"]) / max(len(results[method]["tokens_per_s"]), 1)
        avg_acceptance = sum(results[method]["acceptance_rate"]) / max(len(results[method]["acceptance_rate"]), 1)
        avg_reward = sum(results[method]["reward"]) / max(len(results[method]["reward"]), 1) if results[method]["reward"] else 0.0
        avg_peak_memory = (
            sum(results[method]["peak_memory_mb"]) / max(len(results[method]["peak_memory_mb"]), 1)
            if results[method]["peak_memory_mb"]
            else 0.0
        )
        summary[method] = {
            "avg_time_s": mean_time,
            "avg_tokens_per_s": avg_tokens_per_s,
            "avg_acceptance_rate": avg_acceptance,
            "avg_reward": avg_reward,
            "avg_peak_memory_mb": avg_peak_memory,
            "speedup_vs_sd": speedup,
        }
        if args.quality_eval == "reference_metric":
            print(
                "| "
                f"{method} | "
                f"{summarize_metric(times)} | "
                f"{avg_tokens_per_s:.4f} | "
                f"{summarize_metric(results[method]['acceptance_rate'])} | "
                f"{summarize_metric(results[method]['reward'])} | "
                f"{avg_peak_memory:.2f} | "
                f"{speedup:.4f} |"
            )
        else:
            print(
                "| "
                f"{method} | "
                f"{summarize_metric(times)} | "
                f"{avg_tokens_per_s:.4f} | "
                f"{summarize_metric(results[method]['acceptance_rate'])} | "
                f"{avg_peak_memory:.2f} | "
                f"{speedup:.4f} |"
            )

    analysis = build_diversed_analysis(summary, args.quality_eval)
    print("=" * 80)
    print("[自动分析]")
    print(f"结论：{analysis['title']}")
    print(f"说明：{analysis['conclusion']}")
    for detail in analysis.get("details", []):
        print(f"- {detail}")

    report_payload = {
        "target_model": bundle.target_model_path,
        "draft_model": bundle.draft_model_path,
        "prompt_file": args.prompt_file,
        "reward_metric": args.reward_metric,
        "quality_eval": args.quality_eval,
        "baseline_method": baseline_method,
        "methods": args.methods,
        "num_runs": args.num_runs,
        "warmup_runs": args.warmup_runs,
        "summary": summary,
        "analysis": analysis,
        "sample_outputs": sample_rows,
        "raw": results,
    }
    write_json_report(args.report_json, report_payload)
    write_markdown_report(args.report_md, report_payload)


def main() -> None:
    args = parse_args()
    seed_everything(args.seed)
    resolve_model_path_args(args)
    try:
        if args.command == "train":
            train_head(args)
        elif args.command == "generate":
            run_generate_command(args)
        elif args.command == "benchmark":
            run_benchmark_command(args)
        else:
            raise ValueError(f"unknown command: {args.command}")
    finally:
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
        if hasattr(torch, "npu") and torch.npu.is_available():
            torch.npu.empty_cache()


if __name__ == "__main__":
    main()
