#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DRY_RUN="${DRY_RUN:-0}"

python_has_deps() {
  local candidate="$1"
  [[ -x "$candidate" ]] || return 1
  "$candidate" - <<'PY' >/dev/null 2>&1
import torch
import transformers
PY
}

if [[ -z "${PYTHON_BIN:-}" ]]; then
  PYTHON_CANDIDATES=()
  if [[ -n "${CONDA_PREFIX:-}" ]]; then
    PYTHON_CANDIDATES+=("$CONDA_PREFIX/bin/python")
  fi
  if [[ -n "${HOME:-}" ]]; then
    PYTHON_CANDIDATES+=("$HOME/miniconda3/bin/python")
  fi
  if command -v python >/dev/null 2>&1; then
    PYTHON_CANDIDATES+=("$(command -v python)")
  fi
  if command -v python3 >/dev/null 2>&1; then
    PYTHON_CANDIDATES+=("$(command -v python3)")
  fi

  for candidate in "${PYTHON_CANDIDATES[@]}"; do
    if python_has_deps "$candidate"; then
      PYTHON_BIN="$candidate"
      break
    fi
  done

  if [[ -z "${PYTHON_BIN:-}" ]]; then
    echo "[Error] 未找到可导入 torch/transformers 的 Python。请通过 PYTHON_BIN=/path/to/python 指定运行环境。" >&2
    exit 1
  fi
fi
if [[ -z "${QWEN_ROOT:-}" ]]; then
  for candidate in "$ROOT_DIR/../../../Qwen" "$ROOT_DIR/../../Qwen" "$ROOT_DIR/../Qwen"; do
    if [[ -d "$candidate" ]]; then
      QWEN_ROOT="$(cd "$candidate" && pwd)"
      break
    fi
  done
fi
if [[ -z "${TARGET_MODEL:-}" || -z "${DRAFT_MODEL:-}" ]]; then
  if [[ -z "${QWEN_ROOT:-}" ]]; then
    echo "[Error] 未找到 Qwen 权重目录。请设置 QWEN_ROOT，或分别设置 TARGET_MODEL / DRAFT_MODEL。" >&2
    exit 1
  fi
  TARGET_MODEL="${TARGET_MODEL:-$QWEN_ROOT/Qwen3-8B}"
  DRAFT_MODEL="${DRAFT_MODEL:-$QWEN_ROOT/Qwen3-0.6B}"
fi
DEVICE="${DEVICE:-auto}"
DTYPE="${DTYPE:-bfloat16}"
export TOKENIZERS_PARALLELISM="${TOKENIZERS_PARALLELISM:-false}"
export TRANSFORMERS_NO_ADVISORY_WARNINGS="${TRANSFORMERS_NO_ADVISORY_WARNINGS:-1}"
export PYTHONUNBUFFERED="${PYTHONUNBUFFERED:-1}"

TRAIN_FILE="${TRAIN_FILE:-$ROOT_DIR/diversed_train_small.jsonl}"
BENCH_FILE="${BENCH_FILE:-$ROOT_DIR/diversed_benchmark_small.jsonl}"
ARTIFACT_DIR="${ARTIFACT_DIR:-$ROOT_DIR/T3_artifacts/diversed_qwen_head}"
RESULT_DIR="${RESULT_DIR:-$ROOT_DIR/T3_artifacts/benchmark_$(date +%Y%m%d_%H%M%S)}"
SAMPLE_JSONL="$RESULT_DIR/sample_outputs.jsonl"

MAX_NEW_TOKENS="${MAX_NEW_TOKENS:-128}"
DRAFT_STEPS="${DRAFT_STEPS:-4}"
BENCH_RUNS="${BENCH_RUNS:-1}"
WARMUP_RUNS="${WARMUP_RUNS:-0}"
FORCE_TRAIN="${FORCE_TRAIN:-0}"
INCLUDE_STATIC="${INCLUDE_STATIC:-0}"
mkdir -p "$RESULT_DIR"

if [[ "$INCLUDE_STATIC" == "1" ]]; then
  METHODS=(sd static diversed)
else
  METHODS=(sd diversed)
fi

echo "[Info] 根目录=$ROOT_DIR"
echo "[Info] Python=$PYTHON_BIN"
echo "[Info] target_model=$TARGET_MODEL"
echo "[Info] draft_model=$DRAFT_MODEL"
echo "[Info] 结果目录=$RESULT_DIR"
echo "[Info] 评测方法=${METHODS[*]}"
echo "[Info] max_new_tokens=$MAX_NEW_TOKENS draft_steps=$DRAFT_STEPS bench_runs=$BENCH_RUNS warmup_runs=$WARMUP_RUNS"
echo "[Info] 质量评估=reference_metric（基于参考答案计算奖励指标，不启用大模型评审）"

if [[ "$DRY_RUN" == "1" ]]; then
  echo "[Info] DRY_RUN=1，仅检查路径和参数，不加载模型。"
  exit 0
fi

if [[ "$FORCE_TRAIN" == "1" || ! -f "$ARTIFACT_DIR/ensemble_head.bin" ]]; then
  echo "[阶段] 开始训练动态 ensemble head"
  "$PYTHON_BIN" "$ROOT_DIR/run_real_qwen_diversed.py" \
    --target-model "$TARGET_MODEL" \
    --draft-model "$DRAFT_MODEL" \
    --device "$DEVICE" \
    --dtype "$DTYPE" \
    train \
    --train-file "$TRAIN_FILE" \
    --ensemble-dir "$ARTIFACT_DIR" \
    --epochs 1 \
    --learning-rate 1e-4 \
    --weight-decay 1e-2 \
    --max-new-tokens "$MAX_NEW_TOKENS" \
    --draft-steps "$DRAFT_STEPS" \
    --temperature 0.8 \
    --do-sample \
    --reward-metric rouge_l \
    --accept-reg 0.10 \
    --entropy-reg 0.01 \
    --log-interval 1
else
  echo "[阶段] 复用已有的 ensemble head：$ARTIFACT_DIR"
fi

echo "[阶段] 开始运行基准测试"
"$PYTHON_BIN" "$ROOT_DIR/run_real_qwen_diversed.py" \
  --target-model "$TARGET_MODEL" \
  --draft-model "$DRAFT_MODEL" \
  --device "$DEVICE" \
  --dtype "$DTYPE" \
  benchmark \
  --prompt-file "$BENCH_FILE" \
  --ensemble-dir "$ARTIFACT_DIR" \
  --methods "${METHODS[@]}" \
  --quality-eval reference_metric \
  --max-new-tokens "$MAX_NEW_TOKENS" \
  --draft-steps "$DRAFT_STEPS" \
  --temperature 0.0 \
  --num-runs "$BENCH_RUNS" \
  --warmup-runs "$WARMUP_RUNS" \
  --measure-memory \
  --sample-jsonl "$SAMPLE_JSONL" \
  --report-json "$RESULT_DIR/report.json" \
  --report-md "$RESULT_DIR/report.md"

echo "[完成] 基准测试报告已生成："
echo "  样本输出：$SAMPLE_JSONL"
echo "  JSON：$RESULT_DIR/report.json"
echo "  Markdown：$RESULT_DIR/report.md"
