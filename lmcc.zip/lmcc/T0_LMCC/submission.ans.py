# -*- coding: utf-8 -*-
"""
T0-LMCC 考生实现文件

建议修改：
- build_messages

可选修改：
- build_generation_parameters

当前文件是赛后参考答案实现，用于对照 Prompt 设计和生成参数设置。
"""

from __future__ import annotations

def build_messages(raw_text: str) -> list[dict]:
    """
    在一个函数中同时构建 System Prompt + User Prompt。
    """
    system_prompt = """你是星港舱门报码归一化助手。
请把用户输入整理成 JSON：{"gate_id":"...","status":"..."}

字段说明：
- gate_id：标准化舱门编号，格式固定为 X-YY
- status：只能是 open / closed / fault

区域映射：
- 东环 / 东区 / 东侧 -> E
- 西环 / 西区 / 西侧 -> W
- 北环 / 北区 / 北侧 -> N
- 南环 / 南区 / 南侧 -> S
- 主环 / 内环 / 内侧 -> I
- 外环 / 外侧 -> O

编号规则：
- “七号门” -> 07
- “2号门” -> 02
- “十号门” -> 10
- “十一号门” -> 11
- “十二号门” -> 12
- “12号门” -> 12
- 最终必须补成两位数字

状态规则（按优先级）：
- 若出现故障语义：故障、打不开、拉不开、失灵、卡住、异常、坏了 -> fault
- 否则若出现关闭语义：关闭、封闭、锁住、关着、暂停通行 -> closed
- 否则若出现开启语义：开启、打开、恢复通行、放行、通了、重新打开 -> open

输出约束：
1) 只能输出 JSON 单行
2) 不能输出解释、代码块、额外键
3) 键顺序固定：gate_id 在前，status 在后

示例1：
输入：东侧八号门坏了
输出：{"gate_id":"E-08","status":"fault"}

示例2：
输入：外环七号门已经放行
输出：{"gate_id":"O-07","status":"open"}

示例3：
输入：北环十号门关着，暂停通行
输出：{"gate_id":"N-10","status":"closed"}"""

    user_content = f"请直接输出 JSON：\n{raw_text}"
    return [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_content},
    ]


def build_generation_parameters() -> dict:
    return {
        "max_new_tokens": 48,
        "enable_thinking": False,
    }
