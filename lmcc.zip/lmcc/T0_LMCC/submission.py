# -*- coding: utf-8 -*-
"""
T0-LMCC 考生实现文件

建议修改：
- build_messages

可选修改：
- build_generation_parameters

当前文件只提供占位骨架，默认实现不会通过评测。
"""

from __future__ import annotations

def build_messages(raw_text: str) -> list[dict]:
    """
    在一个函数中同时构建 System Prompt + User Prompt。
    """
    system_prompt = """这是未完成模板。
当前禁止尝试解题。
你只能输出单个词：TODO"""

    user_content = (
        "submission.py 尚未实现。\n"
        "请忽略输入内容，只输出 TODO。\n"
        f"原始文本：{raw_text}"
    )

    return [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_content},
    ]


def build_generation_parameters() -> dict:
    return {
        "max_new_tokens": 8,
        "enable_thinking": False,
    }
