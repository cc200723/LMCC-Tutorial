# -*- coding: utf-8 -*-
"""
T0-LMCC 评测脚本：Prompt 路线（舱门报码归一化）

评分（总分 10）：
- 内容正确：8 分（在可见集 + 隐藏集上联合统计字段级准确率）
- 输出格式：2 分（在可见集 + 隐藏集上联合统计合法 JSON + 合法键值）
"""

from __future__ import annotations

import warnings

warnings.filterwarnings(
    "ignore",
    message=r"Warning: The /usr/local/Ascend/ascend-toolkit/.* owner does not match the current owner\.",
    category=UserWarning,
)

import json
import os
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Tuple

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

import submission

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from result_store import update_results

VISIBLE_DATA_PATH = ROOT / "data" / "T0_test_data.jsonl"
HIDDEN_DATA_PATH = ROOT / "data" / "T0_test_data.final.jsonl"


def resolve_qwen_model_path(env_var: str, model_name: str) -> str:
    explicit = os.environ.get(env_var, "").strip()
    if explicit:
        return explicit
    qwen_root = os.environ.get("QWEN_ROOT", "").strip()
    roots = [Path(qwen_root).expanduser()] if qwen_root else []
    roots.extend([ROOT.parent.parent / "Qwen", ROOT.parent / "Qwen", ROOT / "Qwen"])
    for root in roots:
        candidate = root / model_name
        if candidate.exists():
            return str(candidate)
    return model_name


DEFAULT_MODEL_PATH = resolve_qwen_model_path("MODEL_PATH", "Qwen3-8B")

# LMCC 子题把“内容字段正确”和“输出格式正确”拆开计分。
# 字段级准确率用于内容分，合法 JSON + 合法键值用于格式分。
CONTENT_SCORE_FULL = 8.0
FORMAT_SCORE_FULL = 2.0
MAX_NEW_TOKENS = 96
ALLOWED_STATUS = {"open", "closed", "fault"}

# gate_id 的结构由题面固定为区域字母 + 两位编号；编号范围也在这里校验。
GATE_PATTERN = re.compile(r"^(E|W|N|S|I|O)-(\d{2})$")


def pick_device() -> str:
    """优先使用 CUDA，其次兼容 Ascend NPU 环境，最后回退到 CPU。"""
    if torch.cuda.is_available():
        return "cuda"
    if hasattr(torch, "npu"):
        try:
            if torch.npu.is_available():
                return "npu"
        except Exception:
            pass
    return "cpu"


def load_jsonl(path: Path) -> List[Dict[str, Any]]:
    """读取公开集或隐藏集；隐藏集缺失时返回空列表，便于本地自测。"""
    rows: List[Dict[str, Any]] = []
    if not path.exists():
        return rows
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def clean_model_text(text: str) -> str:
    """移除模型可能输出的 thinking 标记和 chat template 特殊符号。"""
    text = re.sub(r"<think>.*?</think>", "", text, flags=re.DOTALL | re.IGNORECASE)
    text = re.sub(r"<\|[^>]*think[^>]*\|>", "", text, flags=re.IGNORECASE)
    text = text.replace("<|im_start|>", "").replace("<|im_end|>", "")
    text = text.replace("<think>", "").replace("</think>", "")
    return text.strip()


def extract_json_text(raw_output: str) -> str:
    """从模型原始输出中尽量抽取 JSON，避免解释文本影响解析。"""
    lines = [x.strip() for x in raw_output.splitlines() if x.strip()]
    if not lines:
        return ""
    if lines[-1].startswith("{") and lines[-1].endswith("}"):
        return lines[-1]
    match = re.search(r"\{.*\}", raw_output, flags=re.DOTALL)
    if match:
        return match.group(0).strip()
    return lines[-1]


def gate_id_valid(gate_id: str) -> bool:
    """校验 gate_id 是否满足 X-YY 格式，且 YY 位于题目规定的 01-12。"""
    match = GATE_PATTERN.fullmatch(str(gate_id))
    if not match:
        return False
    return 1 <= int(match.group(2)) <= 12


def parse_prediction(pred_text: str) -> Tuple[Dict[str, Any] | None, bool]:
    """解析模型输出，并单独返回格式是否合法。"""
    try:
        obj = json.loads(pred_text)
    except Exception:
        return None, False

    if not isinstance(obj, dict):
        return None, False

    # 键集合不完全等于题面要求时，格式分为 0；但仍返回 obj，
    # 这样字段值若恰好正确，内容分可以按字段级规则独立统计。
    if set(obj.keys()) != {"gate_id", "status"}:
        return obj, False

    fmt_ok = gate_id_valid(obj.get("gate_id", "")) and obj.get("status") in ALLOWED_STATUS
    return obj, fmt_ok


def get_generation_parameters() -> Dict[str, Any]:
    """读取考生生成参数，并限制只能调整本题允许的两个开关。"""
    params = submission.build_generation_parameters()
    if not isinstance(params, dict):
        raise TypeError("build_generation_parameters() 必须返回 dict")

    # 评测器统一关闭采样，避免考生通过温度等参数引入非确定性。
    allowed = {"max_new_tokens", "enable_thinking"}
    invalid = set(params) - allowed
    if invalid:
        raise ValueError(f"不允许的生成参数: {sorted(invalid)}")

    return {
        "max_new_tokens": MAX_NEW_TOKENS,
        "enable_thinking": False,
        **params,
    }


def build_messages_for_case(raw_text: str) -> List[Dict[str, str]]:
    """调用考生的 prompt 构造函数，并检查 messages 结构是否可被模型消费。"""
    builder = getattr(submission, "build_messages", None)
    if not callable(builder):
        raise AttributeError("submission 必须提供 build_messages(raw_text)")

    messages = builder(raw_text)
    if not isinstance(messages, list) or len(messages) < 2:
        raise ValueError("build_messages 必须返回至少包含 system/user 的 list")

    for item in messages:
        if not isinstance(item, dict):
            raise ValueError("messages 中每项都必须是 dict")
        if not isinstance(item.get("role"), str) or not isinstance(item.get("content"), str):
            raise ValueError("messages 项必须包含字符串类型 role/content")

    return messages


def load_model_and_tokenizer(model_path: str) -> tuple[AutoModelForCausalLM, AutoTokenizer]:
    """加载统一评测模型；模型路径可通过 MODEL_PATH 环境变量覆盖。"""
    tokenizer = AutoTokenizer.from_pretrained(model_path, trust_remote_code=True)
    model = AutoModelForCausalLM.from_pretrained(
        model_path,
        torch_dtype=torch.float16,
        trust_remote_code=True,
    )
    model = model.to(pick_device())
    model.eval()
    return model, tokenizer


def infer_single(
    model: AutoModelForCausalLM,
    tokenizer: AutoTokenizer,
    messages: List[Dict[str, str]],
    generation_params: Dict[str, Any],
) -> tuple[str, str, Dict[str, Any] | None, bool]:
    """对单条样例做一次确定性生成，并返回原始输出、JSON 文本和解析结果。"""
    enable_thinking = bool(generation_params.get("enable_thinking", False))
    rendered = tokenizer.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True,
        enable_thinking=enable_thinking,
    )
    inputs = tokenizer(rendered, return_tensors="pt").to(model.device)

    gen_kwargs = dict(generation_params)
    gen_kwargs.pop("enable_thinking", None)

    # 统一使用 greedy decoding，保证同一份提交多次评测结果一致。
    gen_kwargs["do_sample"] = False
    gen_kwargs.setdefault("max_new_tokens", MAX_NEW_TOKENS)
    gen_kwargs["pad_token_id"] = tokenizer.pad_token_id
    gen_kwargs["eos_token_id"] = tokenizer.eos_token_id
    gen_kwargs.pop("temperature", None)
    gen_kwargs.pop("top_p", None)
    gen_kwargs.pop("top_k", None)

    with torch.no_grad():
        outputs = model.generate(**inputs, **gen_kwargs)

    raw = tokenizer.decode(outputs[0][inputs["input_ids"].shape[1] :], skip_special_tokens=False)
    raw = clean_model_text(raw)

    pred_text = extract_json_text(raw)
    pred_obj, fmt_ok = parse_prediction(pred_text)
    return raw, pred_text, pred_obj, fmt_ok


def eval_split(
    split_name: str,
    data: List[Dict[str, Any]],
    model: AutoModelForCausalLM,
    tokenizer: AutoTokenizer,
    generation_params: Dict[str, Any],
) -> Dict[str, Any]:
    """评测一个 split，并返回字段命中数与格式命中数。"""
    field_correct = 0
    format_correct = 0

    for i, item in enumerate(data, start=1):
        messages = build_messages_for_case(item["text"])
        raw, pred_text, pred_obj, fmt_ok = infer_single(model, tokenizer, messages, generation_params)

        # 内容分按字段级准确率统计；格式分按整条输出是否合法统计。
        hit_gate = bool(pred_obj and pred_obj.get("gate_id") == item["expected_gate_id"])
        hit_status = bool(pred_obj and pred_obj.get("status") == item["expected_status"])

        field_correct += int(hit_gate) + int(hit_status)
        format_correct += int(fmt_ok)

        print(f"[{split_name} {i}/{len(data)}] {item['id']} -> gate_id={hit_gate}, status={hit_status}, 格式={fmt_ok}")
        print(f"  输出: {raw}")

    return {
        "field_correct": field_correct,
        "total_fields": len(data) * 2,
        "format_correct": format_correct,
        "total_cases": len(data),
    }


def main() -> None:
    visible_data = load_jsonl(VISIBLE_DATA_PATH)
    hidden_data = load_jsonl(HIDDEN_DATA_PATH)
    hidden_missing = len(hidden_data) == 0
    generation_params = get_generation_parameters()

    print("=" * 64)
    print("T0-LMCC 评测开始（星港舱门报码归一化）")
    print("=" * 64)
    print(f"模型路径: {DEFAULT_MODEL_PATH}")

    model, tokenizer = load_model_and_tokenizer(DEFAULT_MODEL_PATH)

    visible_stat = eval_split("VISIBLE", visible_data, model, tokenizer, generation_params)
    if hidden_missing:
        # 允许考生在没有 final data 的环境中做公开自测。正式评测时隐藏集存在，
        # 可见集与隐藏集会被合并统计内容分和格式分。
        print("\n⚠️ 隐藏数据未给出，当前仅进行公开部分自测。")
        hidden_stat = {
            "field_correct": 0,
            "total_fields": 0,
            "format_correct": 0,
            "total_cases": 0,
        }
    else:
        hidden_stat = eval_split("HIDDEN", hidden_data, model, tokenizer, generation_params)

    field_correct = visible_stat["field_correct"] + hidden_stat["field_correct"]
    total_fields = visible_stat["total_fields"] + hidden_stat["total_fields"]
    format_correct = visible_stat["format_correct"] + hidden_stat["format_correct"]
    total_cases = visible_stat["total_cases"] + hidden_stat["total_cases"]

    # 内容 8 分来自字段级准确率；格式 2 分来自合法 JSON 和合法键值。
    score_content = CONTENT_SCORE_FULL * field_correct / max(1, total_fields)
    score_format = FORMAT_SCORE_FULL * format_correct / max(1, total_cases)
    total = score_content + score_format

    print("\n" + "-" * 64)
    print(f"可见字段: {visible_stat['field_correct']}/{visible_stat['total_fields']}")
    print(f"隐藏字段: {hidden_stat['field_correct']}/{hidden_stat['total_fields']}")
    print(f"总字段命中: {field_correct}/{total_fields} -> {score_content:.2f}/{CONTENT_SCORE_FULL:g}")
    print(f"总格式命中: {format_correct}/{total_cases} -> {score_format:.2f}/{FORMAT_SCORE_FULL:g}")
    print(f"得分: {total:.2f}/10")
    if hidden_missing:
        print("说明: 当前分数仅基于公开自测数据折算。")

    # update_results 会同时更新根目录 results.json、用户目录结果和 Markdown 报告。
    result_path = update_results(
        ROOT,
        "T0_LMCC",
        total,
        CONTENT_SCORE_FULL + FORMAT_SCORE_FULL,
        detail={
            "hidden_provided": not hidden_missing,
            "visible": visible_stat,
            "hidden": hidden_stat,
            "field_correct": field_correct,
            "total_fields": total_fields,
            "format_correct": format_correct,
            "total_cases": total_cases,
            "score_content": round(score_content, 2),
            "score_format": round(score_format, 2),
        },
    )
    print(f"结果已更新: {result_path}")


if __name__ == "__main__":
    main()
