# -*- coding: utf-8 -*-
"""T2 训练骨架：保留完整训练流程说明，只在关键实现处留空。"""

from __future__ import annotations

from contextlib import nullcontext
from dataclasses import dataclass
import json
import math
import os
from pathlib import Path
import random
from typing import Any, Dict, List, Tuple

import torch
from torch.optim import AdamW
from torch.utils.data import DataLoader

from tool_agent_common import (
    FIXED_MODEL_RELATIVE_PATH,
    MODEL_DIR,
    QWEN_TOOLS,
    REQUIRED_BASE_MODEL,
    REQUIRED_FINE_TUNING_TYPE,
    TOOL_AGENT_SYSTEM_PROMPT,
    SFT_DATA_PATH,
    TRAIN_DATA_PATH,
    list_relative_files,
    load_jsonl,
    normalize_answer_spec,
    render_assistant_content,
    write_jsonl,
)


@dataclass
class EncodedSample:
    input_ids: List[int]
    attention_mask: List[int]
    labels: List[int]


class SupervisedDataset:
    def __init__(self, samples: List[EncodedSample]) -> None:
        self.samples = samples

    def __len__(self) -> int:
        return len(self.samples)

    def __getitem__(self, idx: int) -> EncodedSample:
        return self.samples[idx]


class DataCollator:
    def __init__(self, pad_token_id: int) -> None:
        self.pad_token_id = int(pad_token_id)

    def __call__(self, features: List[EncodedSample]) -> Dict[str, Any]:
        max_len = max(len(feature.input_ids) for feature in features)
        input_ids: List[List[int]] = []
        attention_mask: List[List[int]] = []
        labels: List[List[int]] = []
        for feature in features:
            pad_len = max_len - len(feature.input_ids)
            input_ids.append(feature.input_ids + [self.pad_token_id] * pad_len)
            attention_mask.append(feature.attention_mask + [0] * pad_len)
            labels.append(feature.labels + [-100] * pad_len)
        return {
            "input_ids": torch.tensor(input_ids, dtype=torch.long),
            "attention_mask": torch.tensor(attention_mask, dtype=torch.long),
            "labels": torch.tensor(labels, dtype=torch.long),
        }


def pick_device(torch_module: Any) -> str:
    if torch_module.cuda.is_available():
        return "cuda"
    if hasattr(torch_module, "npu"):
        try:
            if torch_module.npu.is_available():
                return "npu"
        except Exception:
            pass
    return "cpu"


def resolve_torch_dtype(torch_module: Any, precision: str, device: str) -> Any:
    if device == "cpu":
        return torch_module.float32
    if precision == "fp16":
        return torch_module.float16
    if precision == "bf16":
        return torch_module.bfloat16
    return torch_module.float32


def reset_peak_device_memory(torch_module: Any, device: str) -> None:
    try:
        if device == "cuda" and torch_module.cuda.is_available():
            torch_module.cuda.reset_peak_memory_stats()
        elif device == "npu" and hasattr(torch_module, "npu"):
            torch_module.npu.reset_peak_memory_stats()
    except Exception:
        pass


def read_peak_device_memory_mib(torch_module: Any, device: str) -> int | None:
    try:
        if device == "cuda" and torch_module.cuda.is_available():
            return int(torch_module.cuda.max_memory_allocated() / (1024 * 1024))
        if device == "npu" and hasattr(torch_module, "npu"):
            return int(torch_module.npu.max_memory_allocated() / (1024 * 1024))
    except Exception:
        return None
    return None


def read_env_int(name: str, default: int, *, minimum: int | None = None, maximum: int | None = None) -> int:
    raw = os.environ.get(name)
    if raw is None or not raw.strip():
        value = int(default)
    else:
        value = int(raw)
    if minimum is not None:
        value = max(minimum, value)
    if maximum is not None:
        value = min(maximum, value)
    return value


def read_env_float(name: str, default: float) -> float:
    raw = os.environ.get(name)
    if raw is None or not raw.strip():
        return float(default)
    return float(raw)


def read_env_bool(name: str, default: bool) -> bool:
    raw = os.environ.get(name)
    if raw is None or not raw.strip():
        return bool(default)
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def build_verified_runtime_defaults() -> Tuple[int, int, int, int, int, Path]:
    # TODO-1:
    # 返回已验证的默认训练超参数。
    raise NotImplementedError("TODO-1: build_verified_runtime_defaults")


def resolve_default_model_path() -> str:
    explicit = os.environ.get("T2_MODEL_PATH", "").strip()
    if explicit:
        return explicit
    model_name = "Qwen3-0.6B"
    task_dir = Path(__file__).resolve().parent
    qwen_root = os.environ.get("QWEN_ROOT", "").strip()
    roots = [Path(qwen_root).expanduser()] if qwen_root else []
    roots.extend([task_dir / "../../../Qwen", task_dir / "../../Qwen", task_dir / "../Qwen"])
    for root in roots:
        candidate = (root / model_name).resolve()
        if candidate.exists():
            return str(candidate)
    return model_name


def build_optimizer_and_scheduler(
    model: Any,
    learning_rate: float,
    weight_decay: float,
    torch_module: Any,
    lr_lambda: Any,
) -> Tuple[Any, Any]:
    # TODO-2:
    # 构造 AdamW optimizer 与 LambdaLR scheduler。
    raise NotImplementedError("TODO-2: build_optimizer_and_scheduler")


def forward_backward_training_step(
    model: Any,
    batch: Dict[str, Any],
    grad_accum: int,
    autocast_context: Any,
    scaler: Any,
) -> float:
    # TODO-3:
    # 完成一次 forward / backward 训练步。
    raise NotImplementedError("TODO-3: forward_backward_training_step")


def build_training_config() -> Dict[str, Any]:
    """
    返回一份可直接参考的 full fine-tuning 配置。

    这里不作为评分点，目的是把样板代码提前搭好，让考生只需要补少量训练主逻辑。
    """
    model_path = resolve_default_model_path()
    (
        default_batch_size,
        default_grad_accum,
        default_num_train_epochs,
        default_max_seq_length,
        default_save_every_epochs,
        checkpoint_root,
    ) = build_verified_runtime_defaults()
    checkpoint_dir = os.environ.get("T2_CHECKPOINT_DIR", str(checkpoint_root)).strip()
    final_model_dir = os.environ.get("T2_FINAL_MODEL_DIR", str(checkpoint_root / "final_model")).strip()
    return {
        "base_model": REQUIRED_BASE_MODEL,
        "fine_tuning_type": REQUIRED_FINE_TUNING_TYPE,
        "model_path": model_path,
        "artifact_dir": f"artifacts/{FIXED_MODEL_RELATIVE_PATH}",
        "sft_train_file": "artifacts/tool_agent_sft_train.jsonl",
        "per_device_train_batch_size": read_env_int("T2_BATCH_SIZE", default_batch_size, minimum=1),
        "gradient_accumulation_steps": read_env_int("T2_GRAD_ACCUM", default_grad_accum, minimum=1),
        "learning_rate": read_env_float("T2_LEARNING_RATE", 2e-5),
        "num_train_epochs": read_env_int("T2_NUM_EPOCHS", default_num_train_epochs, minimum=1, maximum=20),
        "max_seq_length": read_env_int("T2_MAX_SEQ_LENGTH", default_max_seq_length, minimum=64),
        "weight_decay": read_env_float("T2_WEIGHT_DECAY", 0.01),
        "warmup_ratio": read_env_float("T2_WARMUP_RATIO", 0.03),
        "precision": os.environ.get("T2_PRECISION", "bf16").strip() or "bf16",
        "gradient_checkpointing": read_env_bool("T2_ENABLE_GRADIENT_CHECKPOINTING", True),
        "log_interval": read_env_int("T2_LOG_INTERVAL", 5, minimum=1),
        "max_grad_norm": read_env_float("T2_MAX_GRAD_NORM", 1.0),
        "target_loss": read_env_float("T2_TARGET_LOSS", 0.001),
        "seed": read_env_int("T2_SEED", 20260416),
        "save_every_epochs": read_env_int("T2_SAVE_EVERY_EPOCHS", default_save_every_epochs, minimum=0, maximum=20),
        "checkpoint_dir": checkpoint_dir,
        "final_model_dir": final_model_dir,
        "empty_cache_every_step": read_env_bool("T2_EMPTY_CACHE_EVERY_STEP", True),
        "notes": "固定使用 Qwen3-0.6B 做 full fine-tuning，默认参数为 bs=4、grad_accum=4、effective_bs=16、epoch=20、max_seq_length=1024、每 2 轮保存一次，目标显存<=22GiB、target_loss<=0.001。",
    }


def build_sft_rows(train_rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    将原始训练集转换为标准 SFT messages。

    这一步不作为考点，官方已经帮你接好：
    1. 固定 system prompt
    2. user query
    3. assistant 的一个或多个 <tool_call>...</tool_call>
    """
    rows: List[Dict[str, Any]] = []
    for row in train_rows:
        query = str(row.get("query", "")).strip()
        answer_spec = normalize_answer_spec(row)
        if not query or answer_spec is None:
            continue
        rows.append(
            {
                "messages": [
                    {"role": "system", "content": TOOL_AGENT_SYSTEM_PROMPT},
                    {"role": "user", "content": query},
                    {
                        "role": "assistant",
                        "content": render_assistant_content(
                            answer_spec["tool_calls"],
                            dispatch_message=answer_spec.get("dispatch_message", ""),
                        ),
                    },
                ]
            }
        )
    return rows


def render_messages(tokenizer: Any, messages: List[Dict[str, str]], add_generation_prompt: bool) -> str:
    """
    用 Qwen3 官方 chat template 渲染训练文本。

    这里必须使用 `apply_chat_template(..., tools=QWEN_TOOLS)`，
    不能退回到手工字符串拼接。
    """
    if not hasattr(tokenizer, "apply_chat_template"):
        raise TypeError("Qwen3 tokenizer 必须提供 apply_chat_template，不能退回到手工字符串拼接。")
    return tokenizer.apply_chat_template(
        messages,
        tools=QWEN_TOOLS,
        tokenize=False,
        add_generation_prompt=add_generation_prompt,
        enable_thinking=False,
    )


def load_qwen_components(config: Dict[str, Any]) -> Tuple[Any, Any]:
    """
    加载 tokenizer 和 model。

    目标：
    1. 用 `AutoTokenizer.from_pretrained(config["model_path"], trust_remote_code=True)` 加载 tokenizer
    2. 用 `AutoModelForCausalLM.from_pretrained(...)` 加载 Qwen3-0.6B
    3. 如 pad_token_id 为空，可将 pad_token 对齐到 eos_token
    4. 如果配置要求，可开启 gradient checkpointing

    返回：
    - tokenizer
    - model
    """
    from transformers import AutoModelForCausalLM, AutoTokenizer

    model_path = str(config["model_path"])
    precision = str(config.get("precision", "bf16"))
    gradient_checkpointing = bool(config.get("gradient_checkpointing", True))

    tokenizer = AutoTokenizer.from_pretrained(model_path, trust_remote_code=True)
    if tokenizer.pad_token_id is None:
        tokenizer.pad_token = tokenizer.eos_token

    device = pick_device(torch)
    torch_dtype = resolve_torch_dtype(torch, precision, device)
    model = AutoModelForCausalLM.from_pretrained(
        model_path,
        trust_remote_code=True,
        torch_dtype=torch_dtype,
    )
    if gradient_checkpointing:
        model.gradient_checkpointing_enable()
    model.config.use_cache = False
    model = model.to(device)
    model.train()
    return tokenizer, model


def build_supervised_dataset(sft_rows: List[Dict[str, Any]], tokenizer: Any, max_length: int) -> List[EncodedSample]:
    """
    把 SFT messages 编码成监督训练样本。

    推荐流程：
    1. 对每条样本取 `messages[:-1]` 作为 prompt，完整 `messages` 作为 full conversation
    2. 分别调用 `render_messages(tokenizer, ..., add_generation_prompt=True/False)` 得到 prompt_text 和 full_text
    3. 用 tokenizer 编码成 `input_ids`
    4. 构造 `labels` 时，把 prompt 部分全部置为 `-100`，只监督 assistant 输出段
    5. 返回 `List[EncodedSample]`

    这一步的关键，是让模型只学习 assistant 的 tool-call 输出，而不是回归整段 prompt。
    """
    rows: List[EncodedSample] = []
    eos = tokenizer.eos_token or ""
    for sample in sft_rows:
        messages = sample.get("messages")
        if not isinstance(messages, list) or len(messages) < 3:
            continue

        prompt_messages = messages[:-1]
        full_text = render_messages(tokenizer, messages, add_generation_prompt=False)
        prompt_text = render_messages(tokenizer, prompt_messages, add_generation_prompt=True)
        if eos and not full_text.endswith(eos):
            full_text = full_text + eos

        full_ids = tokenizer(
            full_text,
            add_special_tokens=False,
            truncation=True,
            max_length=max_length,
        )["input_ids"]
        prompt_ids = tokenizer(
            prompt_text,
            add_special_tokens=False,
            truncation=True,
            max_length=max_length,
        )["input_ids"]
        if not full_ids:
            continue

        labels = list(full_ids)
        prompt_len = min(len(prompt_ids), len(labels))
        if prompt_len >= len(labels):
            continue
        for idx in range(prompt_len):
            labels[idx] = -100

        rows.append(
            EncodedSample(
                input_ids=list(full_ids),
                attention_mask=[1] * len(full_ids),
                labels=labels,
            )
        )
    return rows


def run_full_finetuning(
    model: Any,
    tokenizer: Any,
    dataset: List[EncodedSample],
    config: Dict[str, Any],
) -> Dict[str, Any]:
    """
    执行 full fine-tuning 训练循环。

    本函数是官方已经接好的训练主流程，不是考生填空点。
    考生只需要补全 TODO-1 / TODO-2 / TODO-3 对应的三个小函数。

    要求：
    - 只能做 full fine-tuning，不要 LoRA、不要冻结层
    - 训练完成后，不在这里保存模型；保存步骤统一放到 `save_model_artifacts`
    """
    pad_token_id = int(config["_pad_token_id"])
    batch_size = int(config.get("per_device_train_batch_size", 1))
    grad_accum = max(1, int(config.get("gradient_accumulation_steps", 1)))
    num_train_epochs = max(1, int(config.get("num_train_epochs", 1)))
    learning_rate = float(config.get("learning_rate", 2e-5))
    weight_decay = float(config.get("weight_decay", 0.01))
    warmup_ratio = float(config.get("warmup_ratio", 0.03))
    precision = str(config.get("precision", "bf16"))
    log_interval = max(1, int(config.get("log_interval", 10)))
    max_grad_norm = float(config.get("max_grad_norm", 1.0))
    target_loss = float(config.get("target_loss", 0.001))

    dataset_obj = SupervisedDataset(dataset)
    dataloader = DataLoader(
        dataset_obj,
        batch_size=batch_size,
        shuffle=True,
        collate_fn=DataCollator(pad_token_id=pad_token_id),
        drop_last=False,
    )

    total_update_steps = max(1, math.ceil(len(dataloader) / grad_accum) * num_train_epochs)
    warmup_steps = int(total_update_steps * warmup_ratio)

    def lr_lambda(step: int) -> float:
        if warmup_steps > 0 and step < warmup_steps:
            return float(step + 1) / float(warmup_steps)
        remain = max(1, total_update_steps - warmup_steps)
        progress = float(max(0, step - warmup_steps)) / float(remain)
        return max(0.0, 1.0 - progress)

    optimizer, scheduler = build_optimizer_and_scheduler(
        model=model,
        learning_rate=learning_rate,
        weight_decay=weight_decay,
        torch_module=torch,
        lr_lambda=lr_lambda,
    )
    device = str(next(model.parameters()).device).split(":")[0]
    model_device = next(model.parameters()).device
    use_autocast = device in {"cuda", "npu"} and precision in {"bf16", "fp16"}
    amp_dtype = torch.bfloat16 if precision == "bf16" else torch.float16
    scaler = torch.cuda.amp.GradScaler(enabled=(device == "cuda" and precision == "fp16"))
    save_every_epochs = max(0, int(config.get("save_every_epochs", 0)))
    checkpoint_dir = Path(str(config.get("checkpoint_dir", MODEL_DIR.parent / "checkpoints")))
    empty_cache_every_step = bool(config.get("empty_cache_every_step", False))
    checkpoint_dirs: List[str] = []

    optimizer.zero_grad(set_to_none=True)
    global_step = 0
    optimizer_steps = 0
    loss_sum = 0.0
    loss_count = 0
    best_epoch_loss = float("inf")
    target_loss_reached = False
    peak_device_mem_mib = 0

    seed = int(config.get("seed", 20260416))
    random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    reset_peak_device_memory(torch, device)

    print(
        f"[train_config] batch={batch_size} grad_accum={grad_accum} "
        f"effective_batch={batch_size * grad_accum} epochs={num_train_epochs} "
        f"target_loss={target_loss:.4f}"
    )

    for epoch in range(num_train_epochs):
        epoch_loss_sum = 0.0
        epoch_loss_count = 0
        for step, batch in enumerate(dataloader, start=1):
            global_step += 1
            batch = {key: value.to(model_device) for key, value in batch.items()}

            autocast_context = (
                torch.autocast(device_type=device, dtype=amp_dtype)
                if use_autocast
                else nullcontext()
            )
            loss_value = forward_backward_training_step(
                model=model,
                batch=batch,
                grad_accum=grad_accum,
                autocast_context=autocast_context,
                scaler=scaler,
            )
            loss_sum += loss_value
            loss_count += 1
            epoch_loss_sum += loss_value
            epoch_loss_count += 1
            current_peak_mib = read_peak_device_memory_mib(torch, device)
            if current_peak_mib is not None:
                peak_device_mem_mib = max(peak_device_mem_mib, current_peak_mib)

            should_step = step % grad_accum == 0 or step == len(dataloader)
            if not should_step:
                continue

            if scaler.is_enabled():
                scaler.unscale_(optimizer)
                torch.nn.utils.clip_grad_norm_(model.parameters(), max_grad_norm)
                scaler.step(optimizer)
                scaler.update()
            else:
                torch.nn.utils.clip_grad_norm_(model.parameters(), max_grad_norm)
                optimizer.step()
            scheduler.step()
            optimizer.zero_grad(set_to_none=True)
            optimizer_steps += 1
            if empty_cache_every_step and device == "npu" and hasattr(torch, "npu"):
                try:
                    torch.npu.empty_cache()
                except Exception:
                    pass

            if optimizer_steps % log_interval == 0:
                avg_loss = loss_sum / max(1, loss_count)
                print(
                    f"[train] epoch={epoch + 1}/{num_train_epochs} "
                    f"step={optimizer_steps}/{total_update_steps} "
                    f"loss={avg_loss:.4f} lr={scheduler.get_last_lr()[0]:.8f} "
                    f"peak_mem_mib={peak_device_mem_mib}"
                )

        epoch_avg_loss = epoch_loss_sum / max(1, epoch_loss_count)
        best_epoch_loss = min(best_epoch_loss, epoch_avg_loss)
        print(
            f"[epoch] epoch={epoch + 1}/{num_train_epochs} "
            f"avg_loss={epoch_avg_loss:.4f} optimizer_steps={optimizer_steps}"
        )
        if epoch_avg_loss <= target_loss and not target_loss_reached:
            target_loss_reached = True
            print(f"[target_loss] reached epoch={epoch + 1} avg_loss={epoch_avg_loss:.4f}")

        if save_every_epochs > 0 and (epoch + 1) % save_every_epochs == 0:
            checkpoint_path = checkpoint_dir / f"epoch-{epoch + 1:03d}"
            save_model_artifacts(model=model, tokenizer=tokenizer, output_dir=checkpoint_path)
            checkpoint_dirs.append(str(checkpoint_path))
            print(f"[checkpoint] saved {checkpoint_path}")
            model.train()
            if device == "npu" and hasattr(torch, "npu"):
                try:
                    torch.npu.empty_cache()
                except Exception:
                    pass

    return {
        "global_steps": global_step,
        "optimizer_steps": optimizer_steps,
        "avg_loss": round(loss_sum / max(1, loss_count), 6),
        "best_epoch_loss": round(best_epoch_loss, 6),
        "target_loss": target_loss,
        "target_loss_reached": target_loss_reached,
        "device": device,
        "precision": precision,
        "peak_device_mem_mib": peak_device_mem_mib,
        "checkpoint_dirs": checkpoint_dirs,
    }


def save_model_artifacts(model: Any, tokenizer: Any, output_dir: Path | None = None) -> None:
    """
    训练完成后，把完整模型目录写到目标目录。

    默认保存到 `config["final_model_dir"]` 指定的位置；如需提交评测，可再复制到 `artifacts/model/`。
    """
    target_dir = MODEL_DIR if output_dir is None else Path(output_dir)
    target_dir.mkdir(parents=True, exist_ok=True)
    model.save_pretrained(target_dir, safe_serialization=True)
    tokenizer.save_pretrained(target_dir)


def list_output_files(base_dir: Path) -> List[str]:
    if not base_dir.exists():
        return []
    files: List[str] = []
    for path in base_dir.rglob("*"):
        if path.is_file():
            files.append(str(path.relative_to(base_dir)).replace("\\", "/"))
    return sorted(files)


def train_tool_agent_model(train_rows: List[Dict[str, Any]], config: Dict[str, Any]) -> Dict[str, Any]:
    """
    整个训练流程如下：

    1. 校验固定基座模型和训练方式
    2. 把原始训练集转换为 SFT messages，并写出到 `artifacts/tool_agent_sft_train.jsonl`
    3. 加载 Qwen3-0.6B 的 tokenizer / model
    4. 用 Qwen3 官方 chat template + tools schema 渲染每条样本
    5. 把渲染后的文本编码成监督训练样本，并屏蔽 prompt 段 labels
    6. 执行 full fine-tuning 训练
    7. 把完整模型目录保存到配置中的默认输出目录

    """
    if str(config.get("base_model")) != REQUIRED_BASE_MODEL:
        raise ValueError(f"base_model 必须为 {REQUIRED_BASE_MODEL}")
    if str(config.get("fine_tuning_type")) != REQUIRED_FINE_TUNING_TYPE:
        raise ValueError(f"fine_tuning_type 必须为 {REQUIRED_FINE_TUNING_TYPE}")

    # Step 1. 先把原始训练集规范化成标准 SFT messages，并落盘成提交产物。
    sft_rows = build_sft_rows(train_rows)
    if not sft_rows:
        raise ValueError("无法从训练集构造合法的 SFT 数据")
    write_jsonl(SFT_DATA_PATH, sft_rows)

    # Step 2. 加载 Qwen3 tokenizer / model。
    tokenizer, model = load_qwen_components(config)
    config = dict(config)
    config["_pad_token_id"] = int(tokenizer.pad_token_id)

    # Step 3. 把 messages 渲染并编码成监督训练样本。
    dataset = build_supervised_dataset(
        sft_rows=sft_rows,
        tokenizer=tokenizer,
        max_length=int(config.get("max_seq_length", 1024)),
    )
    if not dataset:
        raise ValueError("监督训练样本为空，无法开始训练")

    # Step 4. 执行 full fine-tuning。
    train_summary = run_full_finetuning(model=model, tokenizer=tokenizer, dataset=dataset, config=config)

    # Step 5. 统一保存完整模型目录。
    final_model_dir = Path(str(config.get("final_model_dir", MODEL_DIR)))
    save_model_artifacts(model=model, tokenizer=tokenizer, output_dir=final_model_dir)

    return {
        "base_model": REQUIRED_BASE_MODEL,
        "fine_tuning_type": REQUIRED_FINE_TUNING_TYPE,
        "model_type": "qwen3_fullft_tool_agent",
        "train_size": len(train_rows),
        "sft_train_size": len(sft_rows),
        "artifact_dir": str(final_model_dir),
        "artifact_files": list_output_files(final_model_dir),
        **train_summary,
    }


def main() -> None:
    train_rows = load_jsonl(TRAIN_DATA_PATH)
    if not train_rows:
        raise FileNotFoundError(
            f"未找到训练数据: {TRAIN_DATA_PATH}。"
            "请先参考 T0/T1 的 Prompt 方法，自行准备 artifacts/tool_agent_train.jsonl。"
        )

    config = build_training_config()
    summary = train_tool_agent_model(train_rows, config)
    final_model_dir = Path(str(config.get("final_model_dir", MODEL_DIR)))

    print("=" * 64)
    print("T2 训练产物已写出")
    print("=" * 64)
    print(f"base model: {REQUIRED_BASE_MODEL}")
    print(f"fine tuning type: {REQUIRED_FINE_TUNING_TYPE}")
    print(f"model dir: {final_model_dir}")
    print(f"sft train file: {SFT_DATA_PATH}")
    print(f"train summary: {json.dumps(summary, ensure_ascii=False)}")


if __name__ == "__main__":
    main()
