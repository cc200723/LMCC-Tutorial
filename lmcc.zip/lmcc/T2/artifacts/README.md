# T2 训练产物目录

提交 `T2` 时，本目录至少应包含：

1. `tool_agent_train.jsonl`
2. `tool_agent_sft_train.jsonl`
3. `model/`

推荐流程：

```bash
python T2/train_tool_agent.py
python T2/evaluate.py
```

说明：

1. 本题不提供独立的数据合成脚本；`tool_agent_train.jsonl` 需要考生参考 `T0/T1` 的 Prompt 扩写方式自行准备，并包含 `answer_json`
   当前目录里提供的 `tool_agent_train.jsonl` / `tool_agent_sft_train.jsonl` 只有各 `1` 条样例，只用于说明格式
2. 本题固定基座模型是 `Qwen3-0.6B`
3. 本题固定训练方式是 `full fine-tuning`
4. `train_tool_agent.py` 是官方给出的部分训练骨架，只需要补齐少量训练主逻辑，不单独计分
5. `tool_agent_sft_train.jsonl` 需要使用真实 Qwen 工具调用模板；assistant 内容应为一个或多个 `<tool_call>...</tool_call>`，并且每个调用都要带有与 `arguments` 同级的 `wait_for_result`
   这和传统单工具路由不同：本题会评测一个请求内的多个并行调用，以及哪些调用可以直接发射、哪些调用必须等待结果；这些策略不会在 query 中直接明说
   固定等待策略已在题面公开：`weather / translation / stock_quote` 默认 `wait_for_result=false`，其余工具默认 `true`
   真实系统里 `wait_for_result` 往往也和 query / workflow 相关；但本题为了化简，统一把它固定绑定到工具类型
6. `model/` 是唯一允许提交、且正式评测真正会加载的完整模型目录
7. 目录内文件结构应与原始 `Qwen3-0.6B` 的 `save_pretrained()` 输出保持一致
8. 评测器会检查 SFT 数据格式、并行样本占比、混合等待策略样本占比，并结合 `Qwen3-Embedding-0.6B` 评估语义多样性
9. 如果评测器没有检测到完整模型目录，模型性能评测环节会被跳过
10. 如果 `tool_agent_train.jsonl` 或 `tool_agent_sft_train.jsonl` 最终仍然只包含 `1` 条数据，A 项直接记 `0` 分
11. 赛后复现满分时，请把本目录下的 `tool_agent_train.0.43.jsonl` 复制为 `tool_agent_train.jsonl`，把 `tool_agent_sft_train.0.43.jsonl` 复制为 `tool_agent_sft_train.jsonl`，再运行 `python T2/evaluate.py`，A 项即可复现 `10/10`
