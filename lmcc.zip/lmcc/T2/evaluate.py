# -*- coding: utf-8 -*-
"""
T2 正式评测：星港总调度官养成计划（真实训练版）

总分 30：
A. 数据分布和多样性 10
B. 公开集模型性能 12（每题 1 分）
C. 隐藏集模型性能 8（每题 1 分）

本文件是出题方评测入口，负责同时检查两类提交内容：
1. 训练数据：考生需要提交普通训练数据和 SFT 数据，A 项会检查数据数量、格式、
   工具覆盖、并行工具调用、wait_for_result 标注以及 query 的语义多样性。
2. 训练产物：考生需要把训练后的 Qwen3-0.6B 模型放到固定目录，B/C 项会加载该
   模型，对公开/隐藏 query 做真实推理，并严格比较工具名、等待策略和参数。

评测流程概览：
1. 尽早限制 BLAS / torch 线程，避免评测机器上因为线程数过大导致不稳定。
2. 读取提交的数据文件，并计算 A 项数据质量分。
3. 探测 CUDA / NPU / CPU 环境，加载固定目录下的微调模型。
4. 若模型缺失，则 B/C 项跳过并记 0；若模型可加载，则逐条评测公开集和隐藏集。
5. 将分数与细节写入统一的 result_store，供平台汇总展示。
"""

from __future__ import annotations

import warnings

# Ascend/NPU 环境中，torch_npu 导入时可能打印 toolkit owner 不匹配的 UserWarning。
# 这个 warning 与考生模型行为无关，会污染评测日志，因此在真正导入 torch/torch_npu
# 之前先屏蔽掉这一类已知噪声。
warnings.filterwarnings(
    "ignore",
    message=r"Warning: The /usr/local/Ascend/ascend-toolkit/.* owner does not match the current owner\.",
    category=UserWarning,
)

import os
import sys
from pathlib import Path
from typing import Any, Dict, List, Tuple


MAX_BLAS_THREADS = 64
THREAD_ENV_VARS = (
    "OPENBLAS_NUM_THREADS",
    "OMP_NUM_THREADS",
    "MKL_NUM_THREADS",
    "NUMEXPR_NUM_THREADS",
)


def configure_runtime_environment(max_threads: int = MAX_BLAS_THREADS) -> Dict[str, str]:
    """限制底层数值库线程数，降低评测时的资源抖动。

    训练/评测脚本会同时用到 transformers、torch、numpy 以及 embedding 模型。
    这些库底层可能调用 OpenBLAS / MKL / OpenMP。如果不限制线程，在共享机器或
    NPU 容器中可能出现 CPU 线程暴涨、进程退出码 139、或清理阶段 warning。

    这里采用保守策略：如果用户已经设置了一个合理的正数且不超过 max_threads，
    就尊重原设置；否则写入 max_threads。返回值只记录本函数实际覆盖的变量，便于
    评测详情里排查环境问题。
    """
    applied: Dict[str, str] = {}
    target = str(max_threads)
    for name in THREAD_ENV_VARS:
        raw = os.environ.get(name)
        try:
            value = int(raw) if raw is not None else None
        except (TypeError, ValueError):
            value = None
        if value is None or value <= 0 or value > max_threads:
            os.environ[name] = target
            applied[name] = target
    os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
    return applied


# 必须在导入 transformers / torch 重型组件前执行线程限制。
RUNTIME_THREAD_LIMITS = configure_runtime_environment()

# ROOT 指向 lmcc 根目录，用于导入 result_store；TASK_DIR 指向当前 T2 目录，
# 用于导入 tool_agent_common。评测平台可能从不同工作目录启动 evaluate.py，
# 因此这里显式把两个目录加入 sys.path，避免依赖当前 shell 的 cwd。
ROOT = Path(__file__).resolve().parents[1]
TASK_DIR = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
if str(TASK_DIR) not in sys.path:
    sys.path.insert(0, str(TASK_DIR))

from result_store import update_results
from tool_agent_common import (
    ALLOWED_TOOLS,
    FIXED_MODEL_RELATIVE_PATH,
    HIDDEN_EVAL_PATH,
    MODEL_DIR,
    PUBLIC_EVAL_PATH,
    QWEN_TOOLS,
    REQUIRED_BASE_MODEL,
    REQUIRED_FINE_TUNING_TYPE,
    TOOL_AGENT_SYSTEM_PROMPT,
    SFT_DATA_PATH,
    TRAIN_DATA_PATH,
    calls_satisfy_expected,
    load_jsonl,
    model_dir_ready,
    normalize_tool_agent_row,
    parse_assistant_output,
    tool_multiset_match,
    tool_wait_match,
)


# 三个评分部分的满分值。TOTAL_FULL 只用于最终汇总，A/B/C 的计算彼此独立。
A_FULL = 10.0
B_PUBLIC_FULL = 12.0
C_HIDDEN_FULL = 8.0
TOTAL_FULL = A_FULL + B_PUBLIC_FULL + C_HIDDEN_FULL

# A 项期望的合成数据规模。超过 100 条不会因为数量项继续加分，但仍可能通过
# 多样性、工具覆盖等指标影响其它子项。
TARGET_SYNTH_SIZE = 100

def resolve_qwen_model_path(env_var: str, model_name: str) -> str:
    explicit = os.environ.get(env_var, "").strip()
    if explicit:
        return explicit
    qwen_root = os.environ.get("QWEN_ROOT", "").strip()
    roots = [Path(qwen_root).expanduser()] if qwen_root else []
    roots.extend([ROOT.parent.parent / "Qwen", ROOT.parent / "Qwen", ROOT / "Qwen"])
    for root in roots:
        candidate = root / model_name
        if candidate.exists():
            return str(candidate)
    return model_name


# 语义多样性使用 embedding 模型估计 query 是否聚成过少的语义簇。允许用环境变量
# 覆盖路径，方便在不同远程机器上切换模型缓存位置。
DEFAULT_EMBEDDING_MODEL_PATH = resolve_qwen_model_path(
    "T2_EMBEDDING_MODEL_PATH",
    "Qwen3-Embedding-0.6B",
)

# B/C 项中每条 query 的最大生成长度。工具调用输出应很短，256 足以容纳多工具调用，
# 同时避免模型异常长输出拖慢整轮评测。
MAX_NEW_TOKENS = 256

# 设备探测结果会被多处使用。缓存它可以避免反复 import torch_npu 或重复初始化设备。
_RUNTIME_DEVICE_INFO: Dict[str, Any] | None = None


def wait_params_present(tool_calls: List[Dict[str, Any]]) -> bool:
    """检查每个工具调用是否显式带有 wait_for_result 字段。

    本题考察点之一是模型不仅要选对工具，还要判断调用后是否需要等待结果。
    parse_assistant_output 会把这个字段解析为 has_wait_param；只要有一个工具调用
    没有显式标注，格式就不算完整。
    """
    return bool(tool_calls) and all(bool(call.get("has_wait_param")) for call in tool_calls)


def mixed_wait_policies(tool_calls: List[Dict[str, Any]]) -> bool:
    """判断一条样本中是否同时包含等待和不等待的工具调用。"""
    policies = {str(call.get("wait_policy", "")).strip() for call in tool_calls}
    return "wait" in policies and "no_wait" in policies


def build_skipped_eval_detail(reason: str) -> Dict[str, Any]:
    """构造 B/C 项跳过时的统一详情。

    模型目录缺失时不能进行真实推理，但评测仍应完成 A 项并写回结果。因此 B/C 项
    统一返回 skipped=True，而不是抛出异常中断整份评测。
    """
    return {"skipped": True, "reason": reason, "score": 0.0}


def probe_runtime_device() -> Dict[str, Any]:
    """探测当前评测环境可用设备，并记录足够详细的诊断信息。

    设备优先级是 CUDA > NPU > CPU。虽然当前题目主要在 H200/NPU 机器上运行，
    但本地自测或其它平台可能只有 CPU/CUDA，因此这里不硬编码设备。

    返回 detail 字典而不是只返回字符串，是为了在结果详情里暴露：
    - torch 是否能导入；
    - torch_npu 是否导入成功；
    - cuda/npu 是否可用；
    - 线程限制是否成功设置。
    这些信息能帮助区分“模型答错”和“运行环境没有正确加载”的问题。
    """
    global _RUNTIME_DEVICE_INFO
    if _RUNTIME_DEVICE_INFO is not None:
        return dict(_RUNTIME_DEVICE_INFO)

    detail: Dict[str, Any] = {
        "device": "cpu",
        "torch_import_ok": False,
        "torch_npu_imported": False,
        "cuda_available": False,
        "npu_available": False,
    }

    try:
        import torch
    except Exception as exc:
        detail["torch_error"] = str(exc)
        _RUNTIME_DEVICE_INFO = detail
        return dict(detail)

    detail["torch_import_ok"] = True

    # CUDA 查询在 CPU-only 环境通常安全，但仍用 try 包住，避免某些定制 torch 构建
    # 因驱动/动态库问题抛异常。
    try:
        detail["cuda_available"] = bool(torch.cuda.is_available())
    except Exception as exc:
        detail["cuda_error"] = str(exc)

    # torch 自身也会启用线程池。这里与环境变量限制保持一致，进一步降低 CPU 抖动。
    try:
        torch.set_num_threads(MAX_BLAS_THREADS)
        detail["torch_num_threads"] = int(torch.get_num_threads())
    except Exception as exc:
        detail["torch_num_threads_error"] = str(exc)

    # interop 线程通常不需要太大；限制到 16 可以避免多个算子/后端并发时过度抢占。
    try:
        torch.set_num_interop_threads(min(16, MAX_BLAS_THREADS))
        detail["torch_num_interop_threads"] = int(torch.get_num_interop_threads())
    except Exception as exc:
        detail["torch_num_interop_threads_error"] = str(exc)

    # torch_npu 需要显式 import 后，torch 上才可能挂载 npu 后端。导入失败不应中断
    # CPU/CUDA 自测，因此这里只记录错误。
    try:
        import torch_npu  # noqa: F401

        detail["torch_npu_imported"] = True
    except Exception as exc:
        detail["torch_npu_error"] = str(exc)

    if hasattr(torch, "npu"):
        try:
            detail["npu_available"] = bool(torch.npu.is_available())
        except Exception as exc:
            detail["npu_error"] = str(exc)

    # CUDA 优先是为了兼容本地 4090/服务器 GPU 自测；没有 CUDA 时再选择 NPU。
    if detail["cuda_available"]:
        detail["device"] = "cuda"
    elif detail["npu_available"]:
        detail["device"] = "npu"

    _RUNTIME_DEVICE_INFO = detail
    return dict(detail)


def pick_device() -> str:
    """返回模型加载/推理应使用的设备名。"""
    return str(probe_runtime_device().get("device", "cpu"))


def score_sft_format(sft_rows: List[Dict[str, Any]]) -> Tuple[float, Dict[str, Any]]:
    """检查 SFT 数据是否能训练出题目要求的 assistant 输出格式。

    SFT 文件每行应是三轮 messages：
    1. system：固定工具调度系统提示；
    2. user：自然语言 query；
    3. assistant：Qwen tool-call 格式的答案。

    本函数只做格式层面的数据质量检查，不比较 query 与工具参数是否完全一致。
    更严格的规范化检查在 normalize_tool_agent_row 和 B/C 推理评分中完成。
    """
    if not sft_rows:
        return 0.0, {
            "valid_ratio": 0.0,
            "valid": 0,
            "total": 0,
            "parallel_valid": 0,
            "mixed_parallel_valid": 0,
        }

    valid = 0
    parallel_valid = 0
    mixed_parallel_valid = 0
    for row in sft_rows:
        messages = row.get("messages")
        # 只接受标准三段式训练样本。多一轮或少一轮都可能导致模型学习到非评测格式。
        if not isinstance(messages, list) or len(messages) != 3:
            continue
        if messages[0].get("role") != "system" or messages[1].get("role") != "user" or messages[2].get("role") != "assistant":
            continue
        # assistant 内容必须能被题目 parser 解析成工具调用；普通自然语言答案不计入有效。
        parsed = parse_assistant_output(messages[2].get("content", ""))
        if not parsed["parse_ok"] or not parsed["tool_calls"]:
            continue
        if not wait_params_present(parsed["tool_calls"]):
            continue
        valid += 1
        if len(parsed["tool_calls"]) > 1:
            parallel_valid += 1
            mixed_parallel_valid += int(mixed_wait_policies(parsed["tool_calls"]))

    ratio = valid / max(1, len(sft_rows))
    return ratio, {
        "valid_ratio": round(ratio, 4),
        "valid": valid,
        "total": len(sft_rows),
        "parallel_valid": parallel_valid,
        "mixed_parallel_valid": mixed_parallel_valid,
    }


def semantic_cluster_ratio(
    queries: List[str],
    model_name: str,
    max_samples: int = 128,
    batch_size: int = 32,
) -> Tuple[float | None, Dict[str, Any]]:
    """估计 query 的语义多样性。

    指标含义：
    - 先用 embedding 模型把每条 query 编码为向量；
    - 再用一个简单的在线聚类过程，把相似度 >= 0.88 的 query 归入同一语义簇；
    - semantic_cluster_ratio = 语义簇数量 / 样本数量。

    ratio 越高，说明 query 彼此越不像重复改写；ratio 很低则说明数据可能只是同一类
    指令的轻微换皮。这个指标不是最终模型性能评分，而是 A 项中“数据分布和多样性”
    的一个子项。

    失败时返回 (None, detail)，而不是抛异常。这样即使 embedding 模型缺失，评测也能
    给出其它数据质量分，并在 detail 中提示 semantic_error。
    """
    try:
        import torch
        from transformers import AutoModel, AutoTokenizer
    except Exception as exc:
        return None, {"semantic_error": f"import failed: {exc}"}

    # 去掉空 query，并保持原顺序去重。重复 query 本身会在 unique_ratio 中扣分；
    # 语义聚类只看去重后的表达分布，避免完全重复样本主导聚类结果。
    uniq = [str(x).strip() for x in queries if str(x).strip()]
    uniq = list(dict.fromkeys(uniq))
    if not uniq:
        return None, {"semantic_error": "empty query set"}

    # 大数据集最多抽样 max_samples 条做 embedding，保证评测耗时可控。这里使用均匀步长
    # 而不是随机抽样，确保同一份提交每次评测得到稳定结果。
    if max_samples > 0 and len(uniq) > max_samples:
        stride = len(uniq) / float(max_samples)
        sampled = [uniq[min(len(uniq) - 1, int(i * stride))] for i in range(max_samples)]
    else:
        sampled = uniq

    # GPU/NPU 上用 float16 节省显存；CPU 上用 float32 保证兼容性。
    runtime_device = pick_device()
    torch_dtype = torch.float16 if runtime_device in {"cuda", "npu"} else torch.float32

    try:
        tokenizer = AutoTokenizer.from_pretrained(model_name, trust_remote_code=True)
        model = AutoModel.from_pretrained(
            model_name,
            torch_dtype=torch_dtype,
            trust_remote_code=True,
        )
    except Exception as exc:
        return None, {"semantic_error": f"load model failed: {exc}", "semantic_model": model_name}

    model = model.to(runtime_device).eval()

    all_emb = []
    for i in range(0, len(sampled), max(1, batch_size)):
        batch = sampled[i : i + max(1, batch_size)]
        # max_length=128 足够覆盖本题 query；截断过长异常样本，避免单条数据拖慢评测。
        inputs = tokenizer(
            batch,
            padding=True,
            truncation=True,
            max_length=128,
            return_tensors="pt",
        )
        inputs = {k: v.to(runtime_device) for k, v in inputs.items()}
        with torch.no_grad():
            out = model(**inputs)
            hidden = out.last_hidden_state
            attn = inputs["attention_mask"].unsqueeze(-1)
            # 采用 attention-mask mean pooling，避免 padding token 影响句向量。
            pooled = (hidden * attn).sum(dim=1) / attn.sum(dim=1).clamp(min=1)
            # 归一化后，向量点积等价于 cosine similarity，便于后续聚类。
            pooled = pooled / pooled.norm(dim=1, keepdim=True).clamp(min=1e-12)
        all_emb.append(pooled.detach().cpu())

    emb = torch.cat(all_emb, dim=0)
    if emb.shape[0] == 0:
        return None, {"semantic_error": "embedding output empty", "semantic_model": model_name}

    threshold = 0.88
    centers = []
    counts = []
    for i in range(emb.shape[0]):
        vec = emb[i]
        if not centers:
            centers.append(vec)
            counts.append(1)
            continue
        # 在线聚类：把当前 query 放入最相似且超过阈值的簇；否则新开一个簇。
        # 这不是为了得到严格聚类标签，而是为了稳定、快速地估计“有多少种语义表达”。
        sims = torch.stack([torch.dot(vec, c) for c in centers])
        max_sim, idx = torch.max(sims, dim=0)
        j = int(idx.item())
        if float(max_sim.item()) >= threshold:
            center = centers[j]
            n = counts[j]
            # 更新簇中心时做增量平均，再重新归一化，保持中心仍可用 cosine 比较。
            new_center = (center * n + vec) / (n + 1)
            new_center = new_center / new_center.norm().clamp(min=1e-12)
            centers[j] = new_center
            counts[j] = n + 1
        else:
            centers.append(vec)
            counts.append(1)

    ratio = len(centers) / float(emb.shape[0])
    return ratio, {
        "semantic_model": model_name,
        "semantic_device": runtime_device,
        "semantic_samples": int(emb.shape[0]),
        "semantic_clusters": len(centers),
        "semantic_threshold": threshold,
    }


def load_qwen_bundle(model_dir: Path) -> Dict[str, Any]:
    """加载考生提交的固定目录模型。

    评测只接受 HuggingFace/Qwen 兼容目录，不加载训练脚本中的临时 checkpoint 名称。
    这样可以保证考生最终提交的是可直接推理的完整模型产物。
    """
    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer

    device = pick_device()
    torch_dtype = torch.float16 if device in {"cuda", "npu"} else torch.float32

    tokenizer = AutoTokenizer.from_pretrained(model_dir, trust_remote_code=True)
    model = AutoModelForCausalLM.from_pretrained(
        model_dir,
        torch_dtype=torch_dtype,
        trust_remote_code=True,
    )
    model = model.to(device)
    model.eval()

    return {
        "model": model,
        "tokenizer": tokenizer,
        "device": device,
        "model_dir": str(model_dir),
    }


def predict_assistant_output_with_qwen(query: str, bundle: Dict[str, Any]) -> Dict[str, Any]:
    """用提交模型对单条 query 生成工具调用，并解析成统一结构。

    这里复用 Qwen 的 apply_chat_template，并传入官方 tools schema。评测不接受考生
    自定义 prompt 或自定义 schema，因为 B/C 项要衡量的是固定工具协议下的行为。
    enable_thinking=False 是为了让模型直接输出工具调用，避免思考文本干扰 parser。
    """
    import torch

    model = bundle["model"]
    tokenizer = bundle["tokenizer"]
    messages = [
        {"role": "system", "content": TOOL_AGENT_SYSTEM_PROMPT},
        {"role": "user", "content": str(query)},
    ]
    rendered = tokenizer.apply_chat_template(
        messages,
        tools=QWEN_TOOLS,
        tokenize=False,
        add_generation_prompt=True,
        enable_thinking=False,
    )
    inputs = tokenizer(rendered, return_tensors="pt").to(model.device)

    with torch.no_grad():
        # do_sample=False 保证评测确定性；同一模型、同一 query 应得到稳定结果。
        outputs = model.generate(
            **inputs,
            do_sample=False,
            max_new_tokens=MAX_NEW_TOKENS,
            pad_token_id=tokenizer.pad_token_id,
            eos_token_id=tokenizer.eos_token_id,
        )

    # 只截取新增 token，避免把 prompt 本身混入 assistant 输出解析。
    raw = tokenizer.decode(outputs[0][inputs["input_ids"].shape[1] :], skip_special_tokens=False)
    parsed = parse_assistant_output(raw)
    parsed["raw"] = raw
    return parsed


def score_submitted_dataset() -> Tuple[float, Dict[str, Any]]:
    """计算 A 项：数据分布和多样性。

    A 项不是检查模型是否答对，而是检查提交的数据是否足以训练出工具调度能力。
    评分由 8 个子项加权组成：
    - count：训练数据数量是否达到 100 条；
    - valid：普通训练数据能否被规范化为合法工具调用样本；
    - unique：query 是否避免大量完全重复；
    - coverage：是否覆盖全部公开工具；
    - sft_valid：SFT messages 是否符合 Qwen 工具调用训练格式；
    - parallel：是否包含足够的多工具并行样本；
    - mixed_parallel：并行样本中是否覆盖 wait/no_wait 混合策略；
    - semantic_diversity：query 语义簇比例是否足够高。
    """
    detail: Dict[str, Any] = {
        "train_file_exists": TRAIN_DATA_PATH.exists(),
        "sft_file_exists": SFT_DATA_PATH.exists(),
    }

    rows = load_jsonl(TRAIN_DATA_PATH)
    sft_rows = load_jsonl(SFT_DATA_PATH)
    if not rows:
        detail["data_error"] = f"缺少训练数据文件: {TRAIN_DATA_PATH.name}"
        detail["score"] = 0.0
        return 0.0, detail
    if len(rows) <= 1:
        detail["data_error"] = (
            f"{TRAIN_DATA_PATH.name} 只包含 {len(rows)} 条数据。"
            "starter 样例文件不能直接提交；若训练集只包含 1 条数据，A 项记 0 分。"
        )
        detail["score"] = 0.0
        return 0.0, detail
    if len(sft_rows) <= 1:
        detail["data_error"] = (
            f"{SFT_DATA_PATH.name} 只包含 {len(sft_rows)} 条数据。"
            "starter 样例文件不能直接提交；若 SFT 数据只包含 1 条数据，A 项记 0 分。"
        )
        detail["score"] = 0.0
        return 0.0, detail

    total = len(rows)
    valid_rows = 0
    parallel_rows = 0
    mixed_parallel_rows = 0
    unique_queries = set()
    tool_covered = set()
    semantic_queries: List[str] = []

    for row in rows:
        # normalize_tool_agent_row 统一支持参考答案中的 answer_spec 格式和 starter 中
        # 更朴素的 answer_json/wait_tools/no_wait_tools 格式。无法规范化的样本不计有效。
        normalized = normalize_tool_agent_row(row)
        if normalized is None:
            continue
        answer_spec = normalized["answer_spec"]
        valid_rows += 1
        unique_queries.add(normalized["query"])
        tool_covered.update(answer_spec["tool_names"])
        semantic_queries.append(normalized["query"])
        parallel_rows += int(answer_spec["is_parallel"])
        mixed_parallel_rows += int(
            answer_spec["is_parallel"]
            and bool(answer_spec["no_wait_tools"])
            and bool(answer_spec["wait_tools"])
        )

    # 数量项达到 100 条即满，不鼓励单纯堆更多重复数据刷数量分。
    count_ratio = min(1.0, total / TARGET_SYNTH_SIZE)
    valid_ratio = valid_rows / max(1, total)
    uniq_ratio = len(unique_queries) / max(1, valid_rows)
    coverage_ratio = len(tool_covered) / len(ALLOWED_TOOLS)
    parallel_ratio = parallel_rows / max(1, valid_rows)
    mixed_parallel_ratio = mixed_parallel_rows / max(1, valid_rows)
    sft_valid_ratio, sft_detail = score_sft_format(sft_rows)
    semantic_ratio, semantic_detail = semantic_cluster_ratio(semantic_queries, DEFAULT_EMBEDDING_MODEL_PATH)

    # 各子项的满分阈值不是都要求达到 1.0 原始比例。例如 valid_ratio 达到 0.98
    # 即视为格式质量满分，允许极少量噪声；parallel/mixed_parallel 只要求达到合理覆盖。
    valid_component = min(1.0, valid_ratio / 0.98)
    unique_component = min(1.0, uniq_ratio / 0.95)
    sft_component = min(1.0, sft_valid_ratio / 0.98)
    parallel_component = min(1.0, parallel_ratio / 0.25)
    mixed_parallel_component = min(1.0, mixed_parallel_ratio / 0.18)
    semantic_component = 0.0
    if isinstance(semantic_ratio, float):
        semantic_component = min(1.0, semantic_ratio / 0.30)

    # A 项总分采用加权和。权重设计上同时奖励“格式严格”和“数据多样”，避免只靠
    # 某一个维度拿满分。
    score = A_FULL * (
        0.16 * count_ratio
        + 0.14 * valid_component
        + 0.12 * unique_component
        + 0.12 * coverage_ratio
        + 0.12 * sft_component
        + 0.10 * parallel_component
        + 0.08 * mixed_parallel_component
        + 0.16 * semantic_component
    )

    detail.update(
        {
            "count": total,
            "valid_rows": valid_rows,
            "parallel_rows": parallel_rows,
            "mixed_parallel_rows": mixed_parallel_rows,
            "unique_queries": len(unique_queries),
            "tool_covered": sorted(tool_covered),
            "count_ratio": round(count_ratio, 4),
            "valid_ratio": round(valid_ratio, 4),
            "parallel_ratio": round(parallel_ratio, 4),
            "mixed_parallel_ratio": round(mixed_parallel_ratio, 4),
            "unique_ratio": round(uniq_ratio, 4),
            "coverage_ratio": round(coverage_ratio, 4),
            "sft_valid": sft_detail,
            "semantic_cluster_ratio": round(semantic_ratio, 4) if isinstance(semantic_ratio, float) else None,
            "semantic_model": DEFAULT_EMBEDDING_MODEL_PATH,
            "score_breakdown": {
                "count": round(A_FULL * 0.16 * count_ratio, 3),
                "valid": round(A_FULL * 0.14 * valid_component, 3),
                "unique": round(A_FULL * 0.12 * unique_component, 3),
                "coverage": round(A_FULL * 0.12 * coverage_ratio, 3),
                "sft_valid": round(A_FULL * 0.12 * sft_component, 3),
                "parallel": round(A_FULL * 0.10 * parallel_component, 3),
                "mixed_parallel": round(A_FULL * 0.08 * mixed_parallel_component, 3),
                "semantic_diversity": round(A_FULL * 0.16 * semantic_component, 3),
            },
            "score": round(score, 2),
        }
    )
    if semantic_detail:
        detail.update(semantic_detail)
    return round(score, 2), detail


def inspect_submission_artifacts() -> Tuple[Dict[str, Any], Any | None]:
    """检查并加载模型产物，作为 B/C 项前置条件。

    返回两个值：
    - detail：模型目录、设备、线程、探针推理等诊断信息；
    - bundle：成功加载后的 model/tokenizer/device 组合；失败时为 None。

    这里包含一条固定 probe query，目的是在正式逐题评分前快速确认模型是否能：
    1. 正常加载；
    2. 按 Qwen tool-call 格式输出；
    3. 显式标注 wait_for_result；
    4. 对一个简单双工具样例给出合理等待策略。
    probe 失败不会单独扣分，但会写入 detail，帮助定位后续 B/C 项低分原因。
    """
    runtime_info = probe_runtime_device()
    detail: Dict[str, Any] = {
        "required_base_model": REQUIRED_BASE_MODEL,
        "required_fine_tuning_type": REQUIRED_FINE_TUNING_TYPE,
        "expected_model_dir": FIXED_MODEL_RELATIVE_PATH,
        "model_dir_exists": MODEL_DIR.exists(),
        "model_dir_ready": model_dir_ready(MODEL_DIR),
        "load_ok": False,
        "predict_ok": False,
        "graded": False,
        "runtime_device": runtime_info.get("device", "cpu"),
        "cuda_available": runtime_info.get("cuda_available", False),
        "torch_npu_imported": runtime_info.get("torch_npu_imported", False),
        "npu_available": runtime_info.get("npu_available", False),
        "thread_limits": {name: os.environ.get(name, "") for name in THREAD_ENV_VARS},
    }
    if runtime_info.get("torch_npu_error"):
        detail["torch_npu_error"] = runtime_info["torch_npu_error"]
    bundle = None

    if not detail["model_dir_ready"]:
        # 模型缺失时不中断评测：A 项仍然可以给分，B/C 项稍后统一标记 skipped。
        detail["artifact_error"] = f"未检测到完整模型目录: {FIXED_MODEL_RELATIVE_PATH}/"
        detail["performance_eval_skipped"] = True
    else:
        try:
            bundle = load_qwen_bundle(MODEL_DIR)
            probe = predict_assistant_output_with_qwen(
                "并行处理两件事：给 HR 发主题为确认面试时间的邮件；查询北京明天天气。",
                bundle,
            )
            detail["load_ok"] = True
            probe_expected = [
                {
                    "tool_name": "email",
                    "wait_for_result": True,
                    "arguments": {"to": "HR", "subject": "确认面试时间", "body": "请确认面试安排"},
                },
                {
                    "tool_name": "weather",
                    "wait_for_result": False,
                    "arguments": {"city": "北京", "date": "明天"},
                },
            ]
            detail["predict_ok"] = (
                probe["parse_ok"]
                and wait_params_present(probe["tool_calls"])
                and tool_multiset_match(probe["tool_calls"], ["email", "weather"])
                and tool_wait_match(probe["tool_calls"], probe_expected)
            )
        except Exception as exc:
            detail["artifact_error"] = str(exc)

    return detail, bundle


def score_eval_split(
    split_name: str,
    rows: List[Dict[str, Any]],
    full_score: float,
    bundle: Any,
) -> Tuple[float, Dict[str, Any]]:
    """计算公开集或隐藏集的模型性能分。

    每条评测样本先通过 normalize_tool_agent_row 得到标准答案，再让提交模型真实生成。
    一条样本必须同时满足以下条件才算命中：
    - parse_ok：assistant 输出能被解析为工具调用；
    - wait_schema_hit：每个工具调用都显式带 wait_for_result；
    - tools_hit：工具多重集合匹配，顺序不作为唯一依据；
    - wait_hit：每个工具的等待策略符合标准答案；
    - args_hit：工具参数满足标准答案要求。

    full_score 决定该 split 的满分，公开集是 12，隐藏集是 8。当前数据是一题一分，
    但这里仍按 full_score / total_rows 计算，方便后续调整题量。
    """
    if bundle is None:
        return 0.0, {"error": "模型未加载，无法评测"}

    correct = 0
    details = []
    for item in rows:
        normalized = normalize_tool_agent_row(item)
        if normalized is None:
            continue
        query = normalized["query"]
        expected = normalized["answer_spec"]
        try:
            pred = predict_assistant_output_with_qwen(query, bundle)
        except Exception as exc:
            pred = {
                "parse_ok": False,
                "tool_calls": [],
                "raw": f"ERROR:{exc}",
                "cleaned": f"ERROR:{exc}",
            }

        wait_schema_hit = wait_params_present(pred["tool_calls"])
        tools_hit = tool_multiset_match(pred["tool_calls"], expected["tool_names"])
        wait_hit = tool_wait_match(pred["tool_calls"], expected["tool_calls"]) if tools_hit else False
        args_hit = calls_satisfy_expected(pred["tool_calls"], expected["tool_calls"]) if tools_hit else False
        # 只有格式、工具、等待策略、参数全部正确，才给该题分数。这样能避免模型只学会
        # 选择工具名但忽略 wait_for_result 或参数细节。
        hit = bool(pred["parse_ok"]) and wait_schema_hit and tools_hit and wait_hit and args_hit
        correct += int(hit)
        pred_names = [str(call.get("name", "")) for call in pred["tool_calls"]]
        details.append(
            {
                "id": normalized.get("id"),
                "pred_tool_names": pred_names,
                "expected_tool_names": list(expected["tool_names"]),
                "wait_schema_hit": wait_schema_hit,
                "wait_hit": wait_hit,
                "tools_hit": tools_hit,
                "args_hit": args_hit,
                "parse_ok": bool(pred["parse_ok"]),
                "hit": hit,
            }
        )
        print(
            f"[{split_name}] {normalized.get('id', '-')}: "
            f"pred={pred_names} expected={expected['tool_names']} "
            f"wait_schema={wait_schema_hit} wait={wait_hit} args={args_hit} hit={hit}"
        )

    total_rows = max(1, len(rows))
    acc = correct / total_rows
    score = float(full_score) * acc
    return round(score, 2), {
        "correct": correct,
        "total": len(rows),
        "accuracy": round(acc, 4),
        "points_per_hit": round(float(full_score) / total_rows, 4),
        "max_score": full_score,
        "score": round(score, 2),
        "preview": details[:6],
    }


def main() -> None:
    """评测主入口。

    注意隐藏集在学生自测环境中可能不存在。隐藏集缺失时，脚本只报告 A+B 的公开
    自测总分，但仍保留最终满分 30 的提示；正式评测环境会提供隐藏集文件并计算 C 项。
    """
    # 线程池限制必须在任何 torch 算子执行前设置才生效（set_num_interop_threads
    # 在线程池启动后调用会抛 RuntimeError）。probe_runtime_device 内部已记录线程
    # 设置状态，但为保险起见在入口最前再设置一次；失败不中断评测。
    try:
        import torch  # noqa: PLC0415

        torch.set_num_threads(MAX_BLAS_THREADS)
        torch.set_num_interop_threads(min(16, MAX_BLAS_THREADS))
    except Exception:
        pass

    runtime_info = probe_runtime_device()
    print("=" * 64)
    print("T2 正式评测开始：星港总调度官养成计划（真实训练版）")
    print("=" * 64)
    print(f"要求基座模型: {REQUIRED_BASE_MODEL}")
    print(f"要求微调方式: {REQUIRED_FINE_TUNING_TYPE}")
    print(f"固定模型目录: {MODEL_DIR}")
    print(
        "运行设备探测: "
        f"device={runtime_info.get('device')} "
        f"cuda={runtime_info.get('cuda_available')} "
        f"torch_npu_imported={runtime_info.get('torch_npu_imported')} "
        f"npu={runtime_info.get('npu_available')}"
    )
    print(f"线程限制: { {name: os.environ.get(name, '') for name in THREAD_ENV_VARS} }")
    print(f"官方推理 prompt: {TOOL_AGENT_SYSTEM_PROMPT}")

    public_eval = load_jsonl(PUBLIC_EVAL_PATH)
    hidden_eval = load_jsonl(HIDDEN_EVAL_PATH)
    hidden_missing = len(hidden_eval) == 0

    if hidden_missing:
        print("⚠️ 隐藏数据未给出，当前仅进行公开部分自测。")

    a_score, a_detail = score_submitted_dataset()
    artifact_detail, bundle = inspect_submission_artifacts()

    # B/C 项都依赖同一个固定模型目录。若目录不完整，则不重复尝试加载，统一跳过。
    model_missing_reason = None
    if not artifact_detail.get("model_dir_ready", False):
        model_missing_reason = f"未检测到完整模型目录: {FIXED_MODEL_RELATIVE_PATH}/"

    if model_missing_reason is not None:
        b_score, b_detail = 0.0, build_skipped_eval_detail(model_missing_reason)
    else:
        b_score, b_detail = score_eval_split(
            "PUBLIC",
            public_eval,
            B_PUBLIC_FULL,
            bundle,
        )

    if hidden_missing:
        c_score, c_detail = 0.0, {"provided": False, "score": 0.0}
    elif model_missing_reason is not None:
        c_score, c_detail = 0.0, build_skipped_eval_detail(model_missing_reason)
    else:
        c_score, c_detail = score_eval_split(
            "HIDDEN",
            hidden_eval,
            C_HIDDEN_FULL,
            bundle,
        )

    total = round(a_score + b_score + c_score, 2)

    # 控制台输出面向考生调试，保留较完整 detail；平台最终展示则读取下面 update_results
    # 写入的结构化结果。
    print("\n" + "-" * 64)
    print(f"[A ] 数据分布和多样性: {a_score:.2f}/{A_FULL:g}")
    print(f"     详情: {a_detail}")
    print(f"[前置检查] 模型与训练产物: {artifact_detail}")
    print(f"[B ] 公开集模型性能(每题 1 分): {b_score:.2f}/{B_PUBLIC_FULL:g}")
    print(f"     详情: {b_detail}")
    print(f"[C ] 隐藏集模型性能(每题 1 分): {c_score:.2f}/{C_HIDDEN_FULL:g}")
    print(f"     详情: {c_detail}")
    print("-" * 64)
    if hidden_missing:
        available_full = A_FULL + B_PUBLIC_FULL
        print(f"当前公开自测总分: {total:.2f}/{available_full:g}")
        print(f"最终满分仍为: {TOTAL_FULL:g}")
    else:
        print(f"总分: {total:.2f}/{TOTAL_FULL:g}")

    # 统一写回 results.json / 考生得分情况.md 等平台结果文件。detail 中保留所有子项
    # 诊断信息，便于定位是数据问题、模型目录问题，还是真实推理答题问题。
    result_path = update_results(
        ROOT,
        "T2",
        total,
        TOTAL_FULL,
        detail={
            "hidden_provided": not hidden_missing,
            "dataset": a_detail,
            "submission_prereq": artifact_detail,
            "public": b_detail,
            "hidden": c_detail,
            "score_breakdown": {
                "a_distribution_diversity": round(a_score, 2),
                "public": round(b_score, 2),
                "hidden": round(c_score, 2),
            },
        },
    )
    print(f"结果已更新: {result_path}")


if __name__ == "__main__":
    main()
