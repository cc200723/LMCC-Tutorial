# -*- coding: utf-8 -*-
"""T2 共享常量与工具函数。

这个文件被 T2 的训练脚本和评测脚本共同使用，主要承担四类职责：
1. 定义官方工具集合和 Qwen tools schema，确保训练、推理、评测使用同一套协议。
2. 定义数据、模型、评测集的固定路径，避免不同脚本各自硬编码路径后产生偏差。
3. 提供工具调用的渲染、解析和规范化函数，把不同历史版本的数据格式统一成
   evaluate.py 能比较的 answer_spec。
4. 提供评测辅助函数，用于判断模型输出是否选对工具、是否显式标注 wait_for_result、
   等待策略是否正确、参数中是否包含标准答案要求的关键信息。

本题的关键不是普通问答，而是“工具调度协议”：
- assistant 必须输出一个或多个 <tool_call>{...}</tool_call> 块；
- 每个 tool_call 必须包含 name、wait_for_result、arguments 三个字段；
- wait_for_result 与 arguments 同级，不能藏在 arguments 里；
- 多工具任务可以连续输出多个 tool_call，评测时工具顺序不是主要考点，但工具名、
  等待策略和参数关键信息必须全部匹配。
"""

from __future__ import annotations

from collections import Counter
import json
import re
from pathlib import Path
from typing import Any, Dict, Iterable, List


ALLOWED_TOOLS = (
    "weather",
    "calendar",
    "translation",
    "calculator",
    "map_route",
    "email",
    "stock_quote",
    "hotel_booking",
)

# 默认无需等待结果的工具。这个默认值主要用于兼容旧格式数据：如果某条历史样本
# 没有显式写 wait_for_result 或 wait_policy，normalize_tool_call 会用这里的规则
# 补出等待策略。正式训练/评测仍鼓励数据和模型输出显式带 wait_for_result。
DEFAULT_NO_WAIT_TOOLS = ("weather", "translation", "stock_quote")

# 官方等待字段名。注意它必须出现在 tool_call 的顶层，与 name、arguments 同级。
# 若模型把 wait_for_result 放进 arguments，normalize_tool_call 可以兼容解析，但
# evaluate.py 的 wait_schema_hit 会要求模型输出顶层字段，避免学生学到错误协议。
WAIT_PARAM_NAME = "wait_for_result"

# ROOT 默认是 lmcc 根目录。正常结构为 lmcc/T2/tool_agent_common.py，因此 parents[1]
# 正好指向 lmcc。下面两个 fallback 是为了兼容不同打包/上传形态，避免本地题包、
# 远程评测包或旧 upload 目录结构不一致导致 data 路径解析失败。
ROOT = Path(__file__).resolve().parents[1]
if not (ROOT / "data").exists():
    nested_lmcc = ROOT / "lmcc"
    if (nested_lmcc / "data").exists():
        ROOT = nested_lmcc
if not (ROOT / "data").exists():
    sibling_upload = ROOT.parent / "upload"
    if (sibling_upload / "data").exists():
        ROOT = sibling_upload

# 题目目录和产物目录。考生最终提交的训练数据和模型都必须放在 T2/artifacts 下，
# evaluate.py 只从这些固定位置读取，避免训练脚本输出到其它临时目录后被误判为提交。
TASK_DIR = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
ARTIFACT_DIR = TASK_DIR / "artifacts"
MODEL_DIR = ARTIFACT_DIR / "model"

# 题目固定要求：基座必须是 Qwen3-0.6B，微调方式是 full fine-tuning。这里的常量
# 主要用于 evaluate.py 打印和结果详情，不负责实际证明模型来源；真正能否得分取决于
# 固定目录中的模型是否能按 Qwen tool-call 协议完成公开/隐藏评测。
REQUIRED_BASE_MODEL = "Qwen3-0.6B"
REQUIRED_FINE_TUNING_TYPE = "full"
FIXED_MODEL_RELATIVE_PATH = "model"

# HuggingFace/Qwen 模型目录的最小完整性检查：必须有 config.json，并且存在至少一种
# 常见权重文件或权重索引。这个检查不是完整校验，但能过滤掉空目录或只放 README 的情况。
MODEL_CONFIG_NAME = "config.json"
MODEL_CONFIG_PATH = MODEL_DIR / MODEL_CONFIG_NAME
MODEL_WEIGHT_MARKERS = (
    "model.safetensors",
    "model.safetensors.index.json",
    "pytorch_model.bin",
    "pytorch_model.bin.index.json",
)

# Qwen 官方 chat template 会读取 tools 参数，把这里的 schema 渲染进 prompt。
# 训练和评测必须使用同一份 QWEN_TOOLS，否则模型在训练中看到的工具字段与评测时
# 看到的工具字段不一致，容易出现工具名、必填参数或 JSON 结构漂移。
#
# 每个工具 schema 都保持尽量简单：
# - name 是评测时唯一认可的工具名；
# - description 只给模型理解用途，不参与硬匹配；
# - parameters.required 决定模型至少应学会填哪些字段。
QWEN_TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "weather",
            "description": "查询天气",
            "parameters": {
                "type": "object",
                "properties": {
                    "city": {"type": "string"},
                    "date": {"type": "string"},
                },
                "required": ["city", "date"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "calendar",
            "description": "创建或查询日程提醒",
            "parameters": {
                "type": "object",
                "properties": {
                    "title": {"type": "string"},
                    "time": {"type": "string"},
                },
                "required": ["title", "time"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "translation",
            "description": "翻译文本",
            "parameters": {
                "type": "object",
                "properties": {
                    "text": {"type": "string"},
                    "target_lang": {"type": "string"},
                },
                "required": ["text", "target_lang"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "calculator",
            "description": "计算数学表达式",
            "parameters": {
                "type": "object",
                "properties": {
                    "expression": {"type": "string"},
                },
                "required": ["expression"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "map_route",
            "description": "查询路线",
            "parameters": {
                "type": "object",
                "properties": {
                    "origin": {"type": "string"},
                    "destination": {"type": "string"},
                    "mode": {"type": "string"},
                },
                "required": ["origin", "destination"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "email",
            "description": "发送邮件",
            "parameters": {
                "type": "object",
                "properties": {
                    "to": {"type": "string"},
                    "subject": {"type": "string"},
                    "body": {"type": "string"},
                },
                "required": ["to", "subject", "body"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "stock_quote",
            "description": "查询股票行情",
            "parameters": {
                "type": "object",
                "properties": {
                    "symbol": {"type": "string"},
                    "date": {"type": "string"},
                },
                "required": ["symbol", "date"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "hotel_booking",
            "description": "预订酒店",
            "parameters": {
                "type": "object",
                "properties": {
                    "city": {"type": "string"},
                    "check_in": {"type": "string"},
                    "nights": {"type": "integer"},
                    "budget": {"type": "integer"},
                },
                "required": ["city", "check_in", "nights", "budget"],
            },
        },
    },
]

# 固定系统提示。训练数据里的 system message 和 evaluate.py 推理时的 system message
# 都应使用这个字符串，保证模型学习到的输出协议与最终评测协议一致。
#
# 这里特意强调：
# - 多任务可以连续输出多个 <tool_call>；
# - tool_call JSON 必须包含 name、wait_for_result、arguments；
# - wait_for_result 不会在用户 query 中直接说明，需要模型根据工具协议判断；
# - 禁止输出 markdown/解释/最终答案，降低 parser 被额外文本干扰的概率。
TOOL_AGENT_SYSTEM_PROMPT = (
    "你是星港总调度工具调用助手。"
    "若用户请求可以通过工具完成，你必须输出 <tool_call>{...}</tool_call>。"
    "如果用户明确要求并行处理多个彼此独立的子任务，"
    "你应直接连续输出多个 <tool_call>{...}</tool_call>，每个子任务单独对应一个 tool_call。"
    "每个 tool_call 都必须是 JSON object，并包含 name、wait_for_result、arguments 三个字段。"
    "wait_for_result 与 arguments 同级。"
    "wait_for_result=false 表示该调用发射后无需等待结果；wait_for_result=true 表示后续流程依赖该调用结果。"
    "该字段取值遵循星港工具平台的内部回调协议，不会在用户 query 中明说。"
    "你必须根据学到的工具协议为每个 tool_call 选择正确的 wait_for_result。"
    "tool_call 中的 name 必须是 weather/calendar/translation/calculator/map_route/email/stock_quote/hotel_booking 之一。"
    "arguments 必须是合法 JSON object。"
    "禁止输出 markdown、解释、最终答案和任何与工具调用无关的额外文本。"
)

# 官方数据路径：
# - seed 文件是公开题目给出的种子/说明数据；
# - public eval 是公开评测集；
# - hidden eval 在出题包里用 final 文件模拟，正式发给考生时可以不提供。
SEED_PATH = DATA_DIR / "T2_seed_tasks.jsonl"
PUBLIC_EVAL_PATH = DATA_DIR / "T2_public_eval_queries.jsonl"
HIDDEN_EVAL_PATH = DATA_DIR / "T2_public_eval_queries.final.jsonl"

# 提交数据路径。训练脚本、数据合成脚本和评测脚本都围绕这两个文件约定：
# - tool_agent_train.jsonl：普通结构化训练数据，A 项会做规范化和多样性评分；
# - tool_agent_sft_train.jsonl：三段 messages 格式，用于 SFT/full fine-tuning。
TRAIN_DATA_PATH = ARTIFACT_DIR / "tool_agent_train.jsonl"
SFT_DATA_PATH = ARTIFACT_DIR / "tool_agent_sft_train.jsonl"
TOOL_AGENT_TRAIN_DATA_PATH = TRAIN_DATA_PATH
TOOL_AGENT_SFT_DATA_PATH = SFT_DATA_PATH

# 解析 assistant 输出时使用的正则。它只负责提取 <tool_call>...</tool_call> 中的
# JSON object 字符串；JSON 合法性、工具名合法性和等待字段合法性由后续 normalize
# 函数检查。DOTALL 允许 JSON 块跨多行。
TOOL_CALL_RE = re.compile(r"<tool_call>\s*(\{.*?\})\s*</tool_call>", flags=re.DOTALL)

# dispatch/waiting message 的弱校验会用到 CJK_RE，确保要求中文说明时不是空串或纯英文。
CJK_RE = re.compile(r"[\u4e00-\u9fff]")


def load_jsonl(path: Path) -> List[Dict[str, Any]]:
    """读取 JSONL 文件。

    文件不存在时返回空列表，而不是抛 FileNotFoundError。这样 evaluate.py 可以把
    “缺少训练数据/隐藏集未提供”转成结构化评分详情，而不是直接崩溃。

    注意：如果文件存在但某行不是合法 JSON，本函数会让 json.loads 的异常抛出。
    这是有意的，因为格式损坏的数据文件应当暴露为评测失败，而不是静默跳过。
    """
    rows: List[Dict[str, Any]] = []
    if not path.exists():
        return rows
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def write_jsonl(path: Path, rows: List[Dict[str, Any]]) -> None:
    """写入 JSONL 文件，供数据合成/训练准备脚本复用。

    ensure_ascii=False 保留中文 query 和参数，方便人工检查；每个 row 一行，保证
    evaluate.py 可以流式逐行读取。
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")


def valid_tool_name(tool_name: str) -> bool:
    """判断工具名是否属于官方允许集合。"""
    return str(tool_name).strip() in ALLOWED_TOOLS


def default_wait_policy(tool_name: str) -> str:
    """根据工具名给出旧格式数据的默认等待策略。

    这是兼容逻辑，不是鼓励模型省略 wait_for_result。最终模型输出仍必须显式标注
    wait_for_result，evaluate.py 才会把 wait_schema_hit 记为 True。
    """
    return "no_wait" if str(tool_name).strip() in DEFAULT_NO_WAIT_TOOLS else "wait"


def clean_model_text(text: str) -> str:
    """清理模型输出中与工具调用无关的模板/思考标记。

    Qwen 或某些训练配置可能输出 <think>...</think>、<|im_start|>、<|im_end|> 等
    chat-template 标记。解析 tool_call 前先移除这些噪声，可以让 parser 专注于
    <tool_call>{...}</tool_call> 块。
    """
    cleaned = str(text)
    # 仅当 "thinking ... response" 块位于文本开头（允许前导空白或模板 token）时删除；
    # 正文中恰好包含该模式的中文文本不应被误删。此正则与 Qwen/自定义模板的输出形态对齐。
    cleaned = re.sub(
        r"^(?:\s*<\|[^>]*\|>\s*)*thinking.*?response",
        "",
        cleaned,
        flags=re.DOTALL | re.IGNORECASE,
    )
    cleaned = re.sub(r"<\|[^>]*think[^>]*\|>", "", cleaned, flags=re.IGNORECASE)
    cleaned = cleaned.replace("<|im_start|>", "").replace("<|im_end|>", "")
    cleaned = cleaned.replace(" thinking", "").replace(" response", "")
    return cleaned.strip()


def normalize_tool_call(item: Dict[str, Any]) -> Dict[str, Any] | None:
    """把单个工具调用统一成内部标准格式。

    输入可能来自三类来源：
    - 训练数据中的 answer_json/tool_calls；
    - 模型输出解析出的 {"name": ..., "wait_for_result": ..., "arguments": ...}；
    - 旧版本数据中的 {"tool_name": ..., "wait_policy": ...}。

    返回的标准格式包含：
    - tool_name：官方工具名；
    - arguments：不含 wait_for_result 的参数字典；
    - must_contain：评测参数时必须在预测 arguments 中出现的字符串 marker；
    - wait_policy："wait" 或 "no_wait"；
    - has_wait_param：输入是否显式带了 wait_for_result 顶层字段；
    - wait_for_result：布尔等待标注。

    如果工具名非法、arguments 不是 dict，返回 None。这样上层可以把非法样本计为
    无效，而不是在后续评分里产生隐式通过。
    """
    if not isinstance(item, dict):
        return None
    tool_name = str(item.get("tool_name", item.get("name", ""))).strip()
    arguments = item.get("arguments")
    if tool_name not in ALLOWED_TOOLS or not isinstance(arguments, dict):
        return None

    # must_contain/required_markers 是参数匹配的弹性机制：标准答案不一定要求预测参数
    # 完全逐字段相等，但可以要求关键字符串必须出现在 arguments 的 JSON 表示中。
    must_contain = item.get("must_contain", item.get("required_markers"))
    markers: List[str] = []
    if isinstance(must_contain, list):
        markers = [str(x).strip() for x in must_contain if str(x).strip()]

    # 新协议要求 wait_for_result 出现在顶层；legacy_wait_param 只用于兼容早期把该字段
    # 放在 arguments 里的数据。has_wait_param 只承认顶层字段，用于评测格式严格性。
    has_wait_param = isinstance(item.get(WAIT_PARAM_NAME), bool)
    legacy_wait_param = isinstance(arguments.get(WAIT_PARAM_NAME), bool)
    raw_wait_policy = str(item.get("wait_policy", "")).strip().lower()
    if has_wait_param:
        raw_wait_policy = "wait" if bool(item.get(WAIT_PARAM_NAME)) else "no_wait"
    elif legacy_wait_param:
        raw_wait_policy = "wait" if bool(arguments.get(WAIT_PARAM_NAME)) else "no_wait"
    wait_policy = raw_wait_policy if raw_wait_policy in {"wait", "no_wait"} else default_wait_policy(tool_name)
    normalized_arguments = dict(arguments)
    # 无论输入是否把 wait_for_result 放进 arguments，标准化后的 arguments 都要移除它，
    # 保证后续渲染出的官方 tool_call 只有顶层 wait_for_result。
    normalized_arguments.pop(WAIT_PARAM_NAME, None)
    return {
        "tool_name": tool_name,
        "arguments": normalized_arguments,
        "must_contain": markers,
        "wait_policy": wait_policy,
        "has_wait_param": has_wait_param,
        WAIT_PARAM_NAME: wait_policy == "wait",
    }


def render_tool_call(tool_name: str, arguments: Dict[str, Any], wait_for_result: bool | None = None) -> str:
    """把标准工具调用渲染成 assistant 应输出的 <tool_call> 块。

    训练数据生成脚本应优先使用这个函数，而不是手写字符串。这样可以确保字段名、
    wait_for_result 位置和 JSON 序列化方式与评测 parser 一致。
    """
    payload_item: Dict[str, Any] = {"tool_name": tool_name, "arguments": arguments}
    if isinstance(wait_for_result, bool):
        payload_item[WAIT_PARAM_NAME] = wait_for_result
    normalized = normalize_tool_call(payload_item)
    if normalized is None:
        raise ValueError(f"非法工具调用: {tool_name}")
    payload = {
        "name": normalized["tool_name"],
        WAIT_PARAM_NAME: bool(normalized[WAIT_PARAM_NAME]),
        "arguments": dict(normalized["arguments"]),
    }
    return f"<tool_call>{json.dumps(payload, ensure_ascii=False, sort_keys=True)}</tool_call>"


def render_tool_calls(tool_calls: Iterable[Dict[str, Any]]) -> str:
    """渲染一组工具调用。

    多工具并行任务通过连续多个 <tool_call> 块表达，中间用换行分隔。非法工具调用
    会被跳过，便于生成脚本在候选池中容忍少量坏样本。
    """
    blocks: List[str] = []
    for item in tool_calls:
        normalized = normalize_tool_call(dict(item)) if isinstance(item, dict) else None
        if normalized is None:
            continue
        blocks.append(
            render_tool_call(
                normalized["tool_name"],
                normalized["arguments"],
                wait_for_result=bool(normalized[WAIT_PARAM_NAME]),
            )
        )
    return "\n".join(blocks)


def render_assistant_content(
    tool_calls: Iterable[Dict[str, Any]],
    dispatch_message: str = "",
    waiting_message: str = "",
) -> str:
    """渲染完整 assistant 内容。

    dispatch_message/waiting_message 是早期版本中用于解释“哪些工具需要等待”的中文
    前缀。当前正式评分更关注 tool_call 顶层 wait_for_result，但这里仍保留前缀支持，
    以兼容旧数据和训练脚本。
    """
    prefix = str(dispatch_message or waiting_message).strip()
    body = render_tool_calls(tool_calls)
    if prefix and body:
        return prefix + "\n" + body
    if prefix:
        return prefix
    return body


def parse_tool_calls(text: str) -> List[Dict[str, Any]]:
    """从模型输出中提取并规范化所有 tool_call。

    解析策略是“严格块、宽容内容”：
    - 必须存在 <tool_call>{...}</tool_call> 块；
    - 块内必须是合法 JSON object；
    - JSON 再经过 normalize_tool_call，非法工具名或非法 arguments 会被丢弃。
    """
    cleaned = clean_model_text(text)
    rows: List[Dict[str, Any]] = []
    for block in TOOL_CALL_RE.findall(cleaned):
        try:
            obj = json.loads(block)
        except Exception:
            continue
        normalized = normalize_tool_call(obj)
        if normalized is None:
            continue
        rows.append(
            {
                "name": normalized["tool_name"],
                "arguments": normalized["arguments"],
                "wait_policy": normalized["wait_policy"],
                "has_wait_param": normalized["has_wait_param"],
                WAIT_PARAM_NAME: bool(normalized[WAIT_PARAM_NAME]),
            }
        )
    return rows


def extract_dispatch_message(text: str) -> str:
    """提取第一个 tool_call 之前的说明文本。

    如果没有 tool_call，则返回清理后的完整文本。这个函数主要服务于旧版
    dispatch_message/waiting_message 评分或数据检查。
    """
    cleaned = clean_model_text(text)
    match = re.search(r"<tool_call>", cleaned)
    if match is None:
        return cleaned.strip()
    return cleaned[: match.start()].strip()


def parse_assistant_output(text: str) -> Dict[str, Any]:
    """解析 assistant 原始输出，返回 evaluate.py 使用的统一结构。

    parse_ok 的定义比较严格：模型输出中找到的 <tool_call> 块数量必须大于 0，
    且每个块都成功解析为合法工具调用。也就是说，只要出现了损坏 JSON 或非法工具名，
    block_count 就会大于 len(tool_calls)，parse_ok 会变成 False。
    """
    cleaned = clean_model_text(text)
    dispatch_message = extract_dispatch_message(cleaned)
    tool_calls = parse_tool_calls(cleaned)
    block_count = len(TOOL_CALL_RE.findall(cleaned))
    parse_ok = block_count > 0 and block_count == len(tool_calls)
    return {
        "cleaned": cleaned,
        "dispatch_message": dispatch_message,
        "waiting_message": dispatch_message,
        "tool_calls": tool_calls,
        "parse_ok": parse_ok,
    }


def _coerce_tool_calls(raw_calls: Any) -> List[Dict[str, Any]]:
    """把任意输入安全转换成规范化 tool_calls 列表。"""
    if not isinstance(raw_calls, list):
        return []
    rows: List[Dict[str, Any]] = []
    for item in raw_calls:
        normalized = normalize_tool_call(item if isinstance(item, dict) else {})
        if normalized is not None:
            rows.append(normalized)
    return rows


def derive_dispatch_groups(tool_calls: List[Dict[str, Any]]) -> Dict[str, List[str]]:
    """根据 wait_policy 把工具分成 no_wait_tools 和 wait_tools。

    这两个列表既用于旧版 dispatch_message 检查，也用于 answer_spec_to_json 输出
    可读结构，方便人工查看一条样本中哪些工具应等待结果。
    """
    no_wait_tools: List[str] = []
    wait_tools: List[str] = []
    for item in tool_calls:
        normalized = normalize_tool_call(item)
        if normalized is None:
            continue
        group = no_wait_tools if normalized["wait_policy"] == "no_wait" else wait_tools
        group.append(normalized["tool_name"])
    return {"no_wait_tools": no_wait_tools, "wait_tools": wait_tools}


def normalize_answer_spec(row: Dict[str, Any]) -> Dict[str, Any] | None:
    """把一条训练/评测数据中的答案部分统一成 answer_spec。

    本题迭代过程中出现过多种数据格式，因此这里集中做兼容：
    - 新格式：row["answer_json"] 中含 tool_calls/no_wait_tools/wait_tools；
    - 单工具格式：answer_json 直接含 name/arguments/wait_for_result；
    - 顶层格式：row["tool_calls"] 或 row["tool_names"]；
    - 极简格式：row["tool_name"]。

    输出 answer_spec 是 evaluate.py 的标准答案结构，包含工具调用列表、工具名列表、
    wait/no_wait 分组、是否并行等字段。无法提取任何合法工具调用时返回 None。
    """
    if not isinstance(row, dict):
        return None

    answer_json = row.get("answer_json")
    dispatch_message = str(row.get("dispatch_message", row.get("waiting_message", ""))).strip()
    dispatch_message_required = bool(row.get("dispatch_message_required", row.get("waiting_message_required", False)))
    no_wait_tools = row.get("no_wait_tools")
    wait_tools = row.get("wait_tools")
    tool_calls: List[Dict[str, Any]] = []

    if isinstance(answer_json, dict):
        # 优先读取 answer_json 中的新版字段，同时兼容 waiting_message 旧命名。
        dispatch_message = str(
            answer_json.get(
                "dispatch_message",
                answer_json.get("waiting_message", dispatch_message),
            )
        ).strip()
        dispatch_message_required = bool(
            answer_json.get(
                "dispatch_message_required",
                answer_json.get("waiting_message_required", dispatch_message_required),
            )
        )
        if no_wait_tools is None:
            no_wait_tools = answer_json.get("no_wait_tools")
        if wait_tools is None:
            wait_tools = answer_json.get("wait_tools")
        tool_calls = _coerce_tool_calls(answer_json.get("tool_calls"))
        if not tool_calls:
            # 单工具 answer_json 不一定有 tool_calls 数组，可能直接写 name/arguments。
            single_call = normalize_tool_call(
                {
                    "tool_name": answer_json.get("name", answer_json.get("tool_name", row.get("tool_name", ""))),
                    WAIT_PARAM_NAME: answer_json.get(WAIT_PARAM_NAME, row.get(WAIT_PARAM_NAME)),
                    "arguments": answer_json.get("arguments"),
                    "must_contain": answer_json.get("must_contain"),
                    "wait_policy": answer_json.get("wait_policy"),
                }
            )
            if single_call is not None:
                tool_calls = [single_call]
    else:
        tool_calls = _coerce_tool_calls(row.get("tool_calls"))

    if not tool_calls:
        # tool_names 只能恢复工具名和默认等待策略，无法恢复参数。它主要用于非常早期的
        # 数据检查，不建议作为最终训练数据格式。
        top_level_names = row.get("tool_names")
        if isinstance(top_level_names, list):
            tool_calls = [
                {
                    "tool_name": str(name).strip(),
                    "arguments": {},
                    "must_contain": [],
                    "wait_policy": default_wait_policy(str(name).strip()),
                }
                for name in top_level_names
                if valid_tool_name(str(name).strip())
            ]

    if not tool_calls and valid_tool_name(str(row.get("tool_name", "")).strip()):
        # 最后兜底到单个顶层 tool_name。这个分支让简单 starter 样例也能被规范化。
        tool_calls = [
            {
                "tool_name": str(row.get("tool_name")).strip(),
                "arguments": {},
                "must_contain": [],
                "wait_policy": row.get("wait_policy", default_wait_policy(str(row.get("tool_name")).strip())),
                WAIT_PARAM_NAME: bool(row.get(WAIT_PARAM_NAME, default_wait_policy(str(row.get("tool_name")).strip()) == "wait")),
            }
        ]

    if not tool_calls:
        return None

    groups = derive_dispatch_groups(tool_calls)
    # 如果数据显式给了 no_wait_tools/wait_tools，就使用显式列表；否则从 tool_calls 的
    # wait_policy 派生。这保证旧数据和新数据都能得到一致的 answer_spec 字段。
    normalized_no_wait = [
        str(name).strip()
        for name in (no_wait_tools if isinstance(no_wait_tools, list) else groups["no_wait_tools"])
        if valid_tool_name(str(name).strip())
    ]
    normalized_wait = [
        str(name).strip()
        for name in (wait_tools if isinstance(wait_tools, list) else groups["wait_tools"])
        if valid_tool_name(str(name).strip())
    ]
    tool_names = [call["tool_name"] for call in tool_calls]
    return {
        "dispatch_message": dispatch_message,
        "dispatch_message_required": dispatch_message_required,
        "waiting_message": dispatch_message,
        "waiting_message_required": dispatch_message_required,
        "no_wait_tools": normalized_no_wait,
        "wait_tools": normalized_wait,
        "tool_calls": tool_calls,
        "tool_names": tool_names,
        "is_parallel": len(tool_calls) > 1,
    }


def answer_spec_to_json(answer_spec: Dict[str, Any]) -> Dict[str, Any]:
    """把内部 answer_spec 转回可写入 JSONL 的 answer_json。

    这个函数用于生成标准训练数据。单工具、无 dispatch_message 的样本会被压缩成
    简洁格式；多工具或含 dispatch_message 的样本会保留 tool_calls 数组和分组信息。
    """
    tool_calls = answer_spec.get("tool_calls", [])
    dispatch_message = str(answer_spec.get("dispatch_message", answer_spec.get("waiting_message", ""))).strip()
    dispatch_message_required = bool(
        answer_spec.get("dispatch_message_required", answer_spec.get("waiting_message_required", False))
    )
    no_wait_tools = [
        str(name).strip()
        for name in answer_spec.get("no_wait_tools", [])
        if valid_tool_name(str(name).strip())
    ]
    wait_tools = [
        str(name).strip()
        for name in answer_spec.get("wait_tools", [])
        if valid_tool_name(str(name).strip())
    ]
    if len(tool_calls) == 1 and not dispatch_message and not dispatch_message_required:
        # 单工具样本用最短 answer_json，降低学生理解成本，同时仍包含 wait_for_result。
        only_call = tool_calls[0]
        only_wait = only_call.get(WAIT_PARAM_NAME)
        if not isinstance(only_wait, bool):
            only_wait = str(only_call.get("wait_policy", default_wait_policy(only_call["tool_name"]))) == "wait"
        return {
            "name": only_call["tool_name"],
            WAIT_PARAM_NAME: bool(only_wait),
            "arguments": dict(only_call["arguments"]),
        }
    return {
        "dispatch_message": dispatch_message,
        "dispatch_message_required": dispatch_message_required,
        "no_wait_tools": no_wait_tools,
        "wait_tools": wait_tools,
        "tool_calls": [
            {
                "name": item["tool_name"],
                WAIT_PARAM_NAME: bool(
                    item.get(
                        WAIT_PARAM_NAME,
                        str(item.get("wait_policy", default_wait_policy(item["tool_name"]))) == "wait",
                    )
                ),
                "arguments": dict(item["arguments"]),
                "wait_policy": str(item.get("wait_policy", default_wait_policy(item["tool_name"]))),
                **({"must_contain": list(item["must_contain"])} if item.get("must_contain") else {}),
            }
            for item in tool_calls
        ],
    }


def normalize_tool_agent_row(row: Dict[str, Any]) -> Dict[str, Any] | None:
    """规范化完整样本行。

    合法样本至少需要：
    - query：非空用户请求；
    - answer_spec：能从答案字段中提取出至少一个合法工具调用。

    返回值同时包含 answer_spec 和 answer_json，方便 evaluate.py 评分，也方便数据
    生成脚本把不同来源样本统一写回最终训练集。
    """
    if not isinstance(row, dict):
        return None
    query = str(row.get("query", "")).strip()
    answer_spec = normalize_answer_spec(row)
    if not query or answer_spec is None:
        return None
    return {
        "id": row.get("id"),
        "query": query,
        "tool_names": list(answer_spec["tool_names"]),
        "dispatch_message_required": bool(answer_spec["dispatch_message_required"]),
        "waiting_message_required": bool(answer_spec["dispatch_message_required"]),
        "answer_spec": answer_spec,
        "answer_json": answer_spec_to_json(answer_spec),
    }


def tool_name_counter(tool_names: Iterable[str]) -> Counter[str]:
    """统计工具名多重集合。

    使用 Counter 而不是 set，是为了正确处理理论上同一条 query 里多次调用同一工具
    的情况。虽然当前公开样本多为不同工具组合，但评测辅助函数保持更通用的语义。
    """
    return Counter(str(name).strip() for name in tool_names if valid_tool_name(str(name).strip()))


def tool_wait_counter(tool_calls: Iterable[Dict[str, Any]]) -> Counter[tuple[str, str]]:
    """统计 (工具名, 等待策略) 的多重集合。"""
    counter: Counter[tuple[str, str]] = Counter()
    for item in tool_calls:
        normalized = normalize_tool_call(item if isinstance(item, dict) else {})
        if normalized is None:
            continue
        counter[(normalized["tool_name"], normalized["wait_policy"])] += 1
    return counter


def tool_multiset_match(pred_calls: List[Dict[str, Any]], expected_tool_names: Iterable[str]) -> bool:
    """判断预测工具集合是否与标准答案一致，忽略顺序但不忽略重复次数。"""
    pred_names = [str(call.get("name", call.get("tool_name", ""))).strip() for call in pred_calls]
    return tool_name_counter(pred_names) == tool_name_counter(expected_tool_names)


def tool_wait_match(pred_calls: List[Dict[str, Any]], expected_calls: List[Dict[str, Any]]) -> bool:
    """判断预测的工具名和 wait/no_wait 策略是否同时匹配。"""
    return tool_wait_counter(pred_calls) == tool_wait_counter(expected_calls)


def _flatten_leaf_values(value: Any) -> List[str]:
    """抽取嵌套参数中的所有叶子值，转成字符串 marker。

    当标准答案没有显式 must_contain 时，参数匹配会退化为“预测 arguments 中必须包含
    标准答案 arguments 的所有叶子字符串”。这样可以容忍字段顺序、额外字段或轻微
    JSON 结构差异，但仍要求关键信息不丢失。
    """
    if isinstance(value, dict):
        rows: List[str] = []
        for item in value.values():
            rows.extend(_flatten_leaf_values(item))
        return rows
    if isinstance(value, list):
        rows = []
        for item in value:
            rows.extend(_flatten_leaf_values(item))
        return rows
    if value is None:
        return []
    text = str(value).strip()
    return [text] if text else []


def _call_markers(expected_call: Dict[str, Any]) -> List[str]:
    """获取一条标准工具调用的参数匹配 marker。

    优先使用 must_contain，因为有些参数只需要包含关键文本即可；没有 must_contain
    时，自动从 expected arguments 的叶子值生成 marker。
    """
    markers = expected_call.get("must_contain")
    if isinstance(markers, list) and markers:
        return [str(item).strip() for item in markers if str(item).strip()]
    return _flatten_leaf_values(expected_call.get("arguments", {}))


def call_matches_expected(pred_call: Dict[str, Any], expected_call: Dict[str, Any]) -> bool:
    """判断单个预测工具调用是否满足单个标准工具调用。

    匹配条件从严格到宽松依次是：
    1. 两边都能规范化；
    2. 工具名相同；
    3. 预测输出显式带 wait_for_result 顶层字段；
    4. wait/no_wait 策略相同；
    5. 预测 arguments 中包含标准答案要求的所有 marker。

    第 3 点是本题的重要格式约束：即使 default_wait_policy 能推断等待策略，模型
    没有显式输出 wait_for_result 也不能算完全正确。
    """
    pred = normalize_tool_call(pred_call)
    expected = normalize_tool_call(expected_call)
    if pred is None or expected is None:
        return False
    if pred["tool_name"] != expected["tool_name"]:
        return False
    if not pred.get("has_wait_param", False):
        return False
    if pred["wait_policy"] != expected["wait_policy"]:
        return False
    markers = _call_markers(expected)
    if not markers:
        return True
    haystack = json.dumps(pred["arguments"], ensure_ascii=False, sort_keys=True)
    # 这里使用字符串包含而不是 dict 完全相等，是为了允许模型输出额外但无害的字段，
    # 同时要求城市、日期、股票代码、收件人等关键值必须被保留。
    return all(marker in haystack for marker in markers)


def calls_satisfy_expected(pred_calls: List[Dict[str, Any]], expected_calls: List[Dict[str, Any]]) -> bool:
    """判断一组预测工具调用是否整体满足标准答案。

    多工具输出不要求顺序一致，因此不能简单 zip(pred, expected)。这里先检查工具名
    多重集合一致，再用 DFS 寻找“预测调用 -> 标准调用”的一一匹配。这样既能容忍
    并行工具调用顺序变化，又能确保每个标准调用都被某个预测调用满足。
    """
    normalized_pred = [normalize_tool_call(call) for call in pred_calls]
    normalized_exp = [normalize_tool_call(call) for call in expected_calls]
    pred_rows = [row for row in normalized_pred if row is not None]
    exp_rows = [row for row in normalized_exp if row is not None]
    if len(pred_rows) != len(exp_rows):
        return False
    if not tool_multiset_match(pred_rows, [row["tool_name"] for row in exp_rows]):
        return False

    used = [False] * len(pred_rows)

    def dfs(idx: int) -> bool:
        """回溯寻找任意可行匹配。样本工具数很少，DFS 成本可以忽略。"""
        if idx >= len(exp_rows):
            return True
        expected = exp_rows[idx]
        for j, pred in enumerate(pred_rows):
            if used[j]:
                continue
            if not call_matches_expected(pred, expected):
                continue
            used[j] = True
            if dfs(idx + 1):
                return True
            used[j] = False
        return False

    # marker 多的标准调用约束更强，优先匹配它们可以更快剪枝。
    exp_rows.sort(key=lambda row: len(_call_markers(row)), reverse=True)
    return dfs(0)


def dispatch_message_ok(
    dispatch_message: str,
    required: bool,
    no_wait_tools: List[str] | None = None,
    wait_tools: List[str] | None = None,
) -> bool:
    """检查旧版 dispatch/waiting message 是否满足中文说明要求。

    当前核心评测已经转向显式 wait_for_result 字段，但早期数据中还会要求 assistant
    在 tool_call 前用中文说明哪些工具无需等待、哪些工具需要等待。这个函数保留
    该兼容能力：只有 required=True 时才检查，否则直接通过。
    """
    if not required:
        return True
    text = str(dispatch_message).strip()
    if not text or not CJK_RE.search(text):
        return False

    lowered = text.lower()
    no_wait = [str(name).strip() for name in (no_wait_tools or []) if valid_tool_name(str(name).strip())]
    waits = [str(name).strip() for name in (wait_tools or []) if valid_tool_name(str(name).strip())]

    if no_wait:
        # no_wait 工具需要出现“无需等待/不用等待”等中文表达，并且提到对应工具名。
        if not any(token in text for token in ("无需等待", "不必等待", "不用等待", "无需等结果")):
            return False
        if not all(name.lower() in lowered for name in no_wait):
            return False
    if waits:
        # wait 工具需要出现“等待/需要等待”等中文表达，并且提到对应工具名。
        if not any(token in text for token in ("等待", "需等待", "需要等待", "等结果")):
            return False
        if not all(name.lower() in lowered for name in waits):
            return False
    return True


def waiting_message_ok(
    waiting_message: str,
    required: bool,
    no_wait_tools: List[str] | None = None,
    wait_tools: List[str] | None = None,
) -> bool:
    """兼容旧命名 waiting_message；语义等同 dispatch_message_ok。"""
    return dispatch_message_ok(waiting_message, required, no_wait_tools=no_wait_tools, wait_tools=wait_tools)


def tokenize_query(query: str) -> List[str]:
    """把 query 粗略切成英文/数字 token 和中文字符/ngram。

    这是轻量文本分析工具，适合数据生成脚本做去重或覆盖检查。它不是分词器：
    - 英文、数字、股票代码等用正则整体提取；
    - 中文连续片段拆成单字和相邻 bigram，便于捕捉“天气/路线/邮件”等短语。
    """
    q = str(query).strip().lower()
    tokens: List[str] = []

    tokens.extend(re.findall(r"[a-z0-9_.+-]+", q))

    cjk_blocks = re.findall(r"[\u4e00-\u9fff]+", q)
    for block in cjk_blocks:
        chars = list(block)
        tokens.extend(chars)
        for i in range(len(chars) - 1):
            tokens.append(chars[i] + chars[i + 1])

    return tokens


def list_relative_files(base_dir: Path = MODEL_DIR) -> List[str]:
    """列出模型目录下相对 artifacts 的文件路径。

    结果用于调试或结果详情展示。路径统一用 /，避免 Windows/Unix 分隔符差异影响
    文本比较。
    """
    if not base_dir.exists():
        return []
    files = []
    for path in base_dir.rglob("*"):
        if path.is_file():
            files.append(str(path.relative_to(ARTIFACT_DIR)).replace("\\", "/"))
    return sorted(files)


def model_dir_ready(model_dir: Path = MODEL_DIR) -> bool:
    """判断固定模型目录是否至少像一个可加载的 HuggingFace 模型目录。

    最小条件：
    1. 目录存在；
    2. 有 config.json；
    3. 有 safetensors/bin 权重文件或对应 index。

    这一步只做快速前置检查。即使返回 True，evaluate.py 仍会实际调用
    AutoTokenizer/AutoModelForCausalLM.from_pretrained 加载模型；加载失败会记录到
    artifact_detail 中。
    """
    if not model_dir.exists() or not model_dir.is_dir():
        return False
    if not (model_dir / MODEL_CONFIG_NAME).exists():
        return False
    return any((model_dir / marker).exists() for marker in MODEL_WEIGHT_MARKERS)
